# Plugin Wiring: save_artifact Integration

Apply these changes to the Blue Contact plugin repo at `/Users/jmclachlan/gh/claude-plugins`.

The `save_artifact` MCP tool is already registered on the BlueQueryAI server. These changes add it to the plugin skills so Claude knows to call it after generating visualizations.

## Changes Summary

Two changes per skill:
1. **Frontmatter**: Add `- blue-contact:save_artifact` to `allowed-tools`
2. **Workflow**: Add a "Persist the artifact" step after JSX/HTML creation

## Artifact Type Selection

The `save_artifact` tool supports two artifact types. Skills must pick the right one based on what they generated:

| Generated output | `artifact_type` value | When to use |
|---|---|---|
| React `.jsx` component with Recharts, `import` statements, `export default`, `useState` | `"react_dashboard"` | Skills that build JSX dashboards (audience-report, audience-compare, market-sizing, etc.) |
| Self-contained HTML with inline `<script>`, `<style>`, SVG, or Chart.js/vanilla JS | `"html"` | Cowork `show_widget` output, HTML data tables, SVG visualizations, any non-React interactive content |

**Rule of thumb:** If the source code starts with `import` or contains `export default function`, it's `react_dashboard`. If it starts with `<` (HTML/SVG tag) or contains `<script>` tags, it's `html`.

Skills should detect which format was generated and set `artifact_type` accordingly — **do not hardcode `react_dashboard`**. The getting-started skill in particular may produce either format depending on the topic.

---

## 1. `skills/audience-report/SKILL.md`

### Frontmatter — add to allowed-tools:
```yaml
  - blue-contact:save_artifact
```

### Workflow — replace Step 5 ("Generate visualizations") with:

```markdown
### 5. Generate and persist visualizations

Create visualization artifacts alongside the report for interactive viewing:
- Use Recharts with Blue Contact brand colors from `brand.json` (contactBlue primary)
- Build a comprehensive dashboard that mirrors the report content
- Present the artifact so the user can interact with the charts

**Persist to the audience:** After creating the visualization, call `save_artifact` to attach it to the audience so it's accessible from the BlueQueryAI web app. Detect the artifact type from the source code:
- If the visualization is a React `.jsx` component (imports, export default), use `artifact_type: "react_dashboard"`
- If the visualization is self-contained HTML (inline scripts, SVG, Chart.js), use `artifact_type: "html"`

```
save_artifact(
  audience_id: <the audience ID>,
  title: "<Audience title> — Demographic Report",
  source_code: <the complete source code — JSX or HTML>,
  artifact_type: <"react_dashboard" or "html" based on what was generated>,
  metadata: { "generated_by": "audience-report", "chart_types": ["bar", "pie", "progress"] }
)
```
The artifact will be compiled and hosted automatically. Include the returned `share_url` when presenting results to the user.
```

---

## 2. `skills/audience-compare/SKILL.md`

### Frontmatter — add to allowed-tools:
```yaml
  - blue-contact:save_artifact
```

### Workflow — at the end of Section 4 ("Build the comparison dashboard"), add:

```markdown
**Persist to both audiences:** After creating the comparison visualization, call `save_artifact` twice — once for each audience — so the comparison is accessible from either audience's page. Detect `artifact_type` from the source code (`"react_dashboard"` for JSX, `"html"` for HTML):
```
save_artifact(
  audience_id: <audience A ID>,
  title: "<A title> vs <B title> — Comparison",
  source_code: <the complete source code>,
  artifact_type: <"react_dashboard" or "html">,
  metadata: { "generated_by": "audience-compare", "compared_with": <audience B ID> }
)
save_artifact(
  audience_id: <audience B ID>,
  title: "<A title> vs <B title> — Comparison",
  source_code: <the complete source code>,
  artifact_type: <"react_dashboard" or "html">,
  metadata: { "generated_by": "audience-compare", "compared_with": <audience A ID> }
)
```
```

---

## 3. `skills/data-health/SKILL.md`

### Frontmatter — add to allowed-tools:
```yaml
  - blue-contact:save_artifact
```

**Note:** This skill currently has no `allowed-tools` section in its frontmatter. Add the full block:
```yaml
allowed-tools:
  - blue-contact:get_schema
  - blue-contact:get_query_instructions
  - blue-contact:validate_sql
  - blue-contact:execute_sql_query
  - blue-contact:save_artifact
```

### Workflow — at the end of Section 4 ("Build the health check dashboard"), add:

```markdown
**Persist the dashboard:** Data health reports aren't tied to a single audience, but if the user has a recent audience, offer to attach the health check to it. Detect `artifact_type` from the source code (`"react_dashboard"` for JSX with Recharts imports, `"html"` for self-contained HTML/SVG):
```
save_artifact(
  audience_id: <most relevant audience ID, or ask the user>,
  title: "Data Health Check — <date>",
  source_code: <the complete source code>,
  artifact_type: <"react_dashboard" or "html">,
  metadata: { "generated_by": "data-health", "overall_grade": "<A/B/C/D>" }
)
```
```

---

## 4. `skills/market-sizing/SKILL.md`

### Frontmatter — add to allowed-tools:
```yaml
  - blue-contact:save_artifact
```

### Workflow — at the end of Section 5 ("Build the market opportunity dashboard"), add:

```markdown
**Persist to the audience:** If the market sizing created an audience (via `run_audience_query` or `create_audience`), attach the dashboard to it. If not, create an audience first so the dashboard has a home. Detect `artifact_type` from the source code:
```
save_artifact(
  audience_id: <the audience ID>,
  title: "<Market description> — Market Opportunity",
  source_code: <the complete source code>,
  artifact_type: <"react_dashboard" or "html">,
  metadata: { "generated_by": "market-sizing", "tam": <TAM count>, "reachable": <reachable count> }
)
```
Include the returned `share_url` in the findings presentation — stakeholders can open the dashboard without needing Cowork access.
```

---

## 5. `skills/audience-logic-report/SKILL.md`

### Frontmatter — add to allowed-tools:
```yaml
  - blue-contact:save_artifact
```

### Workflow — at the end of Section 4b ("Build the waterfall dropoff visualization"), after the JSX component structure section, add:

```markdown
**Persist the waterfall:** Call `save_artifact` to attach the interactive waterfall chart to the audience. Detect `artifact_type` from the source code:
```
save_artifact(
  audience_id: <the audience ID>,
  title: "<Audience title> — Filter Funnel",
  source_code: <the complete source code>,
  artifact_type: <"react_dashboard" or "html">,
  metadata: { "generated_by": "audience-logic-report", "steps": <number of funnel steps>, "final_count": <final count> }
)
```
The shareable URL lets reviewers see the interactive funnel without needing Cowork access — include it alongside the .docx when delivering the report.
```

---

## 6. `skills/getting-started/SKILL.md`

### Frontmatter — this skill has no `allowed-tools`. Add the section:
```yaml
allowed-tools:
  - blue-contact:get_schema
  - blue-contact:get_query_instructions
  - blue-contact:validate_sql
  - blue-contact:execute_sql_query
  - blue-contact:run_audience_query
  - blue-contact:create_audience
  - blue-contact:get_audience
  - blue-contact:list_audiences
  - blue-contact:save_message
  - blue-contact:save_artifact
```

### Workflow — in Phase 3, at the end of the "General pattern for each topic" section (after step 4 "Build a visualization"), add a new step 5:

```markdown
5. **Persist the visualization.** If the exploration created an audience (e.g., "Build your first audience" topic), call `save_artifact` to attach the dashboard. Detect `artifact_type` from what was generated — the getting-started skill may produce either JSX (interactive Recharts dashboards) or HTML (simpler visualizations, show_widget output):
   ```
   save_artifact(
     audience_id: <the audience ID>,
     title: "<topic> — Getting Started Exploration",
     source_code: <the complete source code>,
     artifact_type: <"react_dashboard" or "html">,
     metadata: { "generated_by": "getting-started", "topic": "<topic name>" }
   )
   ```
   For topics that don't create an audience (e.g., "Explore your data", demographic snapshot without audience creation), skip this step — the visualization lives in the Cowork session only. If the user later builds an audience from the exploration, the artifact can be saved then.
```

(Renumber the existing steps 5 and 6 to 6 and 7.)

---

## 7. `skills/audience-monitor/SKILL.md`

### Frontmatter — this skill has no `allowed-tools`. Add the section:
```yaml
allowed-tools:
  - blue-contact:get_schema
  - blue-contact:get_query_instructions
  - blue-contact:validate_sql
  - blue-contact:execute_sql_query
  - blue-contact:get_audience
  - blue-contact:list_audiences
  - blue-contact:save_message
  - blue-contact:save_artifact
```

### Workflow — in Section 6 ("Optional: Historical dashboard"), replace the existing content with:

```markdown
### 6. Optional: Historical dashboard

If the user wants to see trends over time after several monitoring runs:
- Gather historical data points from the audience's conversation history (`get_audience` with message history)
- Build a React (.jsx) trend visualization using brand colors from `brand/brand.json`, showing count/coverage over time as a line chart
- Highlight any significant changes or inflection points

**Persist the trend dashboard:** Call `save_artifact` to attach the trend chart to the audience. Detect `artifact_type` from the source code:
```
save_artifact(
  audience_id: <the audience ID>,
  title: "<Audience title> — Monitoring Trends",
  source_code: <the complete source code>,
  artifact_type: <"react_dashboard" or "html">,
  metadata: { "generated_by": "audience-monitor", "data_points": <number of monitoring runs> }
)
```
```

---

## Skills NOT modified (no artifact generation)

These skills don't generate JSX/HTML visualizations, so no changes needed:

- **audience-building** — orchestrates query building, delegates visualization to other skills
- **audience-pull** — creates audiences, no dashboards
- **data-dictionary** — text-based field definitions
- **data-querying** — domain knowledge for query writing
- **industry-playbooks** — pre-built audience recipes
- **setup** — connection configuration

---

## Testing

After applying these changes, test with:

1. **audience-report**: Run `/blue-contact:audience-report` on an existing audience → verify the artifact appears in the BlueQueryAI web app under that audience
2. **audience-compare**: Compare two audiences → verify artifacts saved to both
3. **market-sizing**: Size a market → verify the opportunity dashboard is persisted
4. **audience-logic-report**: Generate a logic report → verify the waterfall chart is persisted

Check the share URL works in an incognito window (public, no auth required).
