const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, AlignmentType, BorderStyle, WidthType, ShadingType,
  LevelFormat, Footer, Header, TabStopType, ImageRun, PageNumber
} = require('docx');
const fs = require('fs');

// ── BRAND COLORS (from Blue Contact Brand Guidelines) ─────────────
const BC_BLUE       = "006AFF";   // Contact Blue — primary brand
const BC_GRAPHITE   = "2A3A57";   // Graphite — body text / dark headings
const BC_DARK_NAVY  = "334669";   // Clear Sky (dark) — accent
const BC_CLEAR_SKY  = "334669";   // Clear Sky
const BC_SEAFOAM    = "12C7B4";   // Seafoam accent
const BC_SUCCESS    = "00C864";
const BC_DANGER     = "DB4646";
const BC_HAZARD     = "FF9A1F";
const BC_EGGSHELL   = "E4E9F5";   // Background tint
const BC_WHITE      = "FFFFFF";
const BC_LIGHT_RULE = "D0D9EF";   // Light rule lines

// Logo PNGs
const logoHorizontal = fs.readFileSync('/home/claude/logo_horizontal.png');
const logoIcon       = fs.readFileSync('/home/claude/logo_icon.png');

// ── BORDER HELPERS ─────────────────────────────────────────────────
const border  = (color = BC_LIGHT_RULE) => ({ style: BorderStyle.SINGLE, size: 1, color });
const borders = (color = BC_LIGHT_RULE) => ({ top: border(color), bottom: border(color), left: border(color), right: border(color) });
const noBorders = { top: { style: BorderStyle.NONE }, bottom: { style: BorderStyle.NONE }, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE } };

// ── TEXT HELPERS ───────────────────────────────────────────────────
const run  = (text, opts = {}) => new TextRun({ text, font: "Arial", size: 22, ...opts });
const bold = (text, opts = {}) => run(text, { bold: true, ...opts });

function para(children, opts = {}) {
  return new Paragraph({ spacing: { before: 60, after: 60 }, children: Array.isArray(children) ? children : [children], ...opts });
}

function h1(text) {
  return new Paragraph({
    spacing: { before: 360, after: 120 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: BC_BLUE, space: 4 } },
    children: [new TextRun({ text: text.toUpperCase(), font: "Arial", size: 24, bold: true, color: BC_GRAPHITE, characterSpacing: 40 })]
  });
}

function h2(text) {
  return new Paragraph({
    spacing: { before: 240, after: 80 },
    children: [new TextRun({ text, font: "Arial", size: 22, bold: true, color: BC_BLUE })]
  });
}

function bodyPara(text, opts = {}) {
  return para([run(text, { color: BC_GRAPHITE, ...opts })]);
}

function notePara(text) {
  return new Paragraph({
    spacing: { before: 60, after: 60 },
    indent: { left: 360 },
    children: [
      run("Note: ", { bold: true, color: BC_SEAFOAM, size: 20 }),
      run(text, { color: "666666", size: 20, italics: true })
    ]
  });
}

function bullet(text, editable = false) {
  return new Paragraph({
    numbering: { reference: "bullets", level: 0 },
    spacing: { before: 40, after: 40 },
    children: editable
      ? [run(text, { color: BC_GRAPHITE, size: 22 }), run("  ← editable", { color: "AAAAAA", size: 18, italics: true })]
      : [run(text, { color: BC_GRAPHITE, size: 22 })]
  });
}

function spacer(before = 160) {
  return new Paragraph({ spacing: { before, after: 0 }, children: [run("")] });
}

// ── TABLE HELPERS ──────────────────────────────────────────────────
function filterTable(rows) {
  const COL1 = 2600, COL2 = 6760;
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [COL1, COL2],
    rows: [
      // Header row
      new TableRow({
        children: [
          new TableCell({
            borders: borders(BC_BLUE), width: { size: COL1, type: WidthType.DXA },
            shading: { fill: BC_GRAPHITE, type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 140, right: 140 },
            children: [para([bold("Setting", { color: BC_WHITE, size: 20 })])]
          }),
          new TableCell({
            borders: borders(BC_BLUE), width: { size: COL2, type: WidthType.DXA },
            shading: { fill: BC_GRAPHITE, type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 140, right: 140 },
            children: [para([bold("Value", { color: BC_WHITE, size: 20 })])]
          })
        ]
      }),
      ...rows.map(([label, value, editable], i) => new TableRow({
        children: [
          new TableCell({
            borders: borders(), width: { size: COL1, type: WidthType.DXA },
            shading: { fill: i % 2 === 0 ? BC_EGGSHELL : BC_WHITE, type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 140, right: 140 },
            children: [para([bold(label, { size: 20, color: BC_GRAPHITE })])]
          }),
          new TableCell({
            borders: borders(), width: { size: COL2, type: WidthType.DXA },
            shading: { fill: i % 2 === 0 ? BC_EGGSHELL : BC_WHITE, type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 140, right: 140 },
            children: [new Paragraph({
              spacing: { before: 0, after: 0 },
              children: editable
                ? [run(value, { size: 20, color: BC_BLUE }), run("  ← editable", { size: 18, color: "AAAAAA", italics: true })]
                : [run(value, { size: 20, color: BC_GRAPHITE })]
            })]
          })
        ]
      }))
    ]
  });
}

function blueBox(headerText, children) {
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [9360],
    rows: [
      new TableRow({ children: [new TableCell({
        borders: borders(BC_BLUE), width: { size: 9360, type: WidthType.DXA },
        shading: { fill: BC_BLUE, type: ShadingType.CLEAR },
        margins: { top: 100, bottom: 100, left: 180, right: 180 },
        children: [para([bold(headerText, { color: BC_WHITE, size: 22 })])]
      })] }),
      new TableRow({ children: [new TableCell({
        borders: borders(), width: { size: 9360, type: WidthType.DXA },
        shading: { fill: BC_EGGSHELL, type: ShadingType.CLEAR },
        margins: { top: 120, bottom: 120, left: 180, right: 180 },
        children
      })] })
    ]
  });
}

function summaryTable(rows) {
  const COL1 = 2800, COL2 = 6560;
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [COL1, COL2],
    rows: rows.map(([label, value], i) => new TableRow({
      children: [
        new TableCell({
          borders: borders(), width: { size: COL1, type: WidthType.DXA },
          shading: { fill: BC_GRAPHITE, type: ShadingType.CLEAR },
          margins: { top: 80, bottom: 80, left: 140, right: 140 },
          children: [para([bold(label, { color: BC_WHITE, size: 20 })])]
        }),
        new TableCell({
          borders: borders(), width: { size: COL2, type: WidthType.DXA },
          shading: { fill: i % 2 === 0 ? BC_EGGSHELL : BC_WHITE, type: ShadingType.CLEAR },
          margins: { top: 80, bottom: 80, left: 140, right: 140 },
          children: [para([run(value, { size: 20, color: BC_GRAPHITE })])]
        })
      ]
    }))
  });
}

// ── LOGO IMAGE RUN ─────────────────────────────────────────────────
// ImageRun transformation uses pixels at 96dpi (1 inch = 96px)
// Horizontal logo PNG: 3102 x 384px, aspect ratio = 384/3102
function logoImageRun(inches = 2.0) {
  const w = Math.round(inches * 96);
  const h = Math.round(w * (384 / 3102));
  return new ImageRun({ data: logoHorizontal, transformation: { width: w, height: h }, type: "png" });
}
function iconImageRun(inches = 0.22) {
  const px = Math.round(inches * 96);
  return new ImageRun({ data: logoIcon, transformation: { width: px, height: px }, type: "png" });
}

// ── DOCUMENT ───────────────────────────────────────────────────────
const doc = new Document({
  styles: {
    default: {
      document: { run: { font: "Arial", size: 22, color: BC_GRAPHITE } }
    },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 24, bold: true, font: "Arial", color: BC_GRAPHITE },
        paragraph: { spacing: { before: 360, after: 120 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 22, bold: true, font: "Arial", color: BC_BLUE },
        paragraph: { spacing: { before: 240, after: 80 }, outlineLevel: 1 } },
    ]
  },
  numbering: {
    config: [{
      reference: "bullets",
      levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 720, hanging: 360 } } } }]
    }]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1080, right: 1260, bottom: 1080, left: 1260 }
      }
    },

    // ── HEADER ──
    headers: {
      default: new Header({
        children: [
          new Paragraph({
            border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: BC_BLUE, space: 6 } },
            spacing: { before: 0, after: 120 },
            tabStops: [{ type: TabStopType.RIGHT, position: 9360 }],
            children: [
              logoImageRun(1.4),
              new TextRun({ text: "\t", size: 20 }),
              new TextRun({ text: "Audience Segment Report", font: "Arial", size: 18, color: "999999" })
            ]
          })
        ]
      })
    },

    // ── FOOTER ──
    footers: {
      default: new Footer({
        children: [
          new Paragraph({
            border: { top: { style: BorderStyle.SINGLE, size: 4, color: BC_BLUE, space: 6 } },
            spacing: { before: 100, after: 0 },
            tabStops: [{ type: TabStopType.RIGHT, position: 9360 }],
            children: [
              run("© Blue Contact  |  Confidential", { size: 18, color: "999999" }),
              new TextRun({ text: "\t", size: 18 }),
              run("Page ", { size: 18, color: "999999" }),
              new TextRun({ children: [PageNumber.CURRENT], font: "Arial", size: 18, color: "999999" }),
              run(" of ", { size: 18, color: "999999" }),
              new TextRun({ children: [PageNumber.TOTAL_PAGES], font: "Arial", size: 18, color: "999999" }),
            ]
          })
        ]
      })
    },

    children: [

      // ── TITLE BLOCK ──────────────────────────────────────────────
      new Paragraph({
        spacing: { before: 120, after: 0 },
        border: { bottom: { style: BorderStyle.SINGLE, size: 16, color: BC_BLUE, space: 8 } },
        children: [new TextRun({ text: "AUDIENCE SEGMENT REPORT", font: "Arial", size: 36, bold: true, color: BC_GRAPHITE, characterSpacing: 60 })]
      }),
      spacer(200),

      // Summary table
      summaryTable([
        ["Audience Name", "Building Products — VP+ Decision Makers, Southeast"],
        ["Created By",    "James"],
        ["Date",          new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })],
        ["Status",        "Draft — Pending Review"],
        ["Total Contacts","1,247  (update after query runs)"],
      ]),
      spacer(280),

      // ── SECTION 1 ────────────────────────────────────────────────
      h1("1.  Audience Purpose"),
      bodyPara("This section describes what this audience is meant to accomplish. Edit the purpose statement to reflect your actual campaign or outreach goal."),
      spacer(100),
      blueBox("Purpose Statement", [
        bodyPara("Target VP-level and above decision makers at building products companies in the Southeast United States for an outbound campaign introducing Blue Contact's data platform. Focus on contacts who are likely to influence or own technology purchasing decisions.", { italics: true }),
      ]),
      spacer(80),
      notePara("Edit the purpose statement above to reflect your actual goal. Claude reads this text to validate that the query logic matches your intent before running."),
      spacer(240),

      // ── SECTION 2 ────────────────────────────────────────────────
      h1("2.  Filter Criteria"),
      bodyPara("Each filter is explained in plain English below. Values shown in blue are editable — change them to adjust the audience targeting, then return the document to the audience owner."),
      spacer(140),

      h2("2.1  Industry"),
      filterTable([
        ["Filter Type",     "Industry classification match (OR logic across sub-industry columns)", false],
        ["Current Value",   "Building Materials, Construction Products, HVAC, Plumbing, Roofing, Windows & Doors", true],
        ["Columns Queried", "company_industries_name2 through name6 (all checked with OR conditions)", false],
        ["Priority Filter", "company_industries_activity_priority = 1  (primary industry only)", false],
      ]),
      spacer(80),
      notePara("To add or remove industries, edit the Current Value row. List them comma-separated. Claude will translate each into SQL OR conditions across name2–name6."),
      spacer(160),

      h2("2.2  Seniority / Title"),
      filterTable([
        ["Filter Type",   "Job title keyword match (OR logic, ILIKE)", false],
        ["Current Value", "VP, Vice President, SVP, EVP, C-Suite, Chief, President, Owner, Partner, Director", true],
        ["Column",        "contact_title", false],
        ["Logic",         "Inclusive — any title containing these keywords qualifies", false],
      ]),
      spacer(80),
      notePara("To narrow to C-Suite only, remove VP and Director. To expand, add titles like Manager or Head of. Separate with commas."),
      spacer(160),

      h2("2.3  Geography"),
      filterTable([
        ["Filter Type",   "State code match (IN list)", false],
        ["Current Value", "NC, SC, GA, VA, TN, FL", true],
        ["Column",        "company_state (headquarters state, not contact mailing address)", false],
        ["Logic",         "Inclusive — any company headquartered in these states qualifies", false],
      ]),
      spacer(80),
      notePara("Use 2-letter state codes only. To target a single state, leave just one code. To go national, delete all codes and note 'No geography filter'."),
      spacer(160),

      h2("2.4  Company Size"),
      filterTable([
        ["Filter Type",   "Employee count range", false],
        ["Min Employees", "50", true],
        ["Max Employees", "5,000", true],
        ["Column",        "company_employee_count", false],
      ]),
      spacer(80),
      notePara("Set Min to 0 to include all sizes above the Max. Leave a field blank to remove that bound entirely."),
      spacer(160),

      h2("2.5  Contact Quality"),
      filterTable([
        ["Email Required",    "Yes — contacts without email are excluded", true],
        ["Phone Required",    "No — phone not required", true],
        ["Suppression List",  "None applied", true],
        ["Dedupe Logic",      "One contact per company — highest seniority retained", true],
      ]),
      spacer(80),
      notePara("Set Email Required to No to include phone-only or LinkedIn-only contacts. Suppression list can reference a previously exported audience ID."),
      spacer(280),

      // ── SECTION 3 ────────────────────────────────────────────────
      h1("3.  Query Logic (Reference)"),
      bodyPara("This section shows the SQL pattern used to generate this audience. You do not need to edit this — Claude will regenerate the query automatically from your edits to Section 2."),
      spacer(100),
      blueBox("Query Pattern Summary", [
        bodyPara("SELECT COUNT(DISTINCT c.contact_id)", { font: "Courier New", size: 19, color: BC_GRAPHITE }),
        bodyPara("FROM lsc_data_catalog.business_db.contacts c", { font: "Courier New", size: 19 }),
        bodyPara("JOIN lsc_data_catalog.business_db.companies co ON c.company_id = co.company_id", { font: "Courier New", size: 19 }),
        bodyPara("JOIN lsc_data_catalog.business_db.companies_company_industries cci ON co.company_id = cci.company_id", { font: "Courier New", size: 19 }),
        bodyPara("JOIN lsc_data_catalog.business_db.company_industries ci ON cci.company_industry_id = ci.company_industry_id", { font: "Courier New", size: 19 }),
        bodyPara("WHERE ci.company_industries_activity_priority = 1", { font: "Courier New", size: 19 }),
        bodyPara("AND (ci.company_industries_name2 ILIKE '%Building Materials%' OR ... [name3–name6])", { font: "Courier New", size: 19 }),
        bodyPara("AND (c.contact_title ILIKE '%VP%' OR c.contact_title ILIKE '%Chief%' OR ...)", { font: "Courier New", size: 19 }),
        bodyPara("AND co.company_state IN ('NC','SC','GA','VA','TN','FL')", { font: "Courier New", size: 19 }),
        bodyPara("AND co.company_employee_count BETWEEN 50 AND 5000", { font: "Courier New", size: 19 }),
        bodyPara("AND c.contact_email IS NOT NULL", { font: "Courier New", size: 19 }),
        spacer(40),
        notePara("Three-part fully qualified table path (lsc_data_catalog.business_db.table_name) is required by AWS Athena. Do not alter table names."),
      ]),
      spacer(280),

      // ── SECTION 4 ────────────────────────────────────────────────
      h1("4.  Reviewer Notes"),
      bodyPara("Use this section to leave feedback, request changes, or flag questions before returning the document to the audience owner."),
      spacer(100),
      blueBox("Feedback & Requested Changes", [
        bodyPara("[Leave your notes here — e.g. 'Remove FL, add TX' or 'Expand to Director level' or 'Also include phone-only contacts']", { italics: true, color: "888888" }),
        spacer(40),
        bodyPara("[Add any additional comments or questions here]", { italics: true, color: "888888" }),
        spacer(120),
      ]),
      spacer(280),

      // ── SECTION 5 ────────────────────────────────────────────────
      h1("5.  How to Submit Edits"),
      bodyPara("Once you have made your changes to Sections 2 and 4, save the document and return it to the audience owner. They will drop it into their Claude Cowork session using the prompt below."),
      spacer(100),
      blueBox("Cowork Re-ingestion Prompt", [
        bodyPara("\"I've attached an updated audience report. Please read the Filter Criteria in Section 2 and the Reviewer Notes in Section 4, then update the Blue Contact audience query to reflect all requested changes. Run the updated count query first and confirm the new total before saving the audience.\"", { italics: true, color: BC_GRAPHITE }),
        spacer(40),
        notePara("Claude will read all blue-marked editable fields in Section 2 and any notes in Section 4, then regenerate and run the SQL automatically in Cowork."),
        spacer(40),
      ]),
    ]
  }]
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync('/home/claude/BlueContact_Audience_Report_Branded.docx', buf);
  console.log('done');
});
