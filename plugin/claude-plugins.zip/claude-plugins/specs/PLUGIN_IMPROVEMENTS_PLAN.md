# Blue Contact Plugin — Implementation Plan

*Plan date: 2026-04-21*
*Source: specs/PLUGIN_IMPROVEMENT_SUGGESTIONS.md (2026-04-07)*
*Target plugin version: 0.2.0*

This plan translates the seven improvement suggestions into an ordered, file-by-file implementation blueprint. It is organized into four phases so that each phase is shippable on its own and earlier phases unblock later ones (for example, the reference-file restructure in Phase 1 is reused by the new skills in Phase 3).

---

## Phase 0 — Setup and getting-started skills reflect the real schema

Before touching anything else we upgrade two skills so they describe the user's *actual* access, not a hardcoded baseline. This has two tracks — (A) connector detection, (B) schema-driven capability presentation — that ship together.

### 0A. Setup skill hardens the connector check

Upgrade `setup` so it actively detects whether the Blue Contact MCP connector is enabled and connected, and guides the user to enable it if not. This unblocks every other improvement — hooks, agents, reference files, new skills — by guaranteeing the MCP server is reachable when they run.

### Current state

`skills/setup/SKILL.md` (33 lines) only instructs Claude to "verify the Blue Contact MCP connection is active." There is no explicit detection, no enable flow, and no reference to the `.mcp.json` or Cowork connector UI.

### Target state

The setup skill performs a three-state detection with a scripted remediation path for each state. It runs before any `getting-started` handoff and before any skill that calls a Blue Contact tool.

#### Detection logic (new step 1 in `skills/setup/SKILL.md`)

1. Attempt a lightweight probe: call `get_schema` with no parameters.
2. Classify the outcome into one of three states:
   - **Connected** — response returns database list. Proceed to step 2 of the existing flow (catalogs confirmation).
   - **Connector missing** — tool is not available in the session (`blue-contact:get_schema` is not listed). The connector has not been installed/enabled.
   - **Connector present but unauthenticated** — tool call returns a 401 / auth error / "not authenticated" message. The connector is enabled but OAuth has not been completed.

#### Remediation flows

For **Connector missing**, the skill walks the user through:
- Opening **Settings → Connectors** in Cowork (or `/mcp` in Claude Code).
- Adding the Blue Contact HTTP connector with URL `https://query.bluecontact.com/mcp` (this matches the plugin's `.mcp.json`).
- Confirming the connector appears as "Enabled."
- Re-running `/blue-contact:setup` to continue.

For **Connector present but unauthenticated**, the skill walks the user through:
- Clicking the Blue Contact connector in the Connectors panel.
- Completing the OAuth 2.1 bearer-token sign-in at `auth.bluecontact.com`.
- Re-running `get_schema` to verify.

Each remediation path uses `AskUserQuestion` to offer a retry loop: **"I've enabled it — retry"** vs. **"I'll do this later."**

#### Acceptance criteria
- Running `/blue-contact:setup` on a fresh install with no connector configured results in a clear, scripted path to enabling and authenticating the connector — no guesswork.
- Running `/blue-contact:setup` on a working install reaches the `getting-started` handoff in under three tool calls.
- The new flow is documented in `specs/PLUGIN_IMPROVEMENTS_PLAN.md` (this file) and referenced from `README.md`.

### Files touched
- `skills/setup/SKILL.md` — rewrite step 1 as the three-state detector, add remediation sub-flows, rework step 2 per 0B below, keep steps 3-6 largely intact.
- `README.md` — add a one-line note that the plugin requires the Blue Contact connector to be enabled, pointing to `/blue-contact:setup`.

### 0B. Skills describe only the databases the user actually has — and never mention catalogs

**Problem.** Two separate issues:

*Issue 1 — hardcoded database lists.* Both `setup` and `getting-started` contain hardcoded content that assumes the user has every Blue Contact database:

- `skills/setup/SKILL.md` step 2 asserts "Blue Contact exposes two Athena catalogs: `AwsDataCatalog` … and `lsc_data_catalog` …" *before* any schema call.
- `skills/getting-started/SKILL.md` Phase 1 step 2 has a fixed five-bullet capability list. Phase 2 presents a static menu. Phase 3 has topic walkthroughs for each. Phase 4 recommends slash commands that only make sense against certain databases. The instruction says "include only those relevant to the user's available databases," but nothing enforces it.

*Issue 2 — catalogs leak as a user-facing concept.* Athena's fully-qualified `catalog.database.table` syntax is an SQL mechanic that users don't need to know about, but the skills currently surface it in prose:

- `skills/setup/SKILL.md` step 2 — explains both catalogs by name.
- `skills/getting-started/SKILL.md` line 67 — appends `(lsc_data_catalog)` to the Dealership bullet.
- `skills/getting-started/SKILL.md` line 106 — "Explain the difference between the catalogs (AwsDataCatalog vs lsc_data_catalog)" inside the Explore-your-data walkthrough.
- `skills/audience-logic-report/SKILL.md` line 64 — "Which catalog/database/tables and why" in the Data source selection section of a *user-shareable* logic report.
- `skills/data-querying/SKILL.md` lines 31-33 — "Two catalogs: `AwsDataCatalog` … and `lsc_data_catalog` …" in the Claude-facing conventions list; this prompts Claude to explain catalogs to users when the topic comes up.

**Target state.**

Every user-visible list of databases, capability areas, menu items, topic walkthroughs, and suggested follow-up commands is generated from the live `get_schema` summary for that session — no hardcoded names.

The word "catalog" is never spoken to the user. The SQL produced by Claude still uses fully-qualified `catalog.database.table` notation because Athena requires it; that stays as an internal SQL-writing mechanic in `data-querying` only, framed as "how to spell a table name," not as a concept users need to understand.

#### Changes to `skills/setup/SKILL.md`

- Step 2 becomes: "Call `get_schema` with no parameters. Read the `databases` array out of the response. Summarize the databases *the user* has access to — one sentence per database, no catalog names." Remove the hardcoded `AwsDataCatalog`/`lsc_data_catalog` descriptions entirely. The concept of a catalog is not mentioned.
- Step 4 already uses `get_schema` correctly; keep it, but make it explicit that the enumeration in step 2 is the source of truth for what databases to probe in step 4.

#### Changes to `skills/getting-started/SKILL.md`

- **Phase 1 step 2:** Replace the hardcoded five-bullet capability list with an instruction to derive capability labels from the schema. Introduce a database-to-capability mapping table *inside the skill* (e.g., `consumer` → "Consumer data", `business`/`b2b` → "B2B data", `mover` → "Mover data", `property` → "Property data", `dealership` → "Dealership data"). Claude iterates the schema's `databases` array and emits only the bullets that match. If a database is present that doesn't fit a known label, emit a generic "Other: <name>" line rather than inventing copy. The `(lsc_data_catalog)` parenthetical on the Dealership line is removed.
- **Phase 2 menu:** Make the enforcement explicit. The skill must construct the menu options array programmatically from the available-capabilities set from Phase 1, and pass it to `AskUserQuestion`. Call out that presenting a menu item for data the user doesn't have is a bug, not a style choice.
- **Phase 3 guided exploration:** The topic walkthroughs stay as written (they're the "what to do if the user picks X" branches), but two changes: (a) add a guard at the top — "If the user's session has no database matching this topic, do not run the walkthrough — return to Phase 2 with an apology." (b) delete the bullet that says "Explain the difference between the catalogs (AwsDataCatalog vs lsc_data_catalog)" from the Explore-your-data walkthrough. Replace it with "Show the user which databases they have and what each is good for."
- **Phase 4 what's-next:** The slash-command list gets a per-command applicability rule. `/blue-contact:industry-playbooks` is only mentioned if at least one supported vertical's backing database is present. `/blue-contact:market-sizing`, `/blue-contact:audience-compare`, etc. are always applicable. Encode this as a small table in the skill rather than a prose list.

#### Changes to `skills/audience-logic-report/SKILL.md`

- Line 64: "Step 1 — Data source selection: Which catalog/database/tables and why" → "Step 1 — Data source selection: Which database and tables and why. Explain the JOIN chain." The logic report is shared with the user's QA team; removing "catalog" here keeps the surface consistent with the rest of the plugin.
- The actual SQL blocks (lines 81-89, 200) are *real SQL output* that has to round-trip back into the MCP tool, so they keep the fully-qualified `catalog.database.table` form. The prose describing them stops saying "catalog."

#### Changes to `skills/data-querying/SKILL.md`

This skill is Claude-facing, not user-facing, but its guidance shapes what Claude says to users. Current lines 31-33:

```
- Two catalogs: `AwsDataCatalog` (consumer/B2B/mover/property) and `lsc_data_catalog` (dealership)
- Tables are fully qualified as `catalog.database.table_name` in queries
- Multi-table joins across catalogs are supported
```

Replace with an internal-only mechanics note under a new "SQL-writing mechanics (do not surface to users)" heading:

```
- Blue Contact tables live across two Athena catalogs. Spell every table as `<catalog>.<database>.<table>` in generated SQL — the schema response tells you which catalog a database belongs to.
- Joins across catalogs are supported.
- Never mention the catalog concept or catalog names to the user. Talk about databases only.
```

This keeps Claude producing valid SQL without leaking catalog as a user concept.

#### Acceptance criteria

- A search for `catalog|AwsDataCatalog|lsc_data_catalog` in every user-facing section of every skill returns zero hits. The only surviving mentions are (a) the internal mechanics block in `data-querying`, (b) the fully-qualified SQL strings in `audience-logic-report` examples and SQL template placeholders in `audience-building`, `market-sizing`, `data-health`, `audience-monitor`.
- Running `/blue-contact:setup` on any access profile never prints the strings `AwsDataCatalog`, `lsc_data_catalog`, or the word "catalog" to the user.
- Running `/blue-contact:getting-started` on a token granting only the consumer database shows exactly one capability bullet, one menu option, and zero references to mover/property/dealership data, and zero mentions of catalogs.
- A regression test / manual dry-run exercises at least three access profiles: (a) consumer only, (b) consumer + property, (c) full access. No leakage of un-granted databases or of the catalog concept in any.

#### Files touched
- `skills/setup/SKILL.md` — step 2 rewrite; catalog concept removed.
- `skills/getting-started/SKILL.md` — Phase 1, 2, 4 rewrites; Phase 3 guard + catalog-mention deletion.
- `skills/audience-logic-report/SKILL.md` — line 64 rewrite; SQL examples unchanged.
- `skills/data-querying/SKILL.md` — lines 31-33 replaced with internal mechanics block.

---

## Phase 1 — Hooks + reference-file restructuring (highest impact, lowest effort)

### 1A. Hooks (`hooks/hooks.json`)

Create the directory and a single `hooks.json` manifest. Three hooks, each scoped narrowly to avoid surprising the user.

#### `SessionStart` hook

Purpose: silent connectivity probe so users don't need to manually run `/blue-contact:setup` on every session.

Behavior: on session start, if the `blue-contact` MCP connector is not connected or not authenticated, emit a *short* notice: "Blue Contact connector isn't connected — run `/blue-contact:setup` to fix." Do not block, do not repeat. If the probe succeeds, stay silent.

Implementation: a shell script at `hooks/session-start.sh` that inspects the MCP session state and prints the notice to stdout. Hook type: `SessionStart`.

#### `PostToolUse` hook on `run_audience_query`

Purpose: enforce the audience-pull best practices even when no skill is loaded.

Behavior: after every successful `run_audience_query` call, emit a reminder to Claude (as a hook output) to (a) check contact coverage (phone/email append rates) and (b) share the audience's download URL with the user. This mirrors the guidance in the `data-analyst` agent and the `audience-pull` skill but applies universally.

Implementation: `hooks/post-run-audience-query.sh` with a matcher restricting it to the `blue-contact:run_audience_query` tool.

#### `PreToolUse` hook on `execute_sql_query`

Purpose: guardrail against raw SQL when `run_audience_query` would be more appropriate.

Behavior: before every `execute_sql_query` call, emit a reminder: "Raw SQL execution doesn't persist audiences or track billing. If this query is meant to build an audience, use `run_audience_query` instead." Non-blocking.

Implementation: `hooks/pre-execute-sql.sh` with a matcher restricting it to `blue-contact:execute_sql_query`.

#### Files created
- `hooks/hooks.json`
- `hooks/session-start.sh`
- `hooks/post-run-audience-query.sh`
- `hooks/pre-execute-sql.sh`

#### Acceptance criteria
- `/plugins` shows the three hooks registered under the Blue Contact plugin.
- A fresh session with a broken connector prints the SessionStart notice exactly once.
- Calling `run_audience_query` without the `audience-pull` skill still surfaces the coverage + download reminder.
- Calling `execute_sql_query` surfaces the raw-SQL guardrail.

### 1B. Reference-file restructuring (`references/`)

Two skills are oversized and better served by progressive disclosure:

#### `industry-playbooks` (182 lines → ~40 lines SKILL.md + 8 reference files)

Move each vertical playbook into its own reference file. SKILL.md becomes a thin router.

New layout:
```
skills/industry-playbooks/
├── SKILL.md                              (routing + playbook list)
└── references/
    ├── real-estate.md
    ├── automotive.md
    ├── insurance.md
    ├── home-services.md
    ├── financial-services.md
    ├── healthcare-wellness.md
    ├── moving-services.md
    └── retail-ecommerce.md
```

SKILL.md instructs Claude to call `AskUserQuestion` for industry selection, then **load only the selected reference file** before running the playbook. This keeps the skill-loading footprint roughly 75% smaller.

#### `data-querying` (49 lines → split into focused references)

Currently small, but the referenced content (SQL conventions, catalog guide, field-type rules) is expected to grow as more data sources are added. Pre-empt by splitting now:

```
skills/data-querying/
├── SKILL.md                          (tool list + when to call each reference)
└── references/
    ├── sql-conventions.md            (Presto/Trino dialect, booleans, categoricals, normalization)
    ├── catalog-guide.md              (AwsDataCatalog vs lsc_data_catalog, table naming)
    └── field-types.md                (how to handle the typed fields the schema returns)
```

SKILL.md stays as the "what tools exist + when to reach for which reference" entry point.

#### Acceptance criteria
- Each SKILL.md under 60 lines.
- Each reference file is self-contained (can be loaded alone and still make sense).
- No content is lost relative to the current SKILL.md files — a diff-and-verify step is part of implementation.

---

## Phase 2 — Additional agents + example files

### 2A. `agents/report-builder.md` (model: sonnet)

A second agent, aimed at turning `audience-report` from a guided interactive skill into an autonomous background task. It takes an `audience_id` as input, gathers the data, builds visualizations using the brand tokens in `brand/brand.json`, and produces a PPTX or PDF deliverable end-to-end without intermediate user prompts.

Tools granted:
- All `blue-contact:*` tools the `data-analyst` has.
- File-creation tools (Read, Write, Edit) for generating the report assets.
- Bash (needed by the `pptx`/`pdf` skills).

The agent prompt instructs it to:
1. Load the brand guide (`brand/BRAND.md` + `brand/brand.json`).
2. Pull audience detail via `get_audience`.
3. Run coverage and demographic breakdown queries via `execute_sql_query`.
4. Invoke the `audience-report` skill's rendering conventions (reference the existing `generate_branded_report.js` in `specs/`).
5. Return a single file path to the finished deliverable.

### 2B. `agents/data-monitor.md` (model: haiku)

A lightweight agent for scheduled monitoring tasks (via `audience-monitor`). Designed to run unattended on cron — fetches the audience, re-runs the count query, diffs against the previous run, flags anomalies, and optionally writes a short summary. No loading of the full skill context.

Tools granted: `get_audience`, `execute_sql_query`, `run_audience_query` (for re-running with `audience_id`), `save_message`. No file tools — output goes into the audience conversation history.

### 2C. Example files

Add an `examples/` subdirectory to the skills that would benefit most:

```
skills/audience-pull/examples/
├── consumer-homeowners.sql
├── b2b-financial-services.sql
└── recent-movers-by-destination.sql

skills/audience-report/examples/
├── dashboard-data.json
└── branded-report-structure.md      (mirrors the .docx in specs/)
```

Each example is pulled verbatim from a real Blue Contact query pattern so Claude can adapt them on the fly instead of writing from scratch.

### Acceptance criteria
- Both new agent files validate against the existing agent schema (`data-analyst.md` is the reference).
- Invoking the `report-builder` agent with a real `audience_id` produces a file in `outputs/`.
- `audience-monitor` scheduled tasks now delegate to the `data-monitor` agent rather than running in the main thread.

---

## Phase 3 — New skills (fill content gaps)

### 3A. `skills/data-dictionary/SKILL.md`

Bridges the gap between SQL mechanics (handled by `data-querying`) and institutional knowledge about what the data means. Scope:

- Field-level definitions for the most-asked-about columns (e.g., what "homeowner probability" represents, how mover dates are computed).
- Data freshness expectations per database (weekly, monthly, quarterly).
- Coverage benchmarks by geography (e.g., typical email append rate in rural zips vs. urban DMAs).
- Known data quirks (missing Alaska dealership records, Hawaii property value skew, etc.).

Structure: thin SKILL.md + `references/` with one file per database (consumer, b2b, mover, property, dealership).

Trigger: "what does this field mean", "how fresh is this data", "why is coverage low in X."

### 3B. `skills/export-integrations/SKILL.md` — deferred (depends on server S3.3)

Originally scoped to cover pushing audiences to downstream destinations (SFMC, HubSpot, CSV). Deferred because the corresponding MCP-level integrations (S3.3 in the server spec) don't exist yet — shipping format-spec content alone would create the impression of an automated push the plugin can't actually perform.

The dependency is explicit: build server-side push tools first (S3.3 promoted from "Deferred" to a real candidate in `bluequeryai/specs/blue-contact-plugin-v02-server-spec.md`), then come back and write `export-integrations` against real tools rather than format specs alone.

When 3B is reactivated:

- Scope per destination: Salesforce Marketing Cloud (Data Extension format, field mapping, deduplication keys), HubSpot (list format, required fields, suppression handling), CSV export conventions (header naming, encoding, PII redaction options).
- Structure: SKILL.md as router + `references/salesforce-mc.md`, `references/hubspot.md`, `references/csv-export.md`.
- Trigger: "push this audience to [platform]", "export to [platform]", "what format does [platform] need."

### Acceptance criteria (Phase 3, applied to 3A only while 3B is deferred)
- Each new skill is under 80 lines in SKILL.md with the heavy content in `references/`.
- Each is auto-discoverable via the standard plugin layout (no manual marketplace registration needed for skills).
- Each has at least one example query and one example output.

---

## Phase S — Supporting server changes in `bluequeryai`

A review of the MCP server surfaced one clear performance issue and several targeted changes that make specific plugin phases simpler, faster, or more correct. The full server-side spec lives in the server repo so it can be implemented on its own PR flow:

**See: `bluequeryai/specs/blue-contact-plugin-v02-server-spec.md`**

That document is self-contained — a Rails developer doesn't need to read this plugin plan to pick it up. It enumerates each change with file paths, code sketches, acceptance criteria, and a sequencing section.

Summary table of what the server spec covers and which plugin phase consumes each item:

| ID | Server change | Required / Recommended | Plugin phase consuming it |
|---|---|---|---|
| S-R1 | Refactor scoping to use `account.database_definitions` instead of `database_names` | **Prerequisite cleanup** | Fixes latent `[name, datasource]` bug; unblocks cleaner S0.1 / S1.1 / S1.2 |
| S0.1 | Fix `GetSchema.database_summary` over-fetch + cache | Recommended | Phase 1 `SessionStart` hook |
| S0.2 | Stable JSON 401 shape on MCP endpoint | **Required** | Phase 0A connector detector |
| S0.3 | Lightweight `ping` MCP tool | Recommended | Phase 1 `SessionStart` hook |
| S1.1 | `category` column on `database_definitions` | Recommended | Phase 0B capability mapping |
| S1.2 | Surface `display_name` in schema summary | Required if S1.1 | Phase 0B |
| S2.1 | `coverage_summary` in `run_audience_query` response | Recommended | Phase 1 `PostToolUse` hook |
| S2.2 | `suggestion` hint on `execute_sql_query` response | Optional | Phase 1 `PreToolUse` hook |
| S3.1 | `data_freshness` columns on `database_definitions` | Recommended | Phase 3 `data-dictionary` |
| S3.2 | `get_coverage_benchmarks` tool | Optional | Phase 3 `data-dictionary` |
| S3.3 | Server-side push tools (SFMC + HubSpot) | **Promoted from Deferred** | Phase 3B `export-integrations` (currently deferred pending S3.3) |

### Coordination between the two specs

- **S-R1** is a prerequisite server cleanup: it ships first and alone, independent of any plugin work. It fixes a latent entitlement bug and simplifies the server code that S0.1, S1.1, and S1.2 build on.
- After S-R1, only one server change is *required* to unblock plugin work: **S0.2** (stable 401 shape), which gates Phase 0A's connector detector.
- All other server items are additive and backwards-compatible, so server and plugin work can proceed in parallel once S0.2 ships.
- When a plugin phase starts implementation, cross-reference the corresponding server-spec section to decide whether to wait for the server change or ship the plugin phase with its fallback path first and upgrade later. Both specs are written to support either order.

---

## Phase 4 — CONNECTORS.md (future)

Deferred. Low priority while the plugin is tightly coupled to the Blue Contact MCP server. The placeholder pattern (`~~data platform~~`) is noted here so that when a second provider is added we know where the customization surface lives.

### Trigger for re-activation
- A second Blue-Contact-like data provider is contemplated, OR
- A customer asks to rebrand the plugin.

### Scope when triggered
- Extract provider-specific strings (URL, product name, brand colors) into `CONNECTORS.md`.
- Introduce `~~~placeholder~~~` tokens in SKILL.md files.
- Document customization via the `cowork-plugin-management:cowork-plugin-customizer` skill.

---

## Rollout & sequencing

The four phases can ship as separate minor versions:

| Phase | Version | Scope | Risk |
|---|---|---|---|
| Phase 0 | 0.1.1 | Setup connector detection + schema-driven capability presentation in setup & getting-started | Low — content only |
| Phase 1 | 0.2.0 | Hooks + reference restructure | Medium — hooks are new surface |
| Phase 2 | 0.3.0 | Two new agents + examples | Low — additive |
| Phase 3 | 0.4.0 | `data-dictionary` skill (`export-integrations` deferred — depends on S3.3) | Low — additive |
| Phase 4 | later | CONNECTORS.md | Deferred |
| Phase S | paired with 0, 1, 3 | Supporting server changes in `bluequeryai` | See Phase S table |

Within each phase, the order of work is top-to-bottom as written above. No phase blocks on a later phase.

## Verification

Each phase closes with a verification step:

- **Phase 0:** (0A) fresh-install dry run with the connector disabled; confirm the scripted remediation path works. (0B) run setup and getting-started against at least three access profiles (consumer only; consumer + property; full access) and confirm no reference to un-granted databases appears in either skill's output, and the word "catalog" never appears in user-facing responses.
- **Phase 1:** hook matrix — enable each hook in isolation, verify trigger + output; then enable all three and confirm no double-fires.
- **Phase 2:** end-to-end agent invocation on a real `audience_id` (report-builder) and a mock scheduled run (data-monitor).
- **Phase 3:** trigger-phrase eval — confirm the new skills fire on the intended prompts and don't over-trigger on existing ones.

## Open questions for the maintainer

1. Should the `SessionStart` hook run on *every* session, or only when a Blue-Contact-related skill or tool is invoked? (Leaning toward every session, with silent success.)
2. Is there appetite for moving `data-analyst`'s tool list into a shared `tools.json` so that `report-builder` and `data-monitor` can reuse it without duplication?
3. For Phase 3, which destinations should ship first in `export-integrations` — SFMC + HubSpot, or something else Blue Contact customers ask for more?
