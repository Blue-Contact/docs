# Blue Contact Plugin — Improvement Suggestions

*Generated April 7, 2026 — based on a review of the plugin against full CoWork plugin capabilities.*

---

## 1. Add Hooks (`hooks/hooks.json`)

Currently missing entirely. Three recommended hooks:

### SessionStart Hook
Auto-verify MCP connectivity and greet user with available databases. Eliminates the need for users to manually run `/blue-contact:setup`.

### PostToolUse Hook on `run_audience_query`
Enforce best practices automatically — ensure Claude always checks contact coverage and shares the download URL after every audience pull, even when skills aren't loaded.

### PreToolUse Hook on `execute_sql_query`
Warn when raw SQL is used instead of `run_audience_query` (which handles persistence and billing). Acts as a guardrail.

---

## 2. Add Reference Files for Progressive Disclosure

No skills currently use `references/` subdirectories. Candidates:

### `industry-playbooks`
Split each of the 7 verticals (real estate, automotive, insurance, home services, financial services, moving, healthcare) into separate reference files. Keeps SKILL.md lean; Claude loads only the relevant playbook.

### `data-querying`
Move SQL conventions, field type rules, and catalog details to `references/sql-conventions.md` and `references/catalog-guide.md`.

---

## 3. Additional Agents

Currently only one agent (`data-analyst`). Two recommended additions:

### `report-builder` (model: sonnet)
Autonomously gathers data, builds visualizations, and generates PPTX/PDF reports end-to-end. Converts `audience-report` from a guided skill into an autonomous background task.

### `data-monitor` (model: haiku)
Lightweight agent for `audience-monitor` scheduled tasks. Runs unattended on cron — handles check queries, result comparison, and anomaly flagging without loading full skill context.

---

## 4. Example Files

No skills include `examples/` directories. Recommended additions:

- Sample audience queries: `examples/consumer-homeowners.sql`, `examples/b2b-financial-services.sql`
- Sample React dashboard data: `examples/dashboard-data.json`
- Sample brand-compliant report structure for the report-builder

---

## 5. New Skill: `data-dictionary`

A dedicated skill for explaining what the data means — field definitions, data freshness expectations, coverage benchmarks by geography, and known data quirks. Bridges the gap between SQL mechanics (covered by `data-querying`) and institutional data knowledge.

---

## 6. New Skill: `export-integrations`

Covers the specifics of pushing audiences to destinations: Salesforce Marketing Cloud, HubSpot, field mapping conventions, suppression list handling, formatting requirements per platform.

---

## 7. CONNECTORS.md (Future)

If the plugin is ever adapted for other data providers, a `CONNECTORS.md` with `~~data platform` placeholders would enable customization. Low priority while tightly coupled to Blue Contact's MCP server.

---

## Priority Order

1. **Hooks** + **Reference file restructuring** — highest impact, lowest effort
2. **Additional agents** + **Example files** — meaningful UX improvement
3. **New skills** (data-dictionary, export-integrations) — fills content gaps
4. **CONNECTORS.md** — future consideration
