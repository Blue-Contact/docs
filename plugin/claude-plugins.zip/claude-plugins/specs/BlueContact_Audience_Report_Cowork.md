# Blue Contact — Audience Report Generator (Cowork Briefing)

## What We Built

A branded Word doc template for sharing Blue Contact audience segments with team members for review and approval. The workflow solves the problem that Cowork sessions can't be shared directly with teammates.

---

## The Collaboration Workflow

1. **You generate** an audience report doc in Cowork (using this briefing + the generator script below)
2. **You share** the `.docx` via chat snapshot or email to a teammate
3. **Teammate edits** the blue-marked fields in Section 2 and leaves notes in Section 4
4. **Teammate returns** the edited doc to you
5. **You drop it back** into Cowork and say:

> *"I've attached an updated audience report. Please read the Filter Criteria in Section 2 and the Reviewer Notes in Section 4, then update the Blue Contact audience query to reflect all requested changes. Run the updated count query first and confirm the new total before saving the audience."*

---

## Document Structure

The generated `.docx` has 5 sections:

| Section | Purpose | Editable by reviewer? |
|---|---|---|
| 1. Audience Purpose | Plain-English goal statement | Yes |
| 2. Filter Criteria | All targeting filters with editable values in blue | Yes — primary edit surface |
| 3. Query Logic | Reference SQL pattern | No |
| 4. Reviewer Notes | Freeform feedback area | Yes |
| 5. How to Submit Edits | Cowork re-ingestion prompt | No |

---

## Filter Criteria Fields (Section 2)

Each sub-section maps directly to a SQL clause. When you read an edited doc back in, translate each field as follows:

### 2.1 Industry
- **Column pattern:** `ci.company_industries_name2` through `name6` with `OR` conditions + `ILIKE '%value%'`
- **Priority filter:** always include `ci.company_industries_activity_priority = 1`
- **JOIN required:** `companies_company_industries` → `company_industries`

### 2.2 Seniority / Title
- **Column:** `c.contact_title ILIKE '%value%'`
- **Logic:** OR across all listed title keywords

### 2.3 Geography
- **Column:** `co.company_state IN ('XX','XX',...)`
- **If blank/removed:** drop the state filter entirely

### 2.4 Company Size
- **Column:** `co.company_employee_count BETWEEN min AND max`
- **If one bound is blank:** use `>=` or `<=` instead of BETWEEN

### 2.5 Contact Quality
- **Email required:** `AND c.contact_email IS NOT NULL`
- **Phone required:** `AND c.contact_phone IS NOT NULL`
- **Suppression:** `AND c.contact_id NOT IN (SELECT contact_id FROM audience_[id])`
- **Dedupe:** handled post-query or via ROW_NUMBER() window function

---

## SQL Query Pattern

```sql
SELECT COUNT(DISTINCT c.contact_id)
FROM lsc_data_catalog.business_db.contacts c
JOIN lsc_data_catalog.business_db.companies co 
  ON c.company_id = co.company_id
JOIN lsc_data_catalog.business_db.companies_company_industries cci 
  ON co.company_id = cci.company_id
JOIN lsc_data_catalog.business_db.company_industries ci 
  ON cci.company_industry_id = ci.company_industry_id
WHERE ci.company_industries_activity_priority = 1
  AND (
    ci.company_industries_name2 ILIKE '%Building Materials%' OR
    ci.company_industries_name3 ILIKE '%Building Materials%' OR
    ci.company_industries_name4 ILIKE '%Building Materials%' OR
    ci.company_industries_name5 ILIKE '%Building Materials%' OR
    ci.company_industries_name6 ILIKE '%Building Materials%'
    -- repeat OR block for each industry in the list
  )
  AND (
    c.contact_title ILIKE '%VP%' OR
    c.contact_title ILIKE '%Chief%'
    -- repeat for each title keyword
  )
  AND co.company_state IN ('NC','SC','GA','VA','TN','FL')
  AND co.company_employee_count BETWEEN 50 AND 5000
  AND c.contact_email IS NOT NULL
```

> **Important:** Always use the three-part fully qualified path `lsc_data_catalog.business_db.table_name` — required by AWS Athena.

---

## Generating the Word Doc

The generator script is at `/home/claude/generate_branded_report.js` (or recreate from the code below).

To generate a report for a new audience, update these values at the top of the summary table section:

- **Audience Name** — descriptive name for the segment
- **Created By** — your name
- **Status** — Draft / Active / Archived
- **Total Contacts** — run the count query first, then fill in

Brand assets required (embed as PNG before running):
- `logo_horizontal.png` — converted from `Blue_Contact_Horizontal_Blue.svg` at 3x scale
- `logo_icon.png` — converted from `Blue_Contact_Icon_Blue.svg` at 2x scale

---

## Brand Reference

| Element | Value |
|---|---|
| Primary blue | `#006AFF` |
| Graphite (text) | `#2A3A57` |
| Eggshell (bg tint) | `#E4E9F5` |
| Seafoam (accent) | `#12C7B4` |
| Body font | Arial (FF Clan substitute for Word) |
| Editable values | Shown in Contact Blue `#006AFF` with `← editable` label |

---

## Files

| File | Description |
|---|---|
| `BlueContact_Audience_Report_Branded.docx` | The branded template — ready to use |
| `generate_branded_report.js` | Node.js generator script |
| `Blue_Contact_Horizontal_Blue.svg` | Source logo |
| `Blue_Contact_Icon_Blue.svg` | Source icon |
| `Blue_Contact_Brand_Guidelines_v1.pdf` | Full brand guidelines |
