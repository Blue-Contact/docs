![Blue Contact](logo.svg)

# Blue Contact Plugin for Claude Code & Cowork

Query consumer, B2B, mover, property, and dealership data through natural language. Build targeted audiences, generate reports, visualize data, and analyze demographics — all without writing SQL. Upload your own lists, match them against the Blue Contact library, and turn any audience into data-driven personas you can score prospects against.

## What's included

- **MCP Connection** to Blue Contact's data platform (`query.bluecontact.com/mcp`)
- **14 skills** covering onboarding, data querying, audience building, reporting, market sizing, industry playbooks, monitoring, audience-logic QA, uploads & matching, personas & scoring, and a data dictionary — each invocable as a slash command (`/blue-contact:<skill>`)
- **Sub-agents** `data-analyst` (multi-step analysis), `data-monitor` (scheduled audience checks), and `report-builder` (autonomous PPTX/PDF generation)
- **Interactive visualizations** — React-based dashboards and charts built from your data in real time

## Skills

| Skill | Command | Description |
|-------|---------|-------------|
| Getting Started | `/blue-contact:getting-started` | Interactive guided tour — discovers your data and walks you through it with live visualizations |
| Setup | `/blue-contact:setup` | Connection and configuration troubleshooting |
| Data Querying | *Automatic* | Domain knowledge for querying all Blue Contact datasets — activates when you ask data questions |
| Audience Building | *Automatic* | Structured workflow for building targeted marketing audiences — activates when you describe an audience |
| Audience Pull | `/blue-contact:audience-pull` | Quick audience builds from a one-line description |
| Audience Report | `/blue-contact:audience-report` | Generate polished PPTX or PDF reports from an audience |
| Audience Compare | `/blue-contact:audience-compare` | Side-by-side comparison of two audiences with difference analysis |
| Market Sizing | `/blue-contact:market-sizing` | Size a target market with TAM analysis, breakdowns, and a market opportunity dashboard |
| Industry Playbooks | `/blue-contact:industry-playbooks` | Pre-built audience recipes for real estate, automotive, insurance, home services, and more |
| Audience Monitor | `/blue-contact:audience-monitor` | Scheduled monitoring for audience count changes, coverage trends, and alerts |
| Audience Logic Report | `/blue-contact:audience-logic-report` | Save the exact logic behind an audience as a shareable doc your team can QA — they flag changes and the query updates automatically |
| My Data | `/blue-contact:my-data` | Upload your own files as queryable tables, match them against the Blue Contact library, run quality checks, and manage retention |
| Personas | `/blue-contact:personas` | Segment any audience or uploaded list into data-driven personas, then score prospect universes against them |
| Data Dictionary | `/blue-contact:data-dictionary` | Field definitions, data freshness, coverage benchmarks, and known quirks per database |

## Installation

The plugin requires the Blue Contact MCP connector to be enabled and authenticated. Run `/blue-contact:setup` after install — it walks you through both.

### Claude Code (official marketplace)

```shell
/plugin install blue-contact@claude-plugins-official
```

Or browse the `/plugin` Discover tab and search for "Blue Contact".

### Claude Code (self-hosted marketplace)

```shell
/plugin marketplace add Blue-Contact/claude-plugins
/plugin install blue-contact@bluecontact-plugins
```

### Claude Code (local/development)

```shell
# from a clone of this repo (the repo root IS the plugin)
claude --plugin-dir .
```

### Cowork

Browse and install via Cowork → Customize → Browse plugins.
Or upload the plugin ZIP directly: Cowork → Plugins → "+" → Upload.
Organization admins can also push the plugin via GitHub sync or manual upload.

## Examples

Each example below maps to a specific skill from the table above.

### Quick audience build → `audience-pull`
> "Build me an audience of homeowners in Austin, TX aged 30-45 with household income over $100k. I need name, address, phone, and email."

### Industry playbook → `industry-playbooks`
> "I'm a roofing company in Dallas — help me find homeowners with older homes who might need roof replacement."

### Market sizing → `market-sizing`
> "How big is the market of renters aged 25-35 with income over $75K in the top 10 US metros?"

### Audience compare → `audience-compare`
> "Compare my Austin homeowners audience to my Dallas one — where do they differ on income, age, and contact coverage?"

### Audience report → `audience-report`
> "Generate a presentation from my latest audience so I can share it with the client."

### Audience monitoring → `audience-monitor`
> "Check this audience every week and let me know if the count drifts more than 5%."

### Audience logic QA → `audience-logic-report`
> "Save the logic behind this audience as a doc — I want my colleague to review the filters before we send it to the agency."

### Upload & match → `my-data`
> "Here's a CSV of our customers — match it against Blue Contact and tell me how many you can append phone and email for."

### Personas & scoring → `personas`
> "Build personas from my Austin homeowners audience, then score the rest of Texas against them."

### Data dictionary lookup → `data-dictionary`
> "What does the `home_market_value` field mean, and how often is it refreshed?"

### Mover analysis → `data-querying`
> "How many people moved from Puerto Rico to the US mainland in the last 12 months? Break it down by destination state."

### Dealership lookup → `data-querying`
> "Find all Toyota dealerships in Florida with their contact information."

### B2B targeting → `data-querying`
> "I need tech companies in the Bay Area with 50-200 employees and revenue over $10M."

## Data available

| Dataset | Key fields |
|---------|------------|
| Consumer | Name, address, phone, email, age, income, homeowner status, ethnicity, children |
| B2B | Company name, address, SIC/NAICS, employees, revenue |
| Movers | Origin, destination, move date, mover type |
| Property | Address, property type, value, sqft, year built |
| Dealership | Dealer name, location, make/brand, inventory |

What you actually see depends on your Blue Contact entitlements — `/blue-contact:setup` shows you the databases your account has access to.

## Privacy & Data Use

Blue Contact data is licensed for marketing and analytics purposes. Users are responsible for compliance with applicable laws (CAN-SPAM, TCPA, state privacy laws). See Blue Contact's privacy policy at: https://bluecontact.com/privacy

## Support

- Email: support@bluecontact.com
- GitHub Issues: https://github.com/Blue-Contact/claude-plugins/issues
