#!/bin/bash
# Blue Contact plugin — PostToolUse hook on mcp__blue-contact__run_audience_query
#
# After a successful audience pull, remind Claude of the two things users
# always want to know: contact coverage and where to download the audience.

cat <<'EOF'
<system-reminder>
You just ran `run_audience_query`. Before moving on:

1. If the response includes `coverage_summary`, surface its phone, email,
   and address percentages to the user with a one-line caveat that they're
   computed over the returned page. If coverage is below ~50% on a contact
   field the user cares about, flag it explicitly.

2. Always share the `download_url` from the response — it's the user's
   single shortcut for getting the audience as a CSV.

This reminder fires automatically after every audience run; do not echo it
to the user verbatim. Just make sure both items make it into your reply.
</system-reminder>
EOF
