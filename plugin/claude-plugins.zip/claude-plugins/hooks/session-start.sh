#!/bin/bash
# Blue Contact plugin — SessionStart hook
#
# Emits a short Claude-only context note. Shell hooks can't actually probe
# MCP session state, so this is a soft, always-on reminder rather than a
# detector. Claude reads it and only acts on it if a tool call later fails.

cat <<'EOF'
<system-reminder>
The Blue Contact plugin is installed in this session. Its MCP tools (ping,
get_schema, run_audience_query, get_audience_run, ...) appear under whatever
namespace this environment assigns the Blue Contact connector — commonly
`mcp__blue-contact__*` in Claude Code or `mcp__claude_ai_Blue_Contact__*` in
Cowork. Match on the tool name, not a hardcoded prefix.

If the user invokes a Blue Contact tool and you receive a 401, an
"unauthorized" error, or the tool isn't available at all, do not retry
blindly. Redirect the user to `/blue-contact:setup`, which has scripted
remediation flows for both connector-missing and unauthenticated states.

Don't preemptively run setup or mention this reminder unless connectivity
actually fails.
EOF

# Unquoted heredoc so the plugin root resolves to an absolute path — skills
# reference brand assets relative to the plugin root, not the session CWD.
# Skip the paragraph (but still close the tag) if the var is somehow unset.
if [ -n "${CLAUDE_PLUGIN_ROOT:-}" ]; then
cat <<EOF

Blue Contact brand assets (BRAND.md, brand.json, logos/) live at:
${CLAUDE_PLUGIN_ROOT}/brand/
Read them from that absolute path when generating any branded artifact.
EOF
fi

echo '</system-reminder>'
