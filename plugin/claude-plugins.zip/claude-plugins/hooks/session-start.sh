#!/bin/bash
# Blue Contact plugin — SessionStart hook
#
# Emits a short Claude-only context note. Shell hooks can't actually probe
# MCP session state, so this is a soft, always-on reminder rather than a
# detector. Claude reads it and only acts on it if a tool call later fails.

cat <<'EOF'
<system-reminder>
The Blue Contact plugin is installed in this session. Tools live under the
`mcp__blue-contact__*` namespace (e.g., ping, get_schema, run_audience_query).

If the user invokes a Blue Contact tool and you receive a 401, an
"unauthorized" error, or the tool isn't available at all, do not retry
blindly. Redirect the user to `/blue-contact:setup`, which has scripted
remediation flows for both connector-missing and unauthenticated states.

Don't preemptively run setup or mention this reminder unless connectivity
actually fails.
</system-reminder>
EOF
