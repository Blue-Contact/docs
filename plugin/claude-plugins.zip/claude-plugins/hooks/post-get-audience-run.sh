#!/bin/bash
# Blue Contact plugin — PostToolUse hook on get_audience_run.
#
# get_audience_run is polled repeatedly while a query runs. While status is
# "queued", "running", or "fixing" the response carries no payload and the
# "keep polling" instruction is already obvious — so we stay SILENT on those to
# avoid re-injecting this reminder on every poll. We only emit guidance on the
# terminal states (completed / failed).
#
# Fail-open: if we can't positively detect a non-terminal state in the hook
# input, we still emit — better a redundant reminder than dropping the
# completed-state surfacing (coverage_summary / download_url).

input=$(cat)

# Suppress only when the status FIELD is non-terminal. Match the JSON key
# specifically — row data, echoed SQL, or error text can contain words like
# "running" and must not suppress the terminal-state reminder.
if printf '%s' "$input" | grep -Eq '"status"[[:space:]]*:[[:space:]]*"(queued|running|fixing)"'; then
  exit 0
fi

cat <<'EOF'
<system-reminder>
get_audience_run reached a terminal state. Handle the response you got:

- If `status` is "failed": surface `error_message` to the user; do NOT
  auto-retry the same SQL.
- If `status` is "completed":
  - If `coverage_summary` is present, state its phone / email / address
    percentages with a one-line caveat that they're computed over the
    returned page; flag explicitly any field the user cares about that is
    below ~50%.
  - Always share the `download_url` — the user's shortcut to the full CSV.
  - If `next_token` is present, note more pages are available via
    get_audience_run with direction="next".
  - If a `precedent` / `comparison` block is present, relay it — the
    `disclosure` sentence is written to be used as-is. Read `sql_identical`
    correctly: false = this run used a DIFFERENT query than the earlier one;
    true = the SAME query over refreshed data. Never report one as the other,
    and never present a count that moved as if nothing had changed.

This reminder fires automatically; don't echo it verbatim.
</system-reminder>
EOF
