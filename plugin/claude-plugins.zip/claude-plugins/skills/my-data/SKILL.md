---
name: my-data
description: Upload your own files as queryable Blue Contact tables, match them against the Blue Contact library, run quality checks, and manage table retention — activates when a user wants to bring their own list, enrich/append a customer file, or work with previously uploaded tables
allowed-tools:
  - mcp__blue-contact__list_tables
  - mcp__blue-contact__get_table
  - mcp__blue-contact__get_table_preview
  - mcp__blue-contact__create_table_from_file
  - mcp__blue-contact__create_table_from_query
  - mcp__blue-contact__request_upload_url
  - mcp__blue-contact__register_uploaded_table
  - mcp__blue-contact__run_data_job
  - mcp__blue-contact__get_run_status
  - mcp__blue-contact__read_profiling_stats
  - mcp__blue-contact__sample_values
  - mcp__blue-contact__set_table_retention
  - mcp__blue-contact__drop_table
  - mcp__blue-contact__get_schema
  - mcp__blue-contact__save_message
  - AskUserQuestion
  - Read
  - Bash
---

# My Data — Uploads, Owned Tables, and Data Jobs

Blue Contact lets users bring their own data: upload a file, get a queryable Athena table, match it against the Blue Contact library to append contact/demographic data, and run quality checks. This skill covers that lifecycle. For clustering/personas and scoring, hand off to the `personas` skill.

## Critical rules (do not bypass)

- **NEVER match an uploaded list to the Blue Contact library with SQL.** No joins on names, emails, or addresses; no `create_table_from_query` tricks. SQL matching scans enormous tables, produces poor matches, and burns the customer's query spend. Matching is a managed job: `run_data_job(job_type: "match", table_id: ...)`. This is the single most important rule in this skill.
- **NEVER compute fill rates with SQL COUNT queries.** Every owned table is profiled automatically at registration; `read_profiling_stats(table_id: ...)` returns per-column null/blank rates, distinct counts, and top values with no Athena query.
- **Owned tables expire.** MCP uploads and CTAS tables default to 30-day retention. Every create/register response states the expiry — always surface it to the user, and offer `set_table_retention` if the table matters.
- **`drop_table` is permanent** (drops the Athena table, deletes S3 data, destroys the catalog entry). Confirm with the user via `AskUserQuestion` before calling it, and echo the table name and row count from `get_table` in the confirmation.

## Uploading a file

Pick the path by file size:

- **≤ 25MB raw**: `create_table_from_file(file_content: <base64>, filename, table_name)`. Read the file and base64-encode it (`base64 -i <file>` via Bash). Optional: `database_name` (defaults to the account's dataset database), `retention_days`, `ephemeral: true` for scratch data.
- **> 25MB**: three steps — `request_upload_url(filename)` → HTTP PUT the raw file to the returned presigned URL (`curl -X PUT --upload-file <file> "<url>"`) → `register_uploaded_table(upload_key, table_name)`.

Both paths register an owned table that is **profiled automatically**. The response states the table's expiry — tell the user.

After upload:
1. Check `get_table(table_id)` until `status: "ready"` (upload registration + auto-profiling is usually fast — under a minute for small files; see "Checking on data jobs" for the general rhythm).
2. Sanity-check with `get_table_preview(table_id)` (live sample rows) and `read_profiling_stats(table_id)` (fill rates). Surface anything alarming — empty key columns, obviously misparsed delimiters — before the user invests in downstream jobs.

## Materializing a table from a query

`create_table_from_query` creates an owned table via CTAS from either:
- `sql: "SELECT ..."` + `table_name` — arbitrary guarded SELECT, or
- `audience_id` + `table_name` — materializes an audience's latest SQL, or
- `existing_table: "database.table"` — reference an existing Glue table.

This is the bridge from audience-building to data jobs ("turn my audience into a table I can score against"). CTAS tables expire like uploads (30-day MCP default; `retention_days`/`ephemeral` to change). Optional `auto_profile: true` kicks off segmentation profiling immediately — if the user's goal is personas, set it and hand off to the `personas` skill.

**Not for matching.** Materializing a join between an upload and the library is exactly the SQL-matching anti-pattern banned above.

## Matching against the Blue Contact library

To link uploaded records to the library (identity resolution + append):

```
run_data_job(
  job_type: "match",
  table_id: <uploaded table's id>,
  match_target: "consumer" | "business_contact",   // default consumer; array or "consumer,business_contact" to match several libraries at once
  match_threshold: <int>                            // optional; defaults to account minimum
)
```

A table can be matched against **several libraries in one run** — pass `match_target` as an array or comma-separated list. The output then carries one typed id column per selected library: `bc_consumer_id` and/or `bc_contact_id` (a row may have both; `bc_match_entity_types` lists which libraries matched). Each id column's authoritative join target is in its `joins` metadata in `get_schema` — read it from there rather than guessing library table names.

If you ask the user to choose the target library, put all supporting context (fill rates, your recommendation) *before* the question, and treat the returned answer as final: launch the job in the same turn you receive it. A turn that reads the user's choice but ends without launching — or asks them to pick again — is the specific failure this rule exists to prevent.

Identity mappings are derived automatically from the profiled columns. The job runs as a managed Glue job — typically 5–10 minutes; share the ETA and poll `get_run_status` per the rhythm below. When it completes, the output is a new owned table (named `<source>_matched`, `origin: "match_output"`) that supersedes the upload — `list_tables` shows the linkage via `superseded_by_table` — and inherits the source table's expiry. Preview it for the user and report the match rate (the `bc_match_*` columns carry per-record match type, score, and accept/reject detail).

(`kickoff_import_match` and dataset-based matching are the **legacy** pipeline — only touch them for an old `dataset_id` the user already has, e.g. one stuck in `pending`/`failed` status from `list_datasets`.)

## Quality checks

`run_data_job(job_type: "quality", table_id: ...)` runs null/format/duplicate checks as a managed job. Offer it when the user asks "how good is my file?" before matching. For quick per-column answers, `read_profiling_stats` is instant and often sufficient — reach for the quality job when the user wants a systematic pass.

## The table ↔ dataset bridge

Every owned table carries a `dataset_id` in its `get_table` response (a match output shares its source table's `dataset_id`). That id is the handle for the dataset-scoped job tools — `run_data_job(job_type: "segment" | "score")`, `kickoff_profiling`, `kickoff_scoring`, and the `get_run_status`/`get_profiling_status` pollers. So the hand-off to the `personas` skill is: `get_table(table_id)` → read `dataset_id` → profile/score with it. `get_table` also returns a `profiling` status block and `recent_jobs`, so it's the one call that orients you on any owned table.

## Checking on data jobs

Data jobs (match, quality, profiling, scoring) are **long-running Glue jobs — minutes, not seconds**. Do not poll them in a tight loop the way `audience-building` polls audience queries:

- Call `get_run_status(dataset_run_id: ...)` (or `dataset_id` for the latest run). The response includes status, elapsed time, a runtime estimate, and a `message` with explicit handling guidance — follow it.
- The standard rhythm: launch the job, **share the ETA with the user, and end your turn**. Check status again when the user asks, or opportunistically when you're back for other work. If you have genuinely useful parallel work (e.g. exploring the library schema for the append fields), do that instead of sleeping between polls.
- On `failed`, the response carries error context. Surface it; don't blindly re-launch the job.

## Managing owned tables

- `list_tables` — the user's tables (uploaded, query-derived, job-output) with status and expiry. Filters: `status`, `purpose` (dataset/lookup/scratch). This is the current listing — **`list_datasets` is legacy**; don't use it except for old dataset-id flows.
- `get_table(table_id)` — schema, profiling status, provenance, recent data jobs, expiry.
- `set_table_retention(table_id, action: "pin" | "unpin" | "extend", retention_days)` — pin stops expiry (capped at 1 year), extend sets a new clock. Surface the new expiry from the response.
- Owned tables are queryable through the normal audience tools — get the fully-qualified name from `get_table` and follow the `data-querying` skill's conventions.

## Suggested flow for "here's my customer list"

1. Clarify intent: enrich/append (match), analyze quality, segment into personas, or just query it?
2. Upload via the size-appropriate path; report table name, row count, and expiry.
3. Show `read_profiling_stats` highlights: which identity columns (name/email/phone/address) are well-populated — this determines match quality. Present these highlights and your match-target recommendation **before** asking any question. All context goes ahead of the question, never after it — text emitted after the user answers must respond to the answer, not restate the setup.
4. If matching: confirm the target library (`AskUserQuestion` with your recommendation first). **The moment the answer comes back, launch `run_data_job(job_type: "match")` in that same turn** — do not re-confirm, do not restate the question or say "pick above", and do not end the turn between receiving the answer and launching. Then share the ETA and end your turn; once it succeeds, preview the output table and report the match rate.
5. Offer next steps: build an audience from the matched table, run `personas` profiling, or set retention if this is a keeper.
