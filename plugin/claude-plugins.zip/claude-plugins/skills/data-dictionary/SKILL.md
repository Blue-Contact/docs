---
name: data-dictionary
description: Field-level definitions, freshness expectations, coverage benchmarks, and known quirks for Blue Contact's databases. Use when a user asks what a field means, how fresh the data is, or why coverage looks low in a region.
---

# Blue Contact Data Dictionary

This skill bridges SQL mechanics (handled by `data-querying`) and institutional knowledge about what Blue Contact data actually means. It explains fields, sets expectations on freshness and coverage, and flags known quirks. Heavy content lives under `references/`, one file per data category.

## Triggers

Activate this skill when the user asks:

- "What does this field mean?" / "What's the difference between X and Y?"
- "How fresh is this data?" / "When was it last updated?"
- "Why is coverage so low in [region]?" / "Is X% phone coverage normal?"
- "Are there any quirks I should know about?" / "Why doesn't this state have data?"

## Workflow

### 1. Identify the relevant database(s)

Call `get_schema` (no params) if not loaded. Match the user's question to one or more of the user's available `category` values. Load only the references that match — don't load all five at once.

| `category` | Reference |
|---|---|
| `consumer` | `references/consumer.md` |
| `b2b` | `references/b2b.md` |
| `mover` | `references/mover.md` |
| `property` | `references/property.md` |
| `dealership` | `references/dealership.md` |

### 2. Get authoritative freshness from the schema

Read `data_freshness` and `data_freshness_note` from each database in the schema response. These come from the data team and are the source of truth for refresh cadence — never hardcode values from the references over the live schema. References give you *interpretation* guidance ("what 'weekly' means in practice for movers"); the schema gives you the actual cadence.

If `data_freshness` is missing from the schema response, fall back to the reference's documented expectation and caveat your answer with "based on documented expectations; please verify with the data team if exact freshness matters."

### 3. Read the relevant reference

For field definitions or coverage questions, load the matching reference file and answer from there. References are written to be self-contained — load one, answer, move on.

### 4. For column-level questions, also call `get_schema(database: ..., table: ...)`

Scope to the table the question is about — and `columns: [...]` when the user asks about a specific column. The per-column schema includes `prompt_guidance` — domain notes the data team encodes for Claude. If a user asks about a specific column, surface the prompt_guidance verbatim where relevant; don't paraphrase if precision matters. (Very high-cardinality columns return their options summarized; re-request with `columns: ["<that column>"]` if you need the full value list.)

### 5. Get actual numbers without burning queries

Two tools answer dictionary-style questions from persisted profiler output, with **no Athena query**:

- **`read_profiling_stats(database, table[, column])`** — per-column fill rates (null/blank), distinct counts, inferred types, min/max, and top values. When the user asks "what's the phone coverage in this table?" or "how complete is this field?", this is the answer — do not run SQL COUNT probes for whole-table fill rates. (Coverage of a *filtered* audience is a different question and still needs SQL — that lives in `audience-building`.)
- **`sample_values(database, table, column)`** — up to 100 example values, masked by default; sensitive columns only ever return synthetic/format-preserving values. Use it to show the user what a field's values actually look like.

If `read_profiling_stats` has no stats for a table, fall back to a SQL probe and say so.

### 6. Coverage interpretations

When discussing coverage rates (phone, email, address):

- **High coverage (>70%)**: typical for the contact field; safe to plan campaigns around it.
- **Medium coverage (40–70%)**: usable, but caveat reach — recommend the user check a sample query before committing.
- **Low coverage (<40%)**: flag explicitly. Common causes: rural geographies (mobile-only households often have lower email match), recently-onboarded data segments, or compliance-driven suppression. Per-database references list the typical low-coverage profiles.

## Style

- Prefer "this is what we know" framing over absolutes. The data team's notes are authoritative; if the references and schema agree, say so confidently. If they disagree, surface both.
- When citing a freshness or coverage number, say where it came from ("the schema reports `data_freshness: weekly`" vs. "documented benchmarks suggest").
- Never speculate about data the user doesn't have access to. If their schema doesn't include the dealership database, don't reference dealership quirks.
