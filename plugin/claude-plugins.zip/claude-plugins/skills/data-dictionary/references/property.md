# Property Data Dictionary

Field-level guidance, coverage patterns, and known quirks for Blue Contact's property records. Property data is recorder-of-deeds-sourced — coverage is high in metro areas where digitization is mature, lower in some rural counties.

## Most-asked-about fields

### Identification

- **`address_line_1`, `city`, `state`, `zip`** — USPS-validated. The unit of analysis is the parcel; multi-unit buildings appear as one row per unit when subdivided in the recorder data, otherwise once per parcel.
- **`apn` / `parcel_id`** — The local recorder's parcel ID. Format varies by county; use it for joins back to other property datasets, not for user-facing display.
- **`owner_first_name`, `owner_last_name`, `owner_full_name`** — As-of last recording. May lag by months for recently-changed ownership.

### Physical attributes

- **`property_type`** — Categorical. Typical option values: `SFR` (single-family residential), `CONDO`, `TOWNHOUSE`, `MFR` (multi-family residential), `MOBILE`, `LAND`, `COMM` (commercial). Verify against the schema's `options` array.
- **`year_built`** — Construction year. Often null for pre-1900 properties or in jurisdictions without modern recorder data; do not exclude rows where this is null without a reason.
- **`square_footage`** — Living area, not lot. Self-reported in some jurisdictions; treat as approximate.
- **`lot_size`** — In acres or square feet depending on the schema; check the column's `prompt_guidance`. Mixing units silently is a common bug.
- **`bedrooms`, `bathrooms`** — Recorder-sourced; bathrooms can be fractional (2.5).

### Valuation

- **`assessed_value`** — Tax-assessed value from the local jurisdiction. Lags market value, sometimes substantially. Used for tax purposes; not a market-price estimate.
- **`market_value` / `estimated_value`** — Modeled estimate of current market value. Treat as an order-of-magnitude figure; ranges within ~10% are within model noise.
- **`last_sale_price`, `last_sale_date`** — Most recent recorded transaction. Useful for "recent buyer" segments. Filter `last_sale_date >= DATE_ADD('month', -12, CURRENT_DATE)` for last-year buyers.

### Ownership characteristics

- **`is_owner_occupied`** — Boolean flag. Modeled where not directly knowable. The flip side ("investor-owned") is true when the owner's mailing address differs from the property address — a useful indicator but not perfect.
- **`length_of_residence`** — Years at the address, computed from `last_sale_date`. Null for inherited or never-sold properties.

## Coverage benchmarks

| Field | Metro counties | Rural counties | Notes |
|---|---|---|---|
| `property_type` | 95%+ | 80–90% | Some rural recorders use sparse classifications |
| `year_built` | 85–95% | 60–75% | Older, smaller jurisdictions often missing |
| `square_footage` | 80–90% | 50–70% | Self-reported in many places |
| `last_sale_price` | 90%+ | 70–85% | Privacy-redacted in some states (e.g., parts of TX) |
| `market_value` | 95%+ | 90%+ | Modeled — high coverage even where assessed is missing |
| Owner identity | 95%+ | 90%+ | Recorder-sourced — usually present |

## Known quirks

- **Texas non-disclosure** — Texas does not publicly disclose sale prices in many counties. `last_sale_price` is often null even for recent transactions; `market_value` (modeled) fills the gap.
- **Hawaii valuation skew** — Hawaii property values are extreme outliers; bucketed value comparisons distort if Hawaii is included with mainland data. Filter to a focal geography or use percentile-based bucketing.
- **Mobile homes** — `MOBILE` property type is undercounted in jurisdictions that don't track them through the recorder. If a campaign cares about mobile homes, expect lower volume than ground truth.
- **Year-built defaults** — Some recorders use `1900` as a placeholder for "unknown." Filter `year_built > 1900` for "real" year-built filtering.
- **Investor patterns** — Owner-occupancy flag is more reliable than "investor" inference from name alone. LLCs and trusts are common owner-name patterns and aren't always investors.
- **Apartment buildings as one row** — A 100-unit apartment building may appear as one parcel row, not 100. Direct-mail campaigns at the unit level need a separate household source — property data alone undercounts renters.

## Example: filtering homeowners with old roofs

```sql
-- Likely roof-replacement candidates: single-family homes built 1990 or earlier,
-- in a target state, owner-occupied, with assessed value over $200K
SELECT owner_first_name, owner_last_name, address_line_1, city, state, zip,
       year_built, square_footage, market_value
FROM <catalog>.<property_db>.parcels
WHERE state = 'OH'
  AND property_type = 'SFR'
  AND year_built BETWEEN 1900 AND 1990
  AND year_built > 1900    -- exclude the placeholder
  AND is_owner_occupied = true
  AND market_value >= 200000
ORDER BY zip, address_line_1
LIMIT 50000
```
