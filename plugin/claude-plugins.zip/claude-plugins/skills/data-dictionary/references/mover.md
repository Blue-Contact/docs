# Mover Data Dictionary

Field-level guidance, coverage patterns, and known quirks for Blue Contact's mover data. Mover data changes faster than other Blue Contact databases — always check the schema's `data_freshness` and `data_freshness_note` before quoting numbers.

## Most-asked-about fields

### Move event

- **`move_date`** — The recorded date of the move. Source-dependent: USPS NCOA-derived rows have day-level precision, public-record rows are sometimes month-precision (defaulted to the 1st). Filter with date ranges, never exact equality.
- **`mover_type`** — Categorical. Common option values: `I` (individual), `F` (family), `B` (business). Verify in the schema's `options` array.
- **`origin_address_line_1`, `origin_city`, `origin_state`, `origin_zip`** — Where they moved from.
- **`destination_address_line_1`, `destination_city`, `destination_state`, `destination_zip`** — Where they moved to. The destination address is the address you'd use for direct mail.

### Identity & contact

Same fields as the consumer database (`first_name`, `last_name`, `phone`, `email`) — see `consumer.md` for the deeper notes. Coverage on movers tends to be slightly *lower* than steady-state consumer data because contact information takes time to re-append after a move.

### Move modeling fields

- **`move_distance_miles`** — Computed straight-line. Local moves (<10 miles) and long-haul moves (>500 miles) cluster differently in service-purchase behavior.
- **`is_inbound_to_target_geo`** — Some flavors of the schema include precomputed inbound/outbound flags. Use them when present; they're faster than re-computing from origin/destination.

## Coverage benchmarks

| Field | First 30 days post-move | 30–90 days post-move | 90+ days post-move |
|---|---|---|---|
| Destination address | 95%+ | 95%+ | 95%+ |
| `phone` | 50–60% | 65–75% | 70–80% |
| `email` | 35–45% | 50–60% | 60–70% |

Phone and email coverage *rises* in the months after a move as Blue Contact's append sources catch up. If you're targeting fresh movers (last 30 days), expect lower contact match — plan around address-only campaigns or include a longer recency window if reachability matters.

## Known quirks

- **PO Box origins / destinations** — Common in mover data because relocating households use temporary mail-forwarding addresses. The address is real but the *occupancy* is uncertain. Filter for street addresses (`address_line_1 NOT LIKE 'PO Box%'`) for door-drop campaigns.
- **Self-reported vs. NCOA moves** — Self-reported sources lag actual move dates by weeks. NCOA-derived rows are closer to ground truth. The schema does not always distinguish these in a single column; `prompt_guidance` calls out the source mix.
- **Same-zip "moves"** — Same-ZIP relocations (apartment to apartment within a building) appear as moves but aren't useful for most service-purchase campaigns. Filter `origin_zip != destination_zip` if the use case requires a real geographic shift.
- **Hawaii / Alaska** — Lower mover volume captured than the lower 48; not because fewer moves happen, but because some sources don't cover these states evenly.
- **Holiday clustering** — Move dates cluster heavily around end-of-month and around June, late August, and early September (school-year effects). Don't read seasonal volume changes as data-quality issues.

## Example: inbound movers in a target metro

```sql
-- Last 90 days of family movers into Austin TX
SELECT first_name, last_name, destination_address_line_1, destination_zip,
       move_date, phone, email
FROM <catalog>.<mover_db>.movers
WHERE destination_state = 'TX'
  AND destination_city = 'Austin'
  AND move_date >= DATE_ADD('day', -90, CURRENT_DATE)
  AND mover_type = 'F'
ORDER BY move_date DESC
LIMIT 50000
```

Expected coverage: address ~98%, phone ~65–75%, email ~55–65%. If your run returns substantially below these, check `data_freshness_note` — the partition may be mid-refresh.
