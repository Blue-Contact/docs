# Dealership Data Dictionary

Field-level guidance, coverage patterns, and known quirks for Blue Contact's dealership data. Dealership records are sourced from manufacturer franchise rosters and licensing data — coverage is high for franchised new-car dealers, lower for independents and used-only lots.

## Most-asked-about fields

### Identification

- **`dealer_name`** — As registered with the manufacturer or state. May include legal-entity suffixes ("LLC," "Inc"); normalize for display.
- **`dealer_id` / `oem_dealer_code`** — The manufacturer's internal dealer code where available. Useful for joining to OEM-side analytics.
- **`address_line_1`, `city`, `state`, `zip`** — Physical lot address. Some dealer networks have separate sales / service addresses; this column tracks the primary sales location.
- **`phone`** — Main switchboard. Department-specific lines (sales, service, parts) live in separate columns where present.

### Brand & inventory

- **`make`** / **`brand`** — The franchise marque (Toyota, Ford, etc.). A dealer can carry multiple makes — those appear as separate rows joined by `dealer_id`. Some schemas pivot this into an array column; check the schema's `prompt_guidance`.
- **`is_new_car` / `is_used_car`** — Booleans. Most franchised dealers are both; pure-used lots are flagged accordingly.
- **`inventory_count`** — Approximate count of vehicles on the lot, where reported. Updated less frequently than other fields; treat as a rough indicator.

### Geography

- **`latitude`, `longitude`** — For radius queries (`within X miles of a target consumer`). High coverage. Use the standard haversine formula; Athena's `ST_DISTANCE` after casting to `ST_POINT` works.
- **`dma_code`, `dma_name`** — Designated Market Area. Useful for media-buying alignment.

### Operating status

- **`is_active`** — Boolean. Closed dealerships are kept in history but flagged. Always include `is_active = true` in targeting queries unless you specifically want historical data.

## Coverage benchmarks

| Field | Franchised new-car | Independent / used-only | Notes |
|---|---|---|---|
| `make` / `brand` | 100% | Often `unbranded` or `multi` | Independents may carry whatever |
| `latitude` / `longitude` | 99%+ | 99%+ | High everywhere |
| `phone` | 95%+ | 85–90% | Some independents use mobile-only contact |
| `dealer_name` | 100% | 100% | Always present |
| `inventory_count` | 60–80% | 30–50% | Self-reported, often missing |
| `oem_dealer_code` | 95%+ | n/a | Doesn't apply to independents |

## Known quirks

- **Multi-make dealers** — A dealership group may operate "Smith Toyota" and "Smith Honda" as separate rows with the same address but different `dealer_id`. Aggregate by address+name root for "dealer group" analysis.
- **Used-only lots** — Often have sparser inventory and ownership data; treat as a separate cohort when targeting.
- **Hawaii / Alaska** — Lower dealership density than the lower 48; some makes have zero or one dealer per state. Don't read this as a data quality issue.
- **Closed dealers** — Closures aren't always reflected immediately. If a campaign is sensitive to recency, cross-check against the `last_verified_at` column where available.
- **Radius targeting** — Consumer-to-dealer distance queries often want the *nearest* dealer, not all dealers in a radius. Use `ROW_NUMBER() OVER (PARTITION BY consumer_id ORDER BY distance)` in a CTE rather than a naive `WHERE distance < X` join.
- **Service-only locations** — Some manufacturer networks include service-only locations that don't sell vehicles. Filter by `is_new_car OR is_used_car` to exclude them.

## Example: nearest-Toyota lookup

```sql
-- For each consumer in a target state, find the nearest active Toyota dealer
WITH consumer_locations AS (
  SELECT individual_id, latitude AS c_lat, longitude AS c_lon
  FROM <consumer_catalog>.<consumer_db>.individual
  WHERE state = 'IL'
),
ranked AS (
  SELECT
    c.individual_id,
    d.dealer_name,
    d.address_line_1,
    d.city,
    ST_DISTANCE(
      ST_POINT(c.c_lon, c.c_lat),
      ST_POINT(d.longitude, d.latitude)
    ) * 69 AS approx_miles,    -- degrees to miles, rough
    ROW_NUMBER() OVER (PARTITION BY c.individual_id ORDER BY ST_DISTANCE(
      ST_POINT(c.c_lon, c.c_lat), ST_POINT(d.longitude, d.latitude))) AS rank
  FROM consumer_locations c
  CROSS JOIN <dealer_catalog>.<dealer_db>.dealers d
  WHERE d.make = 'Toyota'
    AND d.is_active = true
    AND d.is_new_car = true
)
SELECT individual_id, dealer_name, address_line_1, city, approx_miles
FROM ranked
WHERE rank = 1
LIMIT 50000
```

This is expensive — it's a cross-join. For production use, pre-filter consumers by ZIP-to-dealer-ZIP proximity first, then do the precise distance ranking on the narrowed set.
