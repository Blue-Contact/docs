# Consumer Data Dictionary

Field-level guidance, coverage patterns, and known quirks for Blue Contact's consumer data. Use this alongside the live schema (`get_schema(database: "<consumer-db>", table: "<table>")`, scoped by table — and `columns: [...]` for a specific field) — the schema's `prompt_guidance` per column is the authoritative source on usage; this file fills in institutional context the schema can't capture.

## Most-asked-about fields

### Identity & contact

- **`first_name`, `last_name`** — As-of the most recent file update. Blue Contact normalizes capitalization but does not unify nicknames (e.g., "Bob" vs. "Robert"). For matching, lowercase + remove punctuation before comparing.
- **`phone`** — Mobile-preferred when both mobile and landline are present. Stored as 10 digits, no formatting. Empty when no phone is appended; never holds a placeholder string.
- **`email`** — Lowercased on ingest. Append rate varies by geography (see Coverage benchmarks below).
- **Placement varies by account:** in some consumer schemas phone/email are inline columns on the main consumer table; in others they live in separate one-to-many join tables (e.g., `consumer_phone`, `consumer_email`, `consumer_mobile`). Check `get_schema` before writing coverage SQL — `COUNT(phone)` only works in the inline case; otherwise use a deduped semi-join (see the audience-building skill).
- **`address_line_1`, `city`, `state`, `zip`** — USPS-validated. State always uses two-letter codes. ZIP is 5-digit; ZIP+4 lives in a separate `zip_plus_4` column when present.

### Demographics

- **`age`** — Estimated, not always exact. Modeled from public records and self-reported sources. For age-band targeting, prefer the bucketed `age_bucket` field if available — it's more stable than the integer.
- **`income`** — Household income estimate, modeled. Ranges are statistical; treat $5K–$10K differences as noise. Use bucketed comparisons when filtering ($50K, $75K, $100K thresholds are standard).
- **`gender`** — Modeled where not self-reported. Coverage is high (>95%) but accuracy on first names with mixed gender associations (Jordan, Casey) drops; flag if a campaign's CTR is sensitive to this.
- **`ethnicity`** — Modeled. Use for campaign localization when it materially helps; never use for pricing or eligibility.
- **`homeowner_status`** — Categorical: `H` (homeowner), `R` (renter), `U` (unknown). Verify the option codes via the schema's `options` array — they occasionally extend.
- **`presence_of_children`** — Binary. Indicates *household* presence, not parental relationship.

### Modeled fields (interpret, don't quote)

These are statistical scores, not facts:

- **`homeowner_probability`**, **`income_probability`**, similar — values 0.0–1.0 representing the model's confidence. Threshold at 0.7 if you need a hard cut; 0.5 is a coin flip.
- Any field ending in `_score` or `_probability` should be framed to the user as "estimate" or "likely," never as a known attribute.

## Coverage benchmarks

These are typical ranges. Per-segment numbers will vary, especially in rural areas.

| Field | Urban DMAs | Rural ZIPs | Notes |
|---|---|---|---|
| `phone` | 70–80% | 55–70% | Lower in mobile-only households |
| `email` | 60–75% | 35–55% | Significantly lower outside metro areas |
| `address_line_1` | 95%+ | 90%+ | High everywhere — Blue Contact's strength |

If you see *substantially* lower numbers (e.g., phone <40% in an urban segment), that's a signal — surface it. Common causes: recently-loaded data partition, narrow demographic filters that intersect with low-coverage groups, or compliance suppression on certain segments.

## Known quirks

- **Hawaii / Alaska** — Lower coverage across all contact fields than the lower 48. Plan campaigns accordingly.
- **PO Box addresses** — `address_line_1` may contain "PO Box NNN." Filter these out for door-drop / direct-mail campaigns; they're useful for general mail.
- **Apartment buildings** — `address_line_2` is sparsely populated, so multi-unit deduplication on address alone undercounts households. Use a `(first_name, last_name, address_line_1, zip)` composite key for dedup.
- **Recent-onboarding markets** — Some smaller MSAs have lower phone/email match for the first 60 days after a new data partition lands. Check the schema's `data_freshness_note` before assuming a coverage anomaly is data quality.

## Example: looking up a field

When a user asks "what does this field actually mean?", the workflow is:

1. Call `get_schema(database: "<consumer-db>", table: "<table>", columns: ["<column>"])` to fetch just that column (scope by table, and by column when you know it).
2. Read its `type`, `options` (if categorical), and `prompt_guidance`.
3. Cross-reference this file's section above for institutional framing.
4. Answer with the schema's authority first, this file's framing second.

## Example: coverage sanity check before targeting

Before committing to a campaign that depends on phone or email reachability, run a quick coverage check on the target segment:

```sql
-- Coverage check: phone + email rates for a target consumer segment.
-- This shape assumes INLINE phone/email columns — verify via get_schema first.
-- If contact fields live in separate join tables, use the semi-join pattern
-- from the audience-building skill instead.
SELECT
  COUNT(*) AS total_in_segment,
  COUNT(NULLIF(phone, '')) AS with_phone,
  COUNT(NULLIF(email, '')) AS with_email,
  ROUND(100.0 * COUNT(NULLIF(phone, '')) / COUNT(*), 1) AS phone_pct,
  ROUND(100.0 * COUNT(NULLIF(email, '')) / COUNT(*), 1) AS email_pct
FROM <catalog>.<consumer_db>.individual
WHERE state = 'TX'
  AND age BETWEEN 35 AND 55
  AND income >= 75000
```

Compare the output against the Coverage benchmarks table above. If `phone_pct` or `email_pct` is materially below the urban-DMA range, surface that to the user before they invest in a campaign that assumes typical reach.
