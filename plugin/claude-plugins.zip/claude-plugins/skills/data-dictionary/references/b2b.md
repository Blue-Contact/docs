# B2B Data Dictionary

Field-level guidance, coverage patterns, and known quirks for Blue Contact's B2B data. Cross-reference the live schema (`get_schema(database: "<b2b-db>", table: "<table>")`, scoped by table — and `columns: [...]` for a specific field) for column-level types and option values — this file adds the institutional context.

## Most-asked-about fields

### Company

- **`company_name`** — Legal name where available, DBA otherwise. Not deduplicated across DBAs / parent-subsidiary relationships — two rows for "Acme Inc" and "Acme Holdings LLC" may be the same operating entity.
- **`sic_code` / `naics_code`** — Industry classifications. SIC is older (4-digit), NAICS is newer (6-digit). Use NAICS when available; fall back to SIC. Both can be present on the same row, and they may not perfectly cross-walk.
- **`employee_count`** — Self-reported or modeled. Treat as an order-of-magnitude figure. Bucket for filtering: `<10`, `10–49`, `50–249`, `250–999`, `1000+`.
- **`annual_revenue`** — Modeled, in dollars. Same caveats as `employee_count` — useful for tiering, weak for exact comparisons.
- **`year_founded`** — Public-record-sourced. Often missing for small businesses; do not exclude rows where this is null without a reason.

### Contact

- **`first_name`, `last_name`** — As-of last appended. Tenure varies — a contact might have moved companies but the row hasn't been updated. Cross-check `last_updated_at` if precision matters.
- **`title`** — Free-text. Filter by keyword (`LIKE '%CFO%'`) rather than exact match. Common normalizations the schema applies: "Vice President" → "VP," "Chief X Officer" abbreviated. Verify with `prompt_guidance` for the column.
- **`email`** — Business email; coverage is generally higher than consumer email but varies sharply by company size (better at enterprises, lower at small businesses).
- **`phone`** — Direct line where available, switchboard otherwise. The `phone_type` column (if present) distinguishes them.

### Modeled / probability fields

- Fields ending in `_score` (e.g., `intent_score`) are model outputs. Threshold conservatively (0.7+) for high-confidence segments.

## Coverage benchmarks

| Field | Enterprise (1000+) | SMB (<50) | Notes |
|---|---|---|---|
| `email` | 75–90% | 45–65% | Smaller companies often have generic info@ addresses, not contact-specific |
| `phone` (direct) | 50–70% | 25–40% | Switchboard fallback covers more |
| `title` | 90%+ | 80%+ | High everywhere; quality drops at smaller companies |
| `employee_count` | 95%+ | 80%+ | Often null for very small businesses |
| `annual_revenue` | 90%+ | 60%+ | Often estimated for SMB |

## Known quirks

- **SIC vs. NAICS gaps** — Some industries (especially newer tech sub-verticals) are better covered by NAICS than SIC. If filtering by industry returns surprisingly few results, try the cross-walked code on the other system.
- **Holding companies** — Large enterprises with many subsidiaries may appear once per subsidiary with related-but-different `sic_code` values. Aggregate carefully.
- **Stale titles** — A contact's title may lag their actual role by 6–12 months. Important for "VP+ at company X" filters; consider widening the title pattern.
- **PO Box company addresses** — Common for very small businesses; filter or accept depending on use case.
- **Government / non-profit** — Mixed coverage; SIC 91xx (government) and NAICS 92xxxx have idiosyncratic data quality. Avoid revenue-based filters for these segments.

## Example: industry filtering

```sql
-- "Find financial-services companies" — use NAICS 52 (Finance and Insurance) at any depth
-- Select only the columns you need; `companies` is wide (60+ cols), so SELECT * scans far more than necessary.
SELECT company_id, company_name, naics_code, sic_code, employee_count, revenue
FROM <catalog>.<b2b_db>.companies
WHERE naics_code LIKE '52%'
   OR sic_code BETWEEN '6000' AND '6799'    -- legacy SIC for finance
```

Always validate the SIC ranges in your specific schema's `prompt_guidance` — they occasionally vary.
