---
name: getting-started
description: Interactive guided tour of Blue Contact's data capabilities — discovers your available data and walks you through real examples with live visualizations
allowed-tools:
  - mcp__blue-contact__get_schema
  - mcp__blue-contact__run_audience_query
  - mcp__blue-contact__get_audience_run
  - mcp__blue-contact__get_audience
  - mcp__blue-contact__list_audiences
  - mcp__blue-contact__save_message
  - mcp__blue-contact__save_artifact
  - AskUserQuestion
  - Read
  - Write
---

# Blue Contact — Getting Started

Welcome the user to Blue Contact and give them an interactive, hands-on tour of what they can do. This skill dynamically discovers the user's available data and walks through capabilities with live examples and rich visualizations.

The tour's defining feel is **fast** — first chart in ~15 seconds (or near-zero on a pre-warmed pick), narrated through the wait, no silent dead air.

## Async query results

`run_audience_query` is async — it returns `{status: "queued", run_id, ...}` with no rows. Poll `get_audience_run` with the `run_id` every 2–5 seconds until `status: "completed"`; the completed response carries `rows`, `columns`, `coverage_summary`, and `download_url`. **Never poll silently — narrate during the wait.** Full pattern: `${CLAUDE_PLUGIN_ROOT}/skills/audience-building/SKILL.md` → "Polling for results".

## Phase 1: Discover & Orient

1. **Verify connectivity.** Call `get_schema` with no parameters to get the lightweight database summary.
   - If the schema was already loaded earlier in the session (e.g., the user just came from `setup`), reuse it.
   - If the call fails, hand back to `setup` with an `AskUserQuestion`: **"Run setup now"** (recommended) and **"I'll fix it myself"**.

2. **Map available data.** Iterate the schema's `databases` array and emit a bullet per `category` present:

   | `category` | Capability bullet |
   |---|---|
   | `consumer` | **Consumer data** — demographics, contact info, lifestyle attributes |
   | `b2b` | **B2B data** — business records, SIC/NAICS, firmographics |
   | `mover` | **Mover data** — recent movers with origin/destination |
   | `property` | **Property data** — real estate records, valuations, characteristics |
   | `dealership` | **Dealership data** — dealer locations, makes, inventory |
   | `custom` (or anything else) | **Other:** *<display_name>* — *<description, truncated>* |

   Only emit bullets matching databases the user actually has. Use `display_name` for user-facing labels, never internal names.

3. **Present a personalized overview.** Brief, friendly summary framed as "Here's what you have access to," with approximate table counts and example questions per dataset.

## Phase 2: Interactive Menu

Build the menu programmatically from the categories present in Phase 1. Do not show options for data the user doesn't have — the menu IS the applicability check; no separate guard needed downstream.

**Speculative pre-warm (free speed).** In the same response as `AskUserQuestion`, fire the marginal query for the user's *most likely first pick* with `audience_title: "Getting Started: <topic>"`. Stash the `run_id`. If the user picks that topic, the query is already in flight — first chart in ~0–5s instead of 15s. If they pick something else, the query completes in the background and is still useful if they circle back. Cost: one extra tracked run on a wrong-topic pick.

Pick the pre-warm topic:
- `consumer` present → demographic snapshot
- Else, the first non-`custom` category present (preferred order: b2b → property → mover → dealership)
- Only `custom` databases → no pre-warm

Menu options. Always include "Explore your data," "Build your first audience," and "Skip — straight to building." Add the rest based on categories present:

| Category | Menu option | Description |
|---|---|---|
| *(always)* | **Explore your data** | "Let me show you what fields are available and how the data is structured" |
| `consumer` | **See who's in your data** | "I'll run a quick demographic snapshot of your consumer records" |
| `b2b` | **Find businesses** | "Let's look at what B2B data you have and search for companies" |
| `mover` | **Track movers** | "I'll show you recent mover volume and what data points are captured" |
| `property` | **Browse properties** | "Let's explore property records — types, values, and characteristics" |
| `dealership` | **Look up dealerships** | "Search dealer inventory by make, location, or type" |
| *(any database)* | **Build your first audience** | "I'll walk you through creating a targeted list step by step" |
| *(always)* | **Bring your own data** | "Upload a file of your own, match it against Blue Contact, and query it — I'll hand you to the `my-data` workflow" |
| *(always)* | **Skip — straight to building** | "Bail on the tour and hand me to `audience-pull` to start working" |

If the user picks **Skip**, invoke `audience-pull` and exit. If they pick **Bring your own data**, invoke `my-data` and exit. Don't run Phase 3 or 4 for either.

## Phase 3: Guided Exploration

Telegraph the wait at the top: *"I'm running one query that gives us the whole snapshot — about 15 seconds. While that runs, here's what we're looking at…"*

**Fire-and-narrate order (not narrate-then-fire):**

1. **Fire the marginal query immediately.** Load only the matching section of `references/topic-playbooks.md` for the chosen topic — it gives the canonical columns and the marginal SQL directly. Call `run_audience_query` with `audience_title: "Getting Started: <topic>"`. (If a pre-warm `run_id` exists for this topic from Phase 2, use it instead — don't re-fire.) **One topic = one tracked run.** Don't use `execute_sql_query` in the tour and never split into multiple queries.

2. **While polling `get_audience_run`, do the prep in parallel:**
   - **Narrate** the dimensions the query covers and what each one will reveal — fill the 15s with content, not silence.
   - **Load brand colors** from `${CLAUDE_PLUGIN_ROOT}/brand/brand.json` (and `${CLAUDE_PLUGIN_ROOT}/brand/BRAND.md` if you haven't seen it this session) — the `brand/` directory lives at the plugin root, not the session working directory. You need them at step 4 — load them now, not at step 4, so they're in context when results land. If the files can't be read, the skeleton's `BRAND` values below are the correct defaults — use them as-is.
   - **Tee up the chart story** — "we'll see age skew, ownership mix, contact reach…"
   - **Schema fallback only if the query errors** with a "column not found" or similar. The playbook's columns are the standard ones; a scoped `get_schema(database, table, columns: [...])` is the exception, not the rule.

3. **When the query completes:**
   - Validate `columns` are `[dimension, value, consumers]` (ignore any extra `total_count` column the platform may add).
   - Pivot rows by `dimension` and build the static multi-chart dashboard from the **skeleton below**. Do not read `references/visualization-guide.md` unless you need chart-selection guidance for an unusual data shape; do not read the large sample `.jsx` files.
   - Replace the `BRAND` hex values with the actual values from `${CLAUDE_PLUGIN_ROOT}/brand/brand.json` if they differ.
   - Save the `.jsx` and present it.

4. **Persist (if an audience was created).**
   ```
   save_artifact(
     audience_id: <id>,
     title: "<topic> — Getting Started Exploration",
     source_code: <complete source>,
     artifact_type: "react_dashboard",
     metadata: { "generated_by": "getting-started", "topic": "<topic>" }
   )
   ```
   For topics without an audience, skip.

5. **Narrate results** — 1–2 patterns, notable numbers, actionable insights. Keep it short.

6. **Suggest one or two contextual follow-ups** — e.g., "Want to filter this by state?" or "Ready to build an audience from this?" Don't list every plugin command; pick what fits.

### Dashboard skeleton (author from this — don't read the large sample `.jsx` files)

```jsx
import React from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, LabelList } from "recharts";

const BRAND = {
  blue: "#006AFF", lightBlue: "#1994FF", seafoam: "#12C7B4", graphite: "#2A3A57",
  clearSky: "#334669", success: "#00C864", hazard: "#FF9A1F", eggshell: "#E4E9F5", white: "#FFFFFF",
  gradient: "linear-gradient(135deg, #1A94FF 0%, #006AFF 100%)",
};
const CHART = [BRAND.blue, BRAND.lightBlue, BRAND.seafoam, BRAND.clearSky, BRAND.hazard, BRAND.success];
const FONT = "'Inter','SF Pro Display',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif";
const fmtM = (n) => (n >= 1e6 ? (n / 1e6).toFixed(1) + "M" : n >= 1e3 ? (n / 1e3).toFixed(0) + "K" : n);

const data = [{ name: "A", value: 0 }]; // inline the pivoted query results

export default function Dashboard() {
  return (
    <div style={{ fontFamily: FONT, background: "#F5F7FC", minHeight: "100vh", padding: 24, color: BRAND.graphite }}>
      <div style={{ background: BRAND.gradient, borderRadius: 20, padding: "26px 30px", color: BRAND.white, marginBottom: 22 }}>
        {/* Embed the Blue Contact icon SVG (${CLAUDE_PLUGIN_ROOT}/brand/logos/icon-gradient.svg) + title */}
        <div style={{ fontSize: 26, fontWeight: 900 }}>YOUR DATA</div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(330px, 1fr))", gap: 16 }}>
        <div style={{ background: BRAND.white, border: `1px solid ${BRAND.eggshell}`, borderRadius: 16, padding: 20 }}>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke={BRAND.eggshell} vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: BRAND.clearSky }} />
              <YAxis tickFormatter={fmtM} tick={{ fontSize: 11, fill: BRAND.clearSky }} />
              <Tooltip />
              <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                {data.map((e, i) => <Cell key={i} fill={CHART[i % CHART.length]} />)}
                <LabelList dataKey="value" position="top" formatter={fmtM} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div style={{ marginTop: 22, color: BRAND.clearSky, fontSize: 12 }}>Data provided by Blue Contact · Where Data Lives.</div>
    </div>
  );
}
```

Add charts in the responsive grid for each dimension the query returned. Finish with the attribution footer. For chart-selection guidance beyond the basics (donut vs. bar, interactive cube pattern, etc.), `references/visualization-guide.md` is on-demand.

## Phase 4: What's Next

After the user has explored a topic:

1. **Offer to explore another topic** from the Phase 2 menu (or wrap).
2. **Suggest one or two contextual workflows** based on what they just explored — don't recite the catalog. Examples:
   - After demographic snapshot → `/blue-contact:audience-pull` or `/blue-contact:audience-compare`
   - After B2B exploration → `/blue-contact:industry-playbooks` or `/blue-contact:audience-pull`
   - After "Build your first audience" → `/blue-contact:audience-report`, `/blue-contact:personas`, or `/blue-contact:audience-monitor`
   - If they mention having their own customer list → `/blue-contact:my-data`
3. **Highlight the conversational angle** — remind users they can query and visualize anything at any time, and that the `data-analyst` sub-agent is available for complex multi-step work.

## Style Guidelines

- Warm, conversational, encouraging — this is onboarding, not a technical manual
- Plain language, no jargon unless explained
- Run real queries with real numbers — hands-on, not a slideshow
- After every meaningful set of results, build a chart — query → visualize → narrate
- Make the first visualization a "wow" moment
- Keep responses focused; let the user drive pace
- If a query fails, handle gracefully and try a different angle
- Celebrate small wins ("Nice — 2.3M consumer records with 68% phone coverage, strong starting point")
- Briefly explain each chart, highlight 1–2 takeaways, then let the user explore
