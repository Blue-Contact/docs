---
name: getting-started
description: Interactive guided tour of Blue Contact's data capabilities — discovers your available data and walks you through real examples with live visualizations
allowed-tools:
  - blue-contact:get_schema
  - blue-contact:get_query_instructions
  - blue-contact:validate_sql
  - blue-contact:execute_sql_query
  - blue-contact:run_audience_query
  - blue-contact:create_audience
  - blue-contact:get_audience
  - blue-contact:list_audiences
  - blue-contact:save_message
  - blue-contact:save_artifact
---

# Blue Contact — Getting Started

Welcome the user to Blue Contact and give them an interactive, hands-on tour of what they can do. This skill dynamically discovers the user's available data and walks through capabilities with live examples and rich visualizations.

## Brand Configuration

Before generating any visual output, read `brand/BRAND.md` for the official Blue Contact brand guide, then load color tokens from `brand/brand.json`. All visual artifacts must use these brand colors — never hardcode color values.

**Every visual artifact must include the Blue Contact icon at minimum.** Embed the icon (`brand/logos/icon-gradient.svg`) or, for headers, the horizontal logo (`brand/logos/horizontal-gradient.svg`). See `brand/BRAND.md` for placement guidance per artifact type.

## Visualization Strategy

A core part of the getting started experience is showing users that Blue Contact + Claude is more than a query tool — it's a full data intelligence platform. After every meaningful query, **create a React (.jsx) visualization** to bring the data to life.

**How to create visualizations:**
- Write a self-contained React component (.jsx file) using Recharts for charts and Tailwind for layout
- Save the file and present it to the user — it will render as an interactive artifact
- Available chart libraries: `recharts` (BarChart, PieChart, LineChart, AreaChart, etc.), `d3`, `plotly`
- Use Tailwind utility classes for styling (no custom CSS needed)
- Each visualization should be a single .jsx file with a default export
- Include the data inline in the component (extracted from the query results)

**Chart selection guidance:**
- Geographic distributions → horizontal bar chart (top 10-15 states) or a colored US map
- Age/income distributions → vertical bar chart or histogram
- Category breakdowns (property type, industry, mover type) → donut/pie chart or horizontal bars
- Time series (mover volume by month) → line chart or area chart
- Coverage rates (phone %, email %) → gauge-style display or stacked bar
- Comparisons (origin vs destination, owner vs renter) → grouped bar chart or side-by-side
- Multi-metric dashboards → combine 2-4 charts in a responsive grid layout

**Visualization best practices:**
- Use the Blue Contact brand color palette from `brand/brand.json` — contactBlue as primary, with seafoam and other tokens
- Always include clear titles, axis labels, and data labels where they help readability
- Add a subtle "Blue Contact" label or data source note at the bottom
- Format numbers with commas and appropriate units (K, M for large numbers)
- Make charts responsive — they should look good at any width
- For the first visualization in the session, make it a "wow" moment — a polished multi-chart dashboard that shows the breadth of the data

### Interactive visualizations (preferred for the first "wow" moment)

Wherever it's feasible, make the visualization **interactive** — let the user adjust filters inside the artifact and watch counts and charts update instantly. The pattern is "pre-fetch a cube, slice it locally":

1. **Pre-fetch a moderately-sized crosstab** with `execute_sql_query`. Aim for roughly 500–5,000 pre-aggregated rows across the dimensions the user is most likely to want to slice (e.g., state × age bucket × income bucket × ownership, with `consumers`, `with_phone`, `with_email` counts). This is small enough to embed in a .jsx file (tens of KB) but rich enough to answer most "what if I change X" questions without another round trip.
2. **Embed the cube inline** in the .jsx file as a compact array literal.
3. **Render interactive controls** (pill-style checkboxes per dimension + a reachability toggle) that re-aggregate the cube in a `useMemo` on every change. The hero count, charts, and breakdowns all update instantly with no network calls.
4. **Include a "Send filters back to Claude" panel** at the bottom that mirrors the current filter state as a natural-language prompt. The sandboxed JSX artifact can't call `run_audience_query` directly, so the user copies the prompt back into chat and Claude materializes the full audience. This closes the loop between exploration (inside the artifact) and execution (via MCP).

The reference implementation is `Interactive_Audience_Builder.jsx` in the plugin root — model new interactive dashboards on it. Fall back to the static multi-chart dashboard only when the natural slicing dimensions don't fit in a reasonable cube (e.g., free-text search over millions of rows).

## Phase 1: Discover & Orient

1. **Verify connectivity.** Call `get_schema` with no parameters to get the lightweight database summary.
   - If the schema was already loaded earlier in the session (e.g., the user just came from the `setup` skill), reuse it — don't re-fetch.
   - If the call fails or the connection isn't authenticated, hand back to `setup` with an `AskUserQuestion` prompt offering: **"Run setup now"** (recommended) and **"I'll fix it myself"**. If they pick the first, launch the `setup` skill and pick the tour back up after setup confirms connectivity.

2. **Map available data.** Iterate the schema's `databases` array. For each entry, use the server-provided `category` to decide which capability bullet to emit, and use `display_name` for the user-facing label. The mapping:

   | `category` value | Capability bullet |
   |---|---|
   | `consumer` | **Consumer data** — demographics, contact info, lifestyle attributes |
   | `b2b` | **B2B data** — business records, SIC/NAICS, firmographics |
   | `mover` | **Mover data** — recent movers with origin/destination |
   | `property` | **Property data** — real estate records, valuations, characteristics |
   | `dealership` | **Dealership data** — dealer locations, makes, inventory |
   | `custom` (or anything else) | **Other:** *<display_name>* — *<description, truncated>* |

   Emit only the bullets whose category matches a database the user actually has. Do not invent bullets for capabilities the user lacks. If a database's category is `custom` or missing, fall back to its `display_name` rather than inventing copy.

3. **Present a personalized overview.** Based on what databases are available, show the user a brief, friendly summary of their data landscape. Include approximate table counts and the types of questions each dataset can answer. Frame it as "Here's what you have access to." Use the `display_name` from the schema response in your prose — never the internal database name.

## Phase 2: Interactive Menu

Build the menu programmatically from the set of categories present in the schema response from Phase 1. Do not present options for data the user doesn't have — that is a bug, not a style choice.

Construction:

1. Collect the set of `category` values across the user's databases.
2. For each category present, include the matching menu option from the table below.
3. **Always** include "Explore your data" (works for any access profile) and "Build your first audience" (works as long as the user has at least one database).
4. Pass the resulting array to `AskUserQuestion`.

Menu option table:

| Category present | Menu option | Description |
|---|---|---|
| *(always)* | **Explore your data** | "Let me show you what fields are available and how the data is structured" |
| `consumer` | **See who's in your data** | "I'll run a quick demographic snapshot of your consumer records" |
| `b2b` | **Find businesses** | "Let's look at what B2B data you have and search for companies" |
| `mover` | **Track movers** | "I'll show you recent mover volume and what data points are captured" |
| `property` | **Browse properties** | "Let's explore property records — types, values, and characteristics" |
| `dealership` | **Look up dealerships** | "Search dealer inventory by make, location, or type" |
| *(any database)* | **Build your first audience** | "I'll walk you through creating a targeted list step by step" |

## Phase 3: Guided Exploration

For whichever topic the user picks, run a live, narrated walkthrough. The goal is to teach by doing — run real queries, show real results, and explain what's happening along the way.

### Applicability guard (run at the top of every topic walkthrough)

Before starting any topic walkthrough, confirm the user actually has the database that backs it. The Phase 2 menu construction should have prevented mismatches, but defend against direct slash-command entry anyway:

| Topic | Required category |
|---|---|
| Demographic snapshot (consumer) | `consumer` |
| B2B exploration | `b2b` |
| Mover data | `mover` |
| Property records | `property` |
| Dealership lookup | `dealership` |
| Build your first audience | *(any)* |
| Explore your data | *(any)* |

If the user's session has no database in the required category, do not run the walkthrough. Apologize briefly and return them to the Phase 2 menu with the options they actually have.

### General pattern for each topic:

1. **Load the full schema** for the relevant database using `get_schema(database: "...")` if not already loaded.
2. **Narrate what's available.** Summarize the key columns, highlight interesting fields, and mention what option values exist for categorical fields. Keep it conversational — don't just dump a column list.
3. **Run sample queries.** Pick something interesting and concrete. Run 2-3 queries to gather enough data for a compelling visualization. Use `execute_sql_query` for exploratory queries. Examples:
   - Consumer: Count by state, age distribution, income breakdown, contact coverage rates
   - B2B: Top industries by company count, employee size distribution
   - Movers: Monthly volume trends, top origin/destination states
   - Property: Property type mix, median value by type, age of housing stock
   - Dealerships: Makes available, geographic coverage, dealer count by state
4. **Build a visualization.** Take the query results and create a React (.jsx) chart or dashboard. This is the "wow" moment — make it polished and informative. Save the .jsx file and present it to the user.
5. **Persist the visualization.** If the exploration created an audience (e.g., "Build your first audience" topic), call `save_artifact` to attach the dashboard. Detect `artifact_type` from what was generated — the getting-started skill may produce either JSX (interactive Recharts dashboards) or HTML (simpler visualizations, show_widget output):
   ```
   save_artifact(
     audience_id: <the audience ID>,
     title: "<topic> — Getting Started Exploration",
     source_code: <the complete source code>,
     artifact_type: <"react_dashboard" or "html">,
     metadata: { "generated_by": "getting-started", "topic": "<topic name>" }
   )
   ```
   For topics that don't create an audience (e.g., "Explore your data", demographic snapshot without audience creation), skip this step — the visualization lives in the Cowork session only. If the user later builds an audience from the exploration, the artifact can be saved then.
6. **Narrate the results.** Walk the user through what the visualization shows. Point out interesting patterns, notable numbers, and actionable insights. Keep it conversational.
7. **Suggest a follow-up.** Offer 2-3 natural next steps the user could try: "Want to filter this by state?", "Shall we check email coverage for this group?", "Ready to build an audience from this?"

### Topic-specific guidance:

#### Explore your data
- Call `get_schema` for each relevant database
- Walk through the table structure and highlight the most useful columns
- Show the user which databases they have and what each is good for (use `display_name` from the schema response, not internal names)
- Show an example of how filters work with a simple count query
- **Visualization:** Create a data landscape overview — a dashboard-style .jsx showing total record counts per database/table as a bar chart, with key stats (total records, databases, tables) as big stat cards at the top

#### Demographic snapshot (consumer)
- **Pre-fetch a cube** with a single `execute_sql_query` call: `state × age_bucket × income_bucket × ownership` with `COUNT(*) AS consumers, COUNT(phone) AS with_phone, COUNT(email) AS with_email`. Limit to the top ~15 states so the cube stays under ~1,500 rows (Athena's per-page limit is 1,000 — page through if needed).
- Check phone and email coverage rates
- Frame it as "Here's a bird's eye view of your consumer universe — and you can slice it yourself"
- **Visualization (interactive):** Build the demographic dashboard as an interactive .jsx using the cube pattern above. Include:
  - Hero count that updates live with the current slice
  - Pill-style filter groups for state, age, income, and ownership
  - A reachability toggle (phone OR email / phone only / email only / phone AND email)
  - Top states (horizontal bar), age (vertical bar), income (vertical bar), ownership (donut) — all re-aggregated from the cube on each filter change
  - "Send filters back to Claude" panel so the user can promote a slice into a real `run_audience_query` run
- Model it on `Interactive_Audience_Builder.jsx` in the plugin root

#### B2B exploration
- Show industry breakdown (SIC or NAICS)
- Employee count and revenue distributions
- Geographic spread
- Contact availability
- **Visualization:** B2B landscape dashboard .jsx with:
  - Top industries as a horizontal bar chart
  - Company size distribution (employee count buckets) as a bar chart
  - Revenue tiers as a bar chart
  - Geographic heatmap or top-states bar chart

#### Mover data
- Show recent volume by month or quarter
- Origin vs destination analysis
- Mover type breakdown (individual, family, etc.)
- Key fields available for targeting
- **Visualization:** Mover trends dashboard .jsx with:
  - Monthly/quarterly volume as a line or area chart (this is the "hero" chart)
  - Top origin states vs top destination states as paired horizontal bars
  - Mover type breakdown as a donut chart

#### Property records
- Property type distribution
- Value ranges and medians
- Geographic coverage
- Year built distribution
- **Visualization:** Property insights dashboard .jsx with:
  - Property type mix as a donut chart
  - Value distribution as a histogram / bar chart with buckets
  - Year built timeline as a bar chart showing housing stock age
  - Top states by property count as horizontal bars

#### Dealership lookup
- Available makes/brands
- Geographic coverage by state
- Dealer count summaries
- How to search for specific dealers or makes
- **Visualization:** Dealership overview .jsx with:
  - Top makes/brands by dealer count as a horizontal bar chart
  - Geographic coverage as a state bar chart
  - Total dealer count and make count as stat cards

#### Build your first audience
- Walk the user through the full audience-building workflow step by step
- Help them pick a target (geography + demographics or firmographics)
- Run a count estimate first
- Check contact coverage
- Use `run_audience_query` to create the audience
- Explain the results and what they can do next (download CSV, refine, segment)
- **Visualization:** After the audience is built, create an audience profile dashboard .jsx showing:
  - Total audience size as a hero stat
  - Geographic breakdown of the audience as a bar chart
  - Key demographic splits (age, income, etc.) relevant to the filters used
  - Contact coverage (phone %, email %) as progress bars with the actual numbers
  - A "what you can do next" section with action suggestions
- **After the audience is finalized**, prompt with AskUserQuestion: "Save & share for QA" / "Skip for now" — this offers to save the audience logic as a shareable doc teammates can review and send back with changes (triggers the `audience-logic-report` skill)

## Phase 4: What's Next

After the user has explored a topic, always circle back with:

1. **Offer to explore another topic** from the menu.
2. **Mention key workflows** they can use going forward. The list below is filtered by what the user actually has access to — only mention a command if its applicability rule is satisfied.

   | Command | Applicability rule |
   |---|---|
   | `/blue-contact:audience-pull [description]` | Always — quick audience builds from a one-line description |
   | `/blue-contact:audience-report` | Always — generate a polished PPTX or PDF from any audience |
   | `/blue-contact:audience-compare` | Always — compare two audiences side-by-side |
   | `/blue-contact:market-sizing` | Always — TAM analysis and opportunity dashboards |
   | `/blue-contact:industry-playbooks` | Only if the user has a database in at least one supported vertical (consumer, b2b, mover, property, or dealership) |
   | `/blue-contact:audience-logic-report` | Always — save audience logic as a doc your team can QA |
   | `/blue-contact:audience-monitor` | Always — recurring checks for audience drift |
   | `/blue-contact:data-health` | Always — diagnostic on data quality, coverage, and completeness |

   Plus these always apply:
   - Ask Claude to analyze or query your data conversationally at any time.
   - Ask Claude to visualize any query results — charts, dashboards, comparisons, trend lines.

3. **Mention the data-analyst agent** — for complex multi-step analysis, Claude can use a specialized sub-agent.
4. **Highlight the visualization angle** — remind users that any time they query data, they can ask Claude to chart it, compare segments visually, or build a dashboard. This is a key differentiator: "You're not just pulling lists — you can explore and visualize your data interactively."

## Style Guidelines

- Be warm, conversational, and encouraging — this is onboarding, not a technical manual
- Use plain language. Avoid jargon unless you're explaining it
- Run real queries and show real numbers — this isn't a slideshow, it's hands-on
- **Always visualize.** After every meaningful set of query results, build a chart or dashboard. The pattern is: query → visualize → narrate. Never just show raw table results when a chart would tell the story better
- Make the first visualization in the session especially polished — this is the user's first impression of what the platform can do
- Keep individual responses focused — don't overwhelm with everything at once
- Let the user drive the pace. After each step, pause for their input
- If a query returns no results or an error, handle it gracefully and try a different angle
- Celebrate small wins: "Nice — you've got 2.3M consumer records with 68% phone coverage. That's a strong starting point."
- When presenting visualizations, briefly explain what the chart shows and highlight 1-2 key takeaways, then let the user explore
