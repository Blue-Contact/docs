# Topic playbooks

When the user picks a topic in Phase 2, read **only the matching section below**. Each follows the Phase 3 fire-and-narrate pattern: fire the marginal query immediately → narrate + load brand during the poll → render the static dashboard from the inlined skeleton in SKILL.md → narrate results → suggest one or two contextual next steps.

> **One topic = one tracked run** (exploration topics). Every *exploration* topic — Explore, Demographic snapshot, B2B, Mover, Property, Dealership — gathers all its data points in a **single** `run_audience_query` shaped as a flat `dimension, value, count` table (a `UNION ALL` of per-dimension `GROUP BY`s — demographic snapshot is the canonical example). Bullet lists under each topic are the *dimensions of that one query*, not separate queries. Never split into multiple runs, and don't use `execute_sql_query` in the tour — it's a real tool (see `data-querying`), but the tour's cost discipline is one `run_audience_query` per topic.
>
> **"Build your first audience"** is the one deliberate exception — it's a guided build. Even so, fold its count estimate and contact-coverage check into a **single** marginal `run_audience_query` (one run), then a second `run_audience_query` to create the audience. Two runs total, not a probe per metric.

> **Canonical columns first, schema fallback only on error.** Each topic below lists the standard column names. Fire the marginal query directly with those names — no preliminary `get_schema` call. If the platform errors with "column not found" or similar, *then* call `get_schema(database, table)` to find the real names and retry. For the major databases this fallback is rare; skipping the proactive schema fetch is what gets the topic to ~15s instead of 20–25s.

## Explore your data
- Call `get_schema(database: "...", table: "...")` for the relevant tables (scope by table; the no-`table` whole-database call is fine only for small databases)
- Walk through the table structure and highlight the most useful columns
- Show the user which databases they have and what each is good for (use `display_name` from the schema response, not internal names)
- Show an example of how filters work with a simple count query
- **Visualization:** Data landscape overview .jsx — total record counts per database/table as a bar chart, plus stat cards (total records, databases, tables) at the top

## Demographic snapshot (consumer)

**Use the reliable compact-marginal pattern — NOT a multi-dimensional cube.** One `run_audience_query` returning ~30 rows of `dimension, value, consumers` via `UNION ALL` of per-dimension `GROUP BY`s — one page, one tracked run, dashboard built directly from it.

**Canonical SQL — fire this directly** (prefix every table with the fully-qualified `<catalog>.<database>.` from the Phase 1 schema summary's `datasource` + `name` fields — shown bare below for brevity, but Athena requires the three-part form):

```sql
SELECT 'age' AS dimension,
       CASE WHEN age < 25 THEN '18-24' WHEN age < 35 THEN '25-34'
            WHEN age < 45 THEN '35-44' WHEN age < 55 THEN '45-54'
            WHEN age < 65 THEN '55-64' WHEN age >= 65 THEN '65+'
            ELSE 'Unknown' END AS value,
       COUNT(*) AS consumers
FROM individual GROUP BY 1, 2
UNION ALL SELECT 'income',
       CASE WHEN income < 25000 THEN '<$25K' WHEN income < 50000 THEN '$25-50K'
            WHEN income < 75000 THEN '$50-75K' WHEN income < 100000 THEN '$75-100K'
            WHEN income < 150000 THEN '$100-150K' WHEN income >= 150000 THEN '$150K+'
            ELSE 'Unknown' END,
       COUNT(*) FROM individual GROUP BY 1, 2
UNION ALL SELECT 'ownership',
       CASE homeowner_status WHEN 'H' THEN 'Owner' WHEN 'R' THEN 'Renter' ELSE 'Unknown' END,
       COUNT(*) FROM individual GROUP BY 1, 2
UNION ALL SELECT 'state', state, COUNT(*) FROM individual GROUP BY 1, 2
UNION ALL SELECT 'coverage', 'Has Phone', COUNT(DISTINCT p.id)
  FROM individual i LEFT JOIN (SELECT DISTINCT Id AS id FROM consumer_phone WHERE phone <> '') p ON p.id = i.Id
UNION ALL SELECT 'coverage', 'Has Email', COUNT(DISTINCT e.id)
  FROM individual i LEFT JOIN (SELECT DISTINCT Id AS id FROM consumer_email WHERE email <> '') e ON e.id = i.Id
```

Canonical column names: `individual.age`, `individual.income`, `individual.homeowner_status` (codes `H`/`R`/`U`), `individual.state`; contact tables `consumer_phone(Id, phone)`, `consumer_email(Id, email)`. If any error, fall back to `get_schema(database, table)` and adjust.

Why this and not a cube:
- **The platform's SQL auto-fixer reshapes multi-dimensional cubes unpredictably** — observed to collapse `state × age × income × ownership` into a flat profile, expand it with extra dimensions past one page (so a single page is incomplete), and hard-fail on `TABLESAMPLE`. The flat `dimension/value/count` shape mirrors what the platform itself emits, so it passes intact. **Don't use `GROUPING SETS` or `CUBE` here** — the flat `UNION ALL` is the shape that survives.
- **No `TABLESAMPLE` in a marginal query.** This query reports *exact* counts over the whole table, and sampling would silently skew every number in the dashboard. That is not in tension with the `data-querying` safety rule requiring `TABLESAMPLE SYSTEM (1)`: that rule governs **unfiltered row samples** of large tables (`SELECT * … LIMIT`), a different job from aggregation. Rule of thumb — sample rows with `TABLESAMPLE`, count rows without it.
- **One bounded run = predictable cost.** Single Athena scan, one small page, no pagination.
- **Contact coverage is a join, not a column.** Phone/email live in separate one-to-many tables keyed on `Id`. `COUNT(phone)` is wrong; use the deduped semi-join above.

**Always keep an explicit Unknown bucket** (treat `''` as NULL — large shares of some fields are unpopulated; silently dropping them is misleading).

**Validate before charting.** Confirm `columns` are `[dimension, value, consumers]` (the platform may add a `total_count` column — ignore it). Pivot by `dimension` and build the static multi-chart dashboard: hero total + phone/email coverage bars, then age (bar), income (bar), ownership (donut), top states (horizontal bar). That static dashboard is the deliverable, not a fallback.

**Interactive "slice-it-yourself" cube — opt-in only.** Attempt only when you can guarantee the result stays ≤1,000 rows *after any auto-fixer expansion* and the returned columns match what you asked for. Otherwise fall back to the static marginal dashboard. See `references/visualization-guide.md` for the pattern.

## B2B exploration
- Show industry breakdown (SIC or NAICS)
- Employee count and revenue distributions
- Geographic spread
- Contact availability

**Canonical columns:** `companies.naics_code` (or `sic_code`), `companies.employee_count`, `companies.annual_revenue`, `companies.state`, `companies.phone`, `companies.email`. Marginal query buckets:
- Industry: `LEFT(naics_code, 2)` (2-digit NAICS sector), keep top 12
- Employee size: 1-9, 10-49, 50-249, 250-999, 1000+, Unknown
- Revenue tier: <$1M, $1-10M, $10-100M, $100M-1B, $1B+, Unknown
- State: top 12 by company count
- Coverage: has-phone, has-email (counted directly on the `companies` table)

If column names differ, fall back to `get_schema(database: "<b2b-db>", table: "companies")`.

**Visualization:** B2B landscape dashboard .jsx — top industries as horizontal bar, company-size and revenue tiers as bar charts, top states as horizontal bar.

## Mover data
- Show recent volume by month or quarter
- Origin vs destination analysis
- Mover type breakdown (individual, family, etc.)
- Key fields available for targeting

**Canonical columns:** `movers.move_date` (or `move_month`), `movers.origin_state`, `movers.destination_state`, `movers.mover_type`. Marginal query dimensions:
- Volume by month (last 12 months): `DATE_TRUNC('month', move_date)`
- Top origin states (top 12)
- Top destination states (top 12)
- Mover type breakdown

If column names differ, fall back to `get_schema(database: "<mover-db>", table: "movers")`.

**Visualization:** Mover trends dashboard .jsx — monthly volume as line/area (hero chart), origin vs destination as paired horizontal bars, mover type as donut.

## Property records
- Property type distribution
- Value ranges and medians
- Geographic coverage
- Year built distribution

**Canonical columns:** `properties.property_type`, `properties.value` (or `assessed_value`), `properties.year_built`, `properties.state`. Bucket boundaries:
- Property type: as-is (donut)
- Value buckets: <$100K, $100-250K, $250-500K, $500K-1M, $1M+
- Year built: pre-1950, 1950-1979, 1980-1999, 2000-2019, 2020+
- State: top 12

If column names differ, fall back to `get_schema(database: "<property-db>", table: "properties")`.

**Visualization:** Property insights dashboard .jsx — property type as donut, value distribution as histogram, year-built timeline as bar, top states as horizontal bars.

## Dealership lookup
- Available makes/brands
- Geographic coverage by state
- Dealer count summaries
- How to search for specific dealers or makes

**Canonical columns:** `dealerships.make`, `dealerships.state`. Marginal query dimensions:
- Top makes by dealer count (top 15)
- Dealers by state (top 12)
- Total dealer count (single COUNT)
- Total distinct make count

If column names differ, fall back to `get_schema(database: "<dealership-db>", table: "dealerships")`.

**Visualization:** Dealership overview .jsx — top makes as horizontal bar, dealers by state as bar chart, total dealer/make counts as stat cards.

## Build your first audience
- Walk the user through the full audience-building workflow step by step
- Help them pick a target (geography + demographics or firmographics)
- Run a single combined marginal query that folds count estimate AND contact coverage into one `run_audience_query` (one tracked run)
- Use a second `run_audience_query` to create the audience itself (two runs total — count it explicitly when telegraphing the wait)
- Explain the results and what they can do next (download CSV, refine, segment)
- **Visualization:** Audience profile dashboard .jsx after the audience is built — total size as hero stat, geographic breakdown as bar, key demographic splits relevant to the filters, contact coverage (phone %, email %) as progress bars, and a "what you can do next" section with action suggestions
- **After the audience is finalized**, offer the QA path inline (no `AskUserQuestion` turn): *"If you want to share this audience's logic as a doc your team can QA and send back with changes, just say the word — I'll trigger `audience-logic-report`."* Then continue — don't wait on a button click.
