# Visualization guide

**On-demand reference.** The dashboard skeleton is inlined in SKILL.md — author from there. Load this file only when:
- You need chart-selection guidance for an unusual data shape (the basics are obvious — bar for distributions, donut for category mix, line for time series)
- You're attempting the opt-in interactive "slice-it-yourself" cube
- You need to look up brand/Recharts conventions beyond the skeleton

## How to create visualizations

- Write a self-contained React component (.jsx) using Recharts for charts and inline styles for layout (the skeleton in SKILL.md is the model)
- Save the file and present it — it renders as an interactive artifact
- Available chart libraries: `recharts` (BarChart, PieChart, LineChart, AreaChart, etc.), `d3`, `plotly`
- Include the data inline in the component (extracted from query results)

## Chart selection

- Geographic distributions → horizontal bar chart (top 10–15 states) or a colored US map
- Age/income distributions → vertical bar chart or histogram
- Category breakdowns (property type, industry, mover type) → donut/pie chart or horizontal bars
- Time series (mover volume by month) → line chart or area chart
- Coverage rates (phone %, email %) → gauge-style display or stacked bar
- Comparisons (origin vs destination, owner vs renter) → grouped bar chart or side-by-side
- Multi-metric dashboards → combine 2–4 charts in a responsive grid layout

## Best practices

- Use the Blue Contact brand palette from `${CLAUDE_PLUGIN_ROOT}/brand/brand.json` — `contactBlue` as primary, with seafoam and other tokens. The `BRAND` block in the SKILL.md skeleton already encodes the defaults; replace hex values only if `brand.json` differs.
- Always include clear titles, axis labels, and data labels where they help readability
- Add a subtle "Blue Contact" attribution at the bottom (the skeleton has this)
- Format numbers with commas and units (K, M for large numbers — the skeleton's `fmtM` helper does this)
- Make charts responsive — they should look good at any width
- First visualization in a session is the "wow" moment — multi-chart dashboard, polished

## Static vs. interactive

**Default to a static multi-chart dashboard** built from a compact marginal query (see the demographic-snapshot playbook). It's reliable, one page, one tracked run, strong first impression.

**Interactive "slice-it-yourself" cube — opt-in upgrade, only when the data supports it.** Pattern: "pre-fetch a cube, slice it locally."

1. **Pre-fetch a small crosstab** with a single `run_audience_query` (not `execute_sql_query` — the tour keeps to single `run_audience_query` calls for cost discipline). Keep to a handful of low-cardinality dimensions, and **verify it stays ≤1,000 rows after any auto-fixer reshaping** — the fixer can add dimensions and push past one page, leaving a single page incomplete. If you can't guarantee that, use the static dashboard.
2. **Embed the cube inline** in the .jsx as a compact array literal.
3. **Render interactive controls** (pill-style checkboxes per dimension + a reachability toggle) that re-aggregate the cube in a `useMemo` on every change.
4. **Include a "Send filters back to Claude" panel** mirroring the current filter state as a natural-language prompt, so the user can promote a slice into a real `run_audience_query`.

**Always validate the returned `columns` before charting**, and fall back to the static dashboard whenever the shape isn't what you requested.
