---
name: audience-compare
description: Compare two Blue Contact audiences side-by-side — demographic differences, geographic skew, coverage gaps, and overlap analysis with visual dashboards
argument-hint: "audience A vs audience B (IDs or descriptions)"
allowed-tools:
  - mcp__blue-contact__get_schema
  - mcp__blue-contact__get_query_instructions
  - mcp__blue-contact__validate_sql
  - mcp__blue-contact__run_audience_query
  - mcp__blue-contact__execute_sql_query
  - mcp__blue-contact__get_audience_run
  - mcp__blue-contact__get_audience
  - mcp__blue-contact__list_audiences
  - mcp__blue-contact__save_message
  - mcp__blue-contact__save_artifact
  - Read
  - Write
---

# Audience Comparison

Compare two audiences to understand how they differ — demographics, geography, coverage, size — and present the findings as an interactive side-by-side dashboard.

## Async query results

This skill runs parallel `execute_sql_query` probes against two audiences (size, coverage, geographic, demographic). Each is asynchronous — the kick-off returns `{status: "queued", run_id, ...}` with no rows. After each kick-off, poll `get_audience_run` with the returned `run_id` every 2–5 seconds until `status: "completed"`, then read the rows from that response. You can kick off the two audiences' probes in parallel, then poll each `run_id` in turn — both queries run concurrently on the worker dyno. Full pattern: `${CLAUDE_PLUGIN_ROOT}/skills/audience-building/SKILL.md` → "Polling for results".

## Brand Configuration

Before generating any visual output, read `${CLAUDE_PLUGIN_ROOT}/brand/BRAND.md` for the official Blue Contact brand guide, then load color tokens from `${CLAUDE_PLUGIN_ROOT}/brand/brand.json`. The `brand/` directory lives at the plugin root, not the session working directory. All visual artifacts must use these brand colors — never invent your own.

**Every visual artifact must include the Blue Contact icon at minimum.** Embed the icon (`${CLAUDE_PLUGIN_ROOT}/brand/logos/icon-gradient.svg`) or, for headers, the horizontal logo (`${CLAUDE_PLUGIN_ROOT}/brand/logos/horizontal-gradient.svg`). See `${CLAUDE_PLUGIN_ROOT}/brand/BRAND.md` for placement guidance per artifact type.

**Fallback palette** — if the brand files cannot be read, do not ship an unbranded artifact; use these tokens: contactBlue `#006AFF` (primary), graphite `#2A3A57` (text), clearSky `#334669` (secondary text), seafoam `#12C7B4` (accent), eggshell `#E4E9F5` (backgrounds/borders), success `#00C864`, danger `#DB4646`, hazard `#FF9A1F`, gradient `linear-gradient(135deg, #1A94FF 0%, #006AFF 100%)`. Chart series order: `#006AFF`, `#1994FF`, `#12C7B4`, `#334669`, `#FF9A1F`, `#00C864`. Every artifact carries the footer attribution "Data provided by Blue Contact".

## Workflow

### 1. Identify the two audiences

The user might provide:
- Two audience IDs → use `get_audience` for each
- One audience ID and a new description → load the existing one, build a query for the new one
- Two descriptions → build queries for both
- "Compare my last two audiences" → use `list_audiences` to find the two most recent

Extract the SQL query and filters for each audience. Label them clearly (e.g., "Audience A: Texas Homeowners 35-54" vs "Audience B: Florida Homeowners 35-54").

### 2. Run parallel analysis

For each audience, run the same set of analytical queries so the results are directly comparable. Use `execute_sql_query` for these exploratory queries, passing the `audience_id` of the audience you're probing — every probe is recorded as an ad-hoc message + run on that audience without overwriting its canonical SQL. If the comparison includes an audience that doesn't exist yet (a new description rather than an existing ID), build it first with `run_audience_query` and use the returned `audience_id` for the probes.

**Size & Coverage:**
```
Total record count
Phone coverage %
Email coverage %
Address completeness %
```

**Geographic breakdown:**
```
Top 10 states by record count (or cities/zips if both are state-specific)
```

**Demographic breakdown (if consumer):**
```
Age distribution (same buckets for both)
Income bracket distribution
Homeowner vs renter %
Gender split
```

**Firmographic breakdown (if B2B):**
```
Top industries
Employee count distribution
Revenue tier distribution
```

### 3. Compute comparison metrics

After gathering data for both audiences, compute:
- **Size ratio**: How much larger/smaller is A vs B?
- **Coverage delta**: Difference in phone/email rates
- **Geographic concentration**: Which states index higher in A vs B?
- **Demographic skew**: Where do the age/income/homeowner distributions diverge?
- **Index scores**: For each dimension, compute an index (A rate / B rate × 100) to show relative over/under-representation

### 4. Build the comparison dashboard

Create a React (.jsx) visualization that shows both audiences side by side:

**Layout:**
- **Header**: Audience A name vs Audience B name, with total counts as hero stats
- **Size & Coverage panel**: Grouped bar chart or stat cards comparing totals, phone %, email %
- **Geographic comparison**: Side-by-side horizontal bar charts (or a diverging bar chart with A on left, B on right)
- **Demographic comparison**: Grouped bar charts for age and income, with both audiences overlaid
- **Key differences callout**: Highlight the 3-5 dimensions where the audiences diverge most, with index scores

**Design:**
- Use two distinct colors for A vs B (e.g., contactBlue from brand config for A, seafoam or hazard for B)
- Include clear legends
- Format numbers consistently
- Add a "Key Differences" summary section at the bottom

**Persist to both audiences:** After creating the comparison visualization, call `save_artifact` twice — once for each audience — so the comparison is accessible from either audience's page. Detect `artifact_type` from the source code (`"react_dashboard"` for JSX, `"html"` for HTML):
```
save_artifact(
  audience_id: <audience A ID>,
  title: "<A title> vs <B title> — Comparison",
  source_code: <the complete source code>,
  artifact_type: <"react_dashboard" or "html">,
  metadata: { "generated_by": "audience-compare", "compared_with": <audience B ID> }
)
save_artifact(
  audience_id: <audience B ID>,
  title: "<A title> vs <B title> — Comparison",
  source_code: <the complete source code>,
  artifact_type: <"react_dashboard" or "html">,
  metadata: { "generated_by": "audience-compare", "compared_with": <audience A ID> }
)
```

### 5. Narrate the findings

After presenting the dashboard, provide a conversational summary:
- Which audience is larger and by how much
- Where they differ most (geography, age, income, coverage)
- Which has better contact coverage
- Any surprising findings or patterns
- Recommendations: "If you need phone reachability, Audience A has 12% better coverage" or "Audience B skews younger — better for digital campaigns"

### 6. Suggest next steps

- "Want to merge these into a combined audience?"
- "Should we create a third audience that captures the overlap?"
- "Want to drill deeper into a specific difference?"
- "Ready to generate a report for either audience?" (→ `audience-report` skill)
