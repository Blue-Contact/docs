---
name: setup
description: Use when the Blue Contact connector is missing, unauthenticated, or erroring, or right after plugin install — detects the connection state and walks the user through fixing it
---

# Blue Contact Setup

When a user first installs this plugin or hits a connection issue, walk them through these steps. Step 1 actively detects what's wrong; subsequent steps assume the connector is working.

## 1. Detect the connector state

Probe the connector by calling `ping`. Classify the outcome into one of three states and follow the matching remediation flow:

### State A — Connected (ping returned `ok: true`)

The connector is enabled and authenticated. Greet the user with the account name and email returned by `ping`, then proceed to step 2.

### State B — Connector missing (the `ping` tool isn't available in the session)

The Blue Contact MCP connector hasn't been installed. Walk the user through enabling it:

- **In Cowork:** open **Settings → Connectors**, click **Add connector**, choose **Blue Contact**, and confirm it appears as Enabled.
- **In Claude Code:** the plugin bundles the connector in its `.mcp.json`, so it normally registers automatically. Have the user restart Claude Code (or disable/re-enable the plugin) so it loads. Only if it still doesn't appear: run `/mcp` and add an HTTP connector pointing at `https://query.bluecontact.com/mcp` manually — but check first, since adding it manually alongside the bundled one creates a duplicate server entry.

After they've enabled it, use `AskUserQuestion` to offer:

- **"I've enabled it — retry"** (recommended) — re-run step 1.
- **"I'll do this later"** — exit gracefully with a one-line note that nothing else in the plugin will work until the connector is enabled.

### State C — Connector present but unauthenticated (`ping` returned a 401 / auth error)

The connector is installed but OAuth hasn't been completed. Walk them through:

- Click the Blue Contact connector in the Connectors panel.
- Complete the OAuth 2.1 sign-in at `auth.bluecontact.com`.
- Wait for the panel to show **Connected**.

Then offer the same retry loop:

- **"I've signed in — retry"** (recommended) — re-run step 1.
- **"I'll do this later"** — exit gracefully.

## 2. Summarize the user's data access

Call `get_schema` with no parameters. Read the `databases` array. Briefly describe what the user has access to — one sentence per database, using the `display_name` field for the friendly label. Frame this as their data landscape, not a configuration list.

Example tone (do not hard-code; derive each line from the schema response):

> "You've got access to four databases: **Consumer** for individual demographics and contact info, **B2B** for business records, **Movers** for recent relocations, and **Property** for real estate."

Keep it under five lines. If the user has a database that doesn't have a recognized `category`, show its `display_name` plain.

## 3. Test connectivity with a real query (optional)

Steps 1–2 (`ping` + `get_schema`) already prove the connector and auth work. A live query additionally verifies end-to-end Athena execution — but **there is no untracked SQL path**, so this creates a small throwaway audience and a billing-tracked run. Offer it rather than running it silently: "Want me to run a quick test query? It creates one small tracked run." If accepted, run a `SELECT COUNT(*) FROM ...` against the smallest database from step 2 (avoid `SELECT 1` — it can fail the SQL validator).

If it errors, the connector is authenticated but the underlying Athena access is broken — surface the error message to the user and suggest contacting `support@bluecontact.com`.

## 4. Load a table's schema (optional warm-up)

Call `get_schema(database: "<one of the user's databases>", table: "<a table in it>")` to load a table's column-level schema. Scope to a single table rather than the whole database — large databases can be slow or get truncated, and the call caches per (database, table). This surfaces typed columns, valid option values, and prompt guidance. The databases enumerated in step 2 are the source of truth for what's worth probing here — don't probe databases the user doesn't have. (For wide tables you can narrow further with `columns: [...]`; very high-cardinality columns return their options summarized rather than fully enumerated.)

## 5. Set expectations

Let the user know:

- Queries run against AWS Athena (Presto/Trino SQL dialect).
- Results return directly in the conversation; complex audience pulls may take 10–30 seconds.
- The `get_query_instructions` tool provides the SQL guidelines the platform enforces.
- All queries are SELECT-only — no DDL, DML, or semicolons.
- Beyond querying, they can upload their own files as queryable tables, match them against the Blue Contact library, and build data-driven personas (`/blue-contact:my-data` and `/blue-contact:personas`). Mention this in one sentence — don't tour it here.

## 6. Hand off to the guided tour

Once setup is verified, immediately offer the `getting-started` tour. Use `AskUserQuestion`:

- **"Yes — give me the tour"** (recommended) — launch `getting-started`. The schema is already loaded from steps 2–4, so it can skip its initial discovery call and jump into the personalized overview.
- **"Not now — I'll explore on my own"** — wrap up with a short pointer to the key slash commands (`/blue-contact:audience-pull`, `/blue-contact:industry-playbooks`, `/blue-contact:market-sizing`, `/blue-contact:my-data` for uploading their own lists) and let them drive.
