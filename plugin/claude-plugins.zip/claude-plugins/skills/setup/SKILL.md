---
name: setup
description: Guide the user through connecting and configuring Blue Contact
---

# Blue Contact Setup

When a user first installs this plugin or hits a connection issue, walk them through these steps. Step 1 actively detects what's wrong; subsequent steps assume the connector is working.

## 1. Detect the connector state

Probe the connector by calling `ping`. Classify the outcome into one of three states and follow the matching remediation flow:

### State A — Connected (ping returned `ok: true`)

The connector is enabled and authenticated. Greet the user with the account name and email returned by `ping`, then proceed to step 2.

### State B — Connector missing (the `ping` tool isn't available in the session)

The Blue Contact MCP connector hasn't been installed. Walk the user through enabling it:

- **In Cowork:** open **Settings → Connectors**, click **Add connector**, choose **Blue Contact**, and confirm it appears as Enabled.
- **In Claude Code:** run `/mcp` and add an HTTP connector pointing at `https://query.bluecontact.com/mcp`. This URL matches the plugin's `.mcp.json`.

After they've enabled it, use `AskUserQuestion` to offer:

- **"I've enabled it — retry"** (recommended) — re-run step 1.
- **"I'll do this later"** — exit gracefully with a one-line note that nothing else in the plugin will work until the connector is enabled.

### State C — Connector present but unauthenticated (`ping` returned a 401 / auth error)

The connector is installed but OAuth hasn't been completed. Walk them through:

- Click the Blue Contact connector in the Connectors panel.
- Complete the OAuth 2.1 sign-in at `auth.bluecontact.com`.
- Wait for the panel to show **Connected**.

Then offer the same retry loop:

- **"I've signed in — retry"** (recommended) — re-run step 1.
- **"I'll do this later"** — exit gracefully.

## 2. Summarize the user's data access

Call `get_schema` with no parameters. Read the `databases` array. Briefly describe what the user has access to — one sentence per database, using the `display_name` field for the friendly label. Frame this as their data landscape, not a configuration list.

Example tone (do not hard-code; derive each line from the schema response):

> "You've got access to four databases: **Consumer** for individual demographics and contact info, **B2B** for business records, **Movers** for recent relocations, and **Property** for real estate."

Keep it under five lines. If the user has a database that doesn't have a recognized `category`, show its `display_name` plain.

## 3. Test connectivity with a real query

Run a simple count query against one of the user's actual databases (pick one from step 2). Avoid `SELECT 1` — it can fail the SQL validator. A `SELECT COUNT(*) FROM ...` against the smallest database is fine.

If this errors, the connector is authenticated but the underlying Athena access is broken — surface the error message to the user and suggest contacting `support@bluecontact.com`.

## 4. Load the full schema for one database (optional warm-up)

Call `get_schema(database: "<one of the user's databases>")` to load the column-level schema. This warms the cache and surfaces typed columns, valid option values, and prompt guidance. The set of databases enumerated in step 2 is the source of truth for what's worth probing here — don't probe databases the user doesn't have.

## 5. Set expectations

Let the user know:

- Queries run against AWS Athena (Presto/Trino SQL dialect).
- Results return directly in the conversation; complex audience pulls may take 10–30 seconds.
- The `get_query_instructions` tool provides the SQL guidelines the platform enforces.
- All queries are SELECT-only — no DDL, DML, or semicolons.

## 6. Hand off to the guided tour

Once setup is verified, immediately offer the `getting-started` tour. Use `AskUserQuestion`:

- **"Yes — give me the tour"** (recommended) — launch `getting-started`. The schema is already loaded from steps 2–4, so it can skip its initial discovery call and jump into the personalized overview.
- **"Not now — I'll explore on my own"** — wrap up with a short pointer to the key slash commands (`/blue-contact:audience-pull`, `/blue-contact:industry-playbooks`, `/blue-contact:data-health`) and let them drive.
