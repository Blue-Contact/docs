---
name: audience-report
description: Generate polished PPTX or PDF reports from Blue Contact audiences — demographics, coverage, visualizations, and insights ready for stakeholder sharing
argument-hint: "audience ID or 'latest'"
allowed-tools:
  - mcp__blue-contact__get_schema
  - mcp__blue-contact__get_query_instructions
  - mcp__blue-contact__validate_sql
  - mcp__blue-contact__execute_sql_query
  - mcp__blue-contact__get_audience_run
  - mcp__blue-contact__get_audience
  - mcp__blue-contact__list_audiences
  - mcp__blue-contact__save_message
  - mcp__blue-contact__save_artifact
  - AskUserQuestion
  - Read
  - Write
---

# Audience Report Generator

Generate a polished, stakeholder-ready report from a Blue Contact audience. The report includes audience overview, demographic breakdowns, geographic distribution, contact coverage analysis, and key insights — all with professional visualizations.

## Async query results

This skill runs many `execute_sql_query` probes in sequence (size, coverage, geographic, demographic, etc.). Each is asynchronous — the kick-off returns `{status: "queued", run_id, ...}` with no rows. After each kick-off, poll `get_audience_run` with the returned `run_id` every 2–5 seconds until `status: "completed"`, then read `rows` / `columns` / `coverage_summary` from that response and continue. Never re-submit the *same* SQL while its run is in flight — that's what creates duplicate runs. Distinct probes may be kicked off concurrently and polled in turn, but running them sequentially is fine too and simpler to track. Full pattern: `${CLAUDE_PLUGIN_ROOT}/skills/audience-building/SKILL.md` → "Polling for results".

## Brand Configuration

Before generating any visual output, read `${CLAUDE_PLUGIN_ROOT}/brand/BRAND.md` for the official Blue Contact brand guide, then load color tokens from `${CLAUDE_PLUGIN_ROOT}/brand/brand.json`. The `brand/` directory lives at the plugin root, not the session working directory. All visual artifacts must use these brand colors — never invent your own.

**Every visual artifact must include the Blue Contact icon at minimum.** Embed the icon (`${CLAUDE_PLUGIN_ROOT}/brand/logos/icon-gradient.svg`) or, for headers, the horizontal logo (`${CLAUDE_PLUGIN_ROOT}/brand/logos/horizontal-gradient.svg`). For PPTX, place the logo on the title slide and a small icon in the footer of every content slide. For PDF, place the horizontal logo in the page header. See `${CLAUDE_PLUGIN_ROOT}/brand/BRAND.md` for placement guidance per artifact type.

**Fallback palette** — if the brand files cannot be read, do not ship an unbranded artifact; use these tokens: contactBlue `#006AFF` (primary), graphite `#2A3A57` (text), clearSky `#334669` (secondary text), seafoam `#12C7B4` (accent), eggshell `#E4E9F5` (backgrounds/borders), success `#00C864`, danger `#DB4646`, hazard `#FF9A1F`, gradient `linear-gradient(135deg, #1A94FF 0%, #006AFF 100%)`. Chart series order: `#006AFF`, `#1994FF`, `#12C7B4`, `#334669`, `#FF9A1F`, `#00C864`. Every artifact carries the footer attribution "Data provided by Blue Contact".

## Workflow

### 1. Identify the audience

- If the user provides an audience ID, use `get_audience` to load it
- If the user says "latest" or doesn't specify, call `list_audiences` and pick the most recent active audience
- If no audiences exist, let the user know and offer to build one first (suggest the `audience-pull` skill)
- Extract the audience's SQL query, title, and reasoning from the audience state

### 2. Ask about report preferences

Use `AskUserQuestion` to clarify:
- **Format**: PPTX presentation or PDF one-pager? (default: PPTX)
- **Depth**: Executive summary (3-5 slides / 1 page) or detailed deep-dive (8-12 slides / 2-3 pages)?
- **Branding**: Should we include the user's company name or logo? (ask for company name if so)
- **Focus areas**: Which breakdowns matter most? (geography, demographics, contact coverage, all of the above)

### 3. Gather the data

Run a series of analytical queries against the same filters used in the audience's SQL. Adapt the queries based on what columns are available (check the schema first):

**Core metrics (always include):**
- Total record count
- Phone coverage rate (count with phone / total)
- Email coverage rate (count with email / total)
- Address completeness rate

**Geographic breakdown:**
- Top 10-15 states by record count
- If the audience is state-specific, break down by city or zip instead

**Demographic breakdowns (if consumer data):**
- Age distribution (group into buckets: 18-24, 25-34, 35-44, 45-54, 55-64, 65+)
- Income brackets
- Homeowner vs renter split
- Gender distribution
- Presence of children

**Firmographic breakdowns (if B2B data):**
- Top industries (SIC/NAICS)
- Employee count distribution
- Revenue tiers

**Mover breakdowns (if mover data):**
- Move date distribution (by month/quarter)
- Origin vs destination states
- Mover type

**Property breakdowns (if property data):**
- Property type mix
- Value distribution
- Year built ranges

### 4. Build the report

For the full section-by-section layout spec (cover, stat grid, footers), see `examples/branded-report-structure.md` next to this skill. The `pptx` and `pdf` skills are Anthropic document skills, available by default in claude.ai/Cowork; if neither is available (possible in Claude Code), generate the file directly via Bash (`python-pptx` for PPTX, `reportlab` or HTML-to-PDF for PDF) following the same structure.

**For PPTX**: Use the `pptx` skill to create a professional presentation:

- **Slide 1 — Title**: Audience name, date generated, total records as hero number
- **Slide 2 — Executive Summary**: Key stats at a glance (total records, phone %, email %, top state, dominant age group). Use big stat callouts.
- **Slide 3 — Geographic Distribution**: Horizontal bar chart of top states (or cities/zips if localized)
- **Slide 4 — Demographic Profile**: Age + income distribution charts, homeowner/renter pie
- **Slide 5 — Contact Coverage**: Phone and email coverage as visual gauges/progress bars, with raw numbers
- **Slide 6+ (detailed only)** — Additional breakdowns: gender, children, industry, property type, etc.
- **Final Slide — Methodology**: The SQL filters used, data source note, date of pull

**For PDF**: Use the `pdf` skill to create a clean one-pager or multi-page report with the same data points.

### 5. Generate and persist visualizations

Create visualization artifacts alongside the report for interactive viewing:
- Use Recharts with Blue Contact brand colors from `${CLAUDE_PLUGIN_ROOT}/brand/brand.json` (contactBlue primary)
- Build a comprehensive dashboard that mirrors the report content
- Present the artifact so the user can interact with the charts

**Persist to the audience:** After creating the visualization, call `save_artifact` to attach it to the audience so it's accessible from the BlueQueryAI web app. Detect the artifact type from the source code:
- If the visualization is a React `.jsx` component (imports, export default), use `artifact_type: "react_dashboard"`
- If the visualization is self-contained HTML (inline scripts, SVG, Chart.js), use `artifact_type: "html"`

```
save_artifact(
  audience_id: <the audience ID>,
  title: "<Audience title> — Demographic Report",
  source_code: <the complete source code — JSX or HTML>,
  artifact_type: <"react_dashboard" or "html" based on what was generated>,
  metadata: { "generated_by": "audience-report", "chart_types": ["bar", "pie", "progress"] }
)
```
The artifact will be compiled and hosted automatically. Include the returned `share_url` when presenting results to the user.

### 6. Deliver and log

- Save the report file and present it to the user
- Present the visualization artifact
- Log the report generation to the audience's conversation history using `save_message`
- Offer next steps: "Want to refine the audience and regenerate?", "Need this in a different format?", "Ready to pull the full list for campaign execution?"

## Report Design Principles

- Clean, professional, minimal — no clutter
- Use Blue Contact brand colors from `${CLAUDE_PLUGIN_ROOT}/brand/brand.json` — contactBlue (#006AFF) for primary elements
- Large, readable stat callouts for key numbers
- Charts should be simple and self-explanatory
- Always include a data source attribution: "Data provided by Blue Contact"
- Format all numbers with commas; use K/M for large aggregates
- Include the date of the data pull on every report
