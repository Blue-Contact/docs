# Branded Report Structure

Section-by-section structure mirroring `specs/BlueContact_Audience_Report_Branded.docx`. Use this as the spec when generating a PPTX or PDF deliverable. Every section maps to one slide (PPTX) or one logical block (PDF).

The reference Node.js renderer is `specs/generate_branded_report.js` — that file is the canonical source for typography, color codes, and layout primitives. The `pptx` and `pdf` skills can produce the same shape.

## Cover / Title

- Background: white.
- Logo: `brand/logos/horizontal-gradient.svg`, top-left, ~25% page width.
- Title: audience name in large bold (Contact Blue `#006AFF`).
- Subtitle: total record count formatted with thousands separators ("412,847 individuals").
- Pull date in the format "April 21, 2026" near the bottom-right.
- Optional co-brand: client company name centered below the audience title in graphite (`#2A3A57`).

## Executive Summary

- Four big stat cards in a 2×2 grid:
  - Total records (big number, `#006AFF`).
  - Phone coverage % (gauge or bar).
  - Email coverage % (gauge or bar).
  - Top state / city (label + count).
- Below the grid: a one-paragraph human-readable narrative — what this audience is and why it's interesting. Two to three sentences.

## Geographic Distribution

- Horizontal bar chart, top 10–15 states (or top cities/zips if the audience is state-localized).
- Bars in Contact Blue (`#006AFF`), counts on the right axis with percent labels.
- Caption underneath: "Geographic concentration — top X represents Y% of the audience."

## Demographic Profile (consumer audiences)

- Two side-by-side bar charts:
  - Age distribution (5- or 10-year buckets).
  - Income brackets ($25K–$50K, $50K–$75K, etc.).
- Donut chart for homeowner vs. renter.
- Donut chart for presence of children (if relevant).

## Firmographic Profile (B2B audiences only)

- Top industries (SIC or NAICS) as a horizontal bar chart.
- Employee count distribution as a bar chart.
- Revenue tiers as a bar chart.

## Mover Profile (mover audiences only)

- Move date distribution by month — line or area chart.
- Origin vs. destination top-states comparison — paired horizontal bars.
- Mover type breakdown (individual vs. family) — donut.

## Property Profile (property audiences only)

- Property type mix — donut.
- Value distribution — histogram with buckets.
- Year-built timeline — bar chart.

## Contact Coverage

- Three progress bars or gauges: phone %, email %, address %.
- Show raw numbers alongside percentages: "302,209 with phone (73.2%)."
- One-sentence interpretation: what this means for campaign reachability.

## Methodology

- Bullet list of filters applied (field, operator, value).
- Data source attribution: "Data provided by Blue Contact."
- Pull date.
- One-line note on coverage caveat (page-level vs. full-audience).

## Footer (every content slide / page)

- Small Blue Contact icon (`brand/logos/icon-gradient.svg`) bottom-left.
- Page number / slide number bottom-right.
- Light rule line in `#D0D9EF` separating the footer from content.

## Color tokens (from `brand/brand.json`)

- Primary: Contact Blue `#006AFF`
- Body / dark headings: Graphite `#2A3A57`
- Accent: Seafoam `#12C7B4`
- Background tint: Eggshell `#E4E9F5`
- Light rule: `#D0D9EF`
- Status: Success `#00C864`, Danger `#DB4646`, Hazard `#FF9A1F`

Never hardcode these in rendering code — read them from `brand/brand.json` so a brand refresh propagates automatically.
