---
name: audience-monitor
description: Set up scheduled monitoring for Blue Contact audiences — track count changes, coverage trends, and get alerts when your data shifts
allowed-tools:
  - mcp__blue-contact__get_schema
  - mcp__blue-contact__get_query_instructions
  - mcp__blue-contact__validate_sql
  - mcp__blue-contact__execute_sql_query
  - mcp__blue-contact__get_audience_run
  - mcp__blue-contact__get_audience
  - mcp__blue-contact__list_audiences
  - mcp__blue-contact__save_message
  - mcp__blue-contact__save_artifact
  - AskUserQuestion
  - Read
  - Write
---

# Audience Monitoring

Set up recurring checks on Blue Contact audiences to track how they change over time. Useful for monitoring mover volume, tracking audience growth/decline, and catching coverage shifts.

## Brand Configuration

Before generating any visual output, read `${CLAUDE_PLUGIN_ROOT}/brand/BRAND.md` for the official Blue Contact brand guide, then load color tokens from `${CLAUDE_PLUGIN_ROOT}/brand/brand.json`. The `brand/` directory lives at the plugin root, not the session working directory. All visual artifacts must use these brand colors — never invent your own.

**Every visual artifact must include the Blue Contact icon at minimum.** Embed the icon (`${CLAUDE_PLUGIN_ROOT}/brand/logos/icon-gradient.svg`) or, for headers, the horizontal logo (`${CLAUDE_PLUGIN_ROOT}/brand/logos/horizontal-gradient.svg`). See `${CLAUDE_PLUGIN_ROOT}/brand/BRAND.md` for placement guidance per artifact type.

**Fallback palette** — if the brand files cannot be read, do not ship an unbranded artifact; use these tokens: contactBlue `#006AFF` (primary), graphite `#2A3A57` (text), clearSky `#334669` (secondary text), seafoam `#12C7B4` (accent), eggshell `#E4E9F5` (backgrounds/borders), success `#00C864`, danger `#DB4646`, hazard `#FF9A1F`, gradient `linear-gradient(135deg, #1A94FF 0%, #006AFF 100%)`. Chart series order: `#006AFF`, `#1994FF`, `#12C7B4`, `#334669`, `#FF9A1F`, `#00C864`. Every artifact carries the footer attribution "Data provided by Blue Contact".

## Workflow

### 1. Choose what to monitor

Use `AskUserQuestion` to understand what the user wants to track:

- **An existing audience** — Monitor an audience they've already built (get the ID from `list_audiences`)
- **A custom query** — Monitor a specific count or metric (e.g., "How many movers into Texas each week?")
- **Data coverage** — Track phone/email append rates for a segment over time

### 2. Define the monitoring parameters

Ask the user:
- **Frequency**: Daily, weekly, or monthly? (Use `AskUserQuestion`)
- **What to track**: Record count, contact coverage rates, geographic distribution, or all of the above?
- **Alert conditions** (optional): Should Claude notify them if the count changes by more than X%? If coverage drops below a threshold?

### 3. Build the monitoring query

Based on the user's selection, construct the SQL query that will run on each check:

**For audience monitoring:**
```sql
-- Get the audience's SQL from get_audience, then wrap it in a COUNT
SELECT COUNT(*) AS audience_size FROM (
  [original audience SQL]
)
```

**For coverage monitoring:**
```sql
-- Shape only — verify contact columns via get_schema first. Contact fields
-- differ by database, and in some schemas phone/email live in separate join
-- tables (e.g. consumer_phone / consumer_email) rather than inline columns;
-- in that case use the semi-join pattern from the audience-building skill
-- instead of COUNT(column). Treat '' as NULL (NULLIF(col, '')).
SELECT
  COUNT(*) AS total,
  COUNT(NULLIF(phone, '')) AS with_phone,
  COUNT(NULLIF(email, '')) AS with_email,
  ROUND(COUNT(NULLIF(phone, '')) * 100.0 / COUNT(*), 1) AS phone_pct,
  ROUND(COUNT(NULLIF(email, '')) * 100.0 / COUNT(*), 1) AS email_pct
FROM catalog.database.table
WHERE [filters]
```

**For mover volume tracking:**
```sql
SELECT
  COUNT(*) AS mover_count
FROM catalog.database.movers_table
WHERE [geographic filters]
  AND move_date >= DATE_ADD('day', -7, CURRENT_DATE)  -- last 7 days for weekly
```

### 4. Create the scheduled task

Use the platform's scheduling mechanism to set up the recurring check — in Claude Code, the `schedule` skill (scheduled cloud agents) or a cron-based scheduled run; in Cowork, a scheduled task. There is no Blue Contact MCP tool for scheduling. The scheduled run should **delegate to the `data-monitor` agent** rather than running the work inline — the agent is purpose-built for this, runs on the cheaper haiku model, and writes a structured summary the next run can diff against. If the environment has no scheduling mechanism available, say so and offer the manual fallback: the user re-invokes this skill whenever they want a check, and the diff logic works the same.

**Example cron expressions:**
- Daily at 8am: `0 8 * * *`
- Weekly on Monday at 9am: `0 9 * * 1`
- Monthly on the 1st at 8am: `0 8 1 * *`

**Task prompt template (delegating to the agent):**
```
Invoke the `data-monitor` agent with these inputs:
- audience_id: [ID]
- metric: [count | coverage | count+coverage]
- alert_threshold_count_pct: [10 if not specified]
- alert_threshold_coverage_pct: [5 if not specified]

The agent will run the metric query, diff against the previous monitoring
summary in the audience's conversation history, and write a fresh
[monitor] line plus a human-readable note via save_message. Surface the
human-readable note as the task's notification output.
```

The agent's structured `[monitor] count=N phone=X% email=Y% address=Z% as_of=YYYY-MM-DD` line is the contract that lets each successive run pick up from the last. Don't override the agent's format with custom logic — it's how trends accumulate.

### 5. Confirm setup

After creating the scheduled task, confirm with the user:
- What's being monitored and how often
- When the first check will run
- How they'll be notified of results
- How to modify or cancel the monitor (update or disable the scheduled task)

### 6. Optional: Historical dashboard

If the user wants to see trends over time after several monitoring runs:
- Gather historical data points from the audience's conversation history (`get_audience` with message history)
- Build a React (.jsx) trend visualization using brand colors from `${CLAUDE_PLUGIN_ROOT}/brand/brand.json`, showing count/coverage over time as a line chart
- Highlight any significant changes or inflection points

**Persist the trend dashboard:** Call `save_artifact` to attach the trend chart to the audience. Detect `artifact_type` from the source code:
```
save_artifact(
  audience_id: <the audience ID>,
  title: "<Audience title> — Monitoring Trends",
  source_code: <the complete source code>,
  artifact_type: <"react_dashboard" or "html">,
  metadata: { "generated_by": "audience-monitor", "data_points": <number of monitoring runs> }
)
```

## Monitor Types

### Audience Size Monitor
Tracks total record count for a saved audience. Good for detecting data refreshes, seasonal shifts, or filter drift.

### Mover Volume Tracker
Tracks new mover volume for a geography. Particularly valuable because mover data changes constantly — weekly monitoring catches trends early.

### Coverage Watchdog
Monitors phone and email append rates for a segment. Alerts if coverage drops, which could indicate data quality issues or changes in append sources.

### Market Pulse
Monitors multiple metrics for a broad market definition — combines count, coverage, and top-state distribution into a weekly snapshot.

## Notes

- Monitoring uses `execute_sql_query` with the audience's `audience_id` so each check is recorded as an ad-hoc message + run on that audience without overwriting the canonical SQL. (Use `run_audience_query` only when the audience's filters are intentionally being updated.)
- Each monitoring run is lightweight — just a COUNT or summary query
- Historical data accumulates in the audience's conversation history via the ad-hoc messages each check writes; use `save_message` for any additional commentary.
- The scheduled task runs in its own session, so results are delivered as notifications
