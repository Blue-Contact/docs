---
name: audience-monitor
description: Set up scheduled monitoring for Blue Contact audiences — track count changes, coverage trends, and get alerts when your data shifts
allowed-tools:
  - blue-contact:get_schema
  - blue-contact:get_query_instructions
  - blue-contact:validate_sql
  - blue-contact:execute_sql_query
  - blue-contact:get_audience
  - blue-contact:list_audiences
  - blue-contact:save_message
  - blue-contact:save_artifact
---

# Audience Monitoring

Set up recurring checks on Blue Contact audiences to track how they change over time. Useful for monitoring mover volume, tracking audience growth/decline, and catching coverage shifts.

## Brand Configuration

Before generating any visual output, read `brand/BRAND.md` for the official Blue Contact brand guide, then load color tokens from `brand/brand.json`. All visual artifacts must use these brand colors — never hardcode color values.

**Every visual artifact must include the Blue Contact icon at minimum.** Embed the icon (`brand/logos/icon-gradient.svg`) or, for headers, the horizontal logo (`brand/logos/horizontal-gradient.svg`). See `brand/BRAND.md` for placement guidance per artifact type.

## Workflow

### 1. Choose what to monitor

Use `AskUserQuestion` to understand what the user wants to track:

- **An existing audience** — Monitor an audience they've already built (get the ID from `list_audiences`)
- **A custom query** — Monitor a specific count or metric (e.g., "How many movers into Texas each week?")
- **Data coverage** — Track phone/email append rates for a segment over time

### 2. Define the monitoring parameters

Ask the user:
- **Frequency**: Daily, weekly, or monthly? (Use `AskUserQuestion`)
- **What to track**: Record count, contact coverage rates, geographic distribution, or all of the above?
- **Alert conditions** (optional): Should Claude notify them if the count changes by more than X%? If coverage drops below a threshold?

### 3. Build the monitoring query

Based on the user's selection, construct the SQL query that will run on each check:

**For audience monitoring:**
```sql
-- Get the audience's SQL from get_audience, then wrap it in a COUNT
SELECT COUNT(*) AS audience_size FROM (
  [original audience SQL]
)
```

**For coverage monitoring:**
```sql
SELECT
  COUNT(*) AS total,
  COUNT(phone) AS with_phone,
  COUNT(email) AS with_email,
  ROUND(COUNT(phone) * 100.0 / COUNT(*), 1) AS phone_pct,
  ROUND(COUNT(email) * 100.0 / COUNT(*), 1) AS email_pct
FROM catalog.database.table
WHERE [filters]
```

**For mover volume tracking:**
```sql
SELECT
  COUNT(*) AS mover_count
FROM catalog.database.movers_table
WHERE [geographic filters]
  AND move_date >= DATE_ADD('day', -7, CURRENT_DATE)  -- last 7 days for weekly
```

### 4. Create the scheduled task

Use the `create_scheduled_task` tool to set up the recurring check. The task should **delegate to the `data-monitor` agent** rather than running the work inline — the agent is purpose-built for this, runs on the cheaper haiku model, and writes a structured summary the next run can diff against.

**Example cron expressions:**
- Daily at 8am: `0 8 * * *`
- Weekly on Monday at 9am: `0 9 * * 1`
- Monthly on the 1st at 8am: `0 8 1 * *`

**Task prompt template (delegating to the agent):**
```
Invoke the `data-monitor` agent with these inputs:
- audience_id: [ID]
- metric: [count | coverage | count+coverage]
- alert_threshold_count_pct: [10 if not specified]
- alert_threshold_coverage_pct: [5 if not specified]

The agent will run the metric query, diff against the previous monitoring
summary in the audience's conversation history, and write a fresh
[monitor] line plus a human-readable note via save_message. Surface the
human-readable note as the task's notification output.
```

The agent's structured `[monitor] count=N phone=X% email=Y% address=Z% as_of=YYYY-MM-DD` line is the contract that lets each successive run pick up from the last. Don't override the agent's format with custom logic — it's how trends accumulate.

### 5. Confirm setup

After creating the scheduled task, confirm with the user:
- What's being monitored and how often
- When the first check will run
- How they'll be notified of results
- How to modify or cancel the monitor (update or disable the scheduled task)

### 6. Optional: Historical dashboard

If the user wants to see trends over time after several monitoring runs:
- Gather historical data points from the audience's conversation history (`get_audience` with message history)
- Build a React (.jsx) trend visualization using brand colors from `brand/brand.json`, showing count/coverage over time as a line chart
- Highlight any significant changes or inflection points

**Persist the trend dashboard:** Call `save_artifact` to attach the trend chart to the audience. Detect `artifact_type` from the source code:
```
save_artifact(
  audience_id: <the audience ID>,
  title: "<Audience title> — Monitoring Trends",
  source_code: <the complete source code>,
  artifact_type: <"react_dashboard" or "html">,
  metadata: { "generated_by": "audience-monitor", "data_points": <number of monitoring runs> }
)
```

## Monitor Types

### Audience Size Monitor
Tracks total record count for a saved audience. Good for detecting data refreshes, seasonal shifts, or filter drift.

### Mover Volume Tracker
Tracks new mover volume for a geography. Particularly valuable because mover data changes constantly — weekly monitoring catches trends early.

### Coverage Watchdog
Monitors phone and email append rates for a segment. Alerts if coverage drops, which could indicate data quality issues or changes in append sources.

### Market Pulse
Monitors multiple metrics for a broad market definition — combines count, coverage, and top-state distribution into a weekly snapshot.

## Notes

- Monitoring uses `execute_sql_query` with the audience's `audience_id` so each check is recorded as an ad-hoc message + run on that audience without overwriting the canonical SQL. (Use `run_audience_query` only when the audience's filters are intentionally being updated.)
- Each monitoring run is lightweight — just a COUNT or summary query
- Historical data accumulates in the audience's conversation history via the ad-hoc messages each check writes; use `save_message` for any additional commentary.
- The scheduled task runs in its own session, so results are delivered as notifications
