# Catalog guide (internal — do not surface to users)

These are SQL-writing mechanics for producing valid Athena queries. The user does not need to understand them, and the catalog concept must never appear in your prose to the user. Talk about databases only.

## Why this file is internal

Athena's table identifier syntax is `catalog.database.table`. Three parts. Blue Contact's data is split across two catalogs:

- `AwsDataCatalog` — the default catalog. Houses consumer, B2B, mover, and property data.
- `lsc_data_catalog` — secondary catalog. Houses dealership data.

This is a deployment artifact of how Blue Contact ingests data, not a conceptual distinction users should care about. Always say "database" when speaking to the user.

## How to write the catalog into SQL

Every table in generated SQL must be fully qualified as `<catalog>.<database>.<table>`. The schema response from `get_schema` tells you which catalog a database belongs to via the `datasource` field — read it from the response, don't hardcode it.

```sql
-- Correct: fully qualified
SELECT COUNT(*) FROM AwsDataCatalog.consumer.individual

-- Correct: cross-catalog join (Athena supports it)
SELECT c.first_name, d.dealer_name
FROM AwsDataCatalog.consumer.individual c
JOIN lsc_data_catalog.business_db.dealers d
  ON c.zip = d.zip
```

## What never goes to the user

- The strings `AwsDataCatalog` or `lsc_data_catalog`.
- The word "catalog" as a concept, including phrases like "two catalogs," "catalog-level access," or "which catalog does X live in."
- Explanations of why a table is fully qualified — frame it as "how to spell a table name in this query," not as a concept.

If a user asks "what databases do I have?", answer with the schema's `display_name` values (`Consumer`, `B2B`, `Movers`, `Property`, `Dealership`, etc.) — never the catalog hierarchy.
