# Catalog guide (internal — do not surface to users)

These are SQL-writing mechanics for producing valid Athena queries. The user does not need to understand them, and the catalog concept must never appear in your prose to the user. Talk about databases only.

## Why this file is internal

Athena's table identifier syntax is `catalog.database.table`. Three parts. Blue Contact's data is split across multiple catalogs — typically `AwsDataCatalog` (the Athena default) plus one or more federated catalogs (e.g., `lsc_data_catalog`). **Which databases live in which catalog varies by account and changes over time — never assume; read the `datasource` field from the `get_schema` response for each database.**

This is a deployment artifact of how Blue Contact ingests data, not a conceptual distinction users should care about. Always say "database" when speaking to the user.

## How to write the catalog into SQL

Every table in generated SQL must be fully qualified as `<catalog>.<database>.<table>`. The schema response from `get_schema` tells you which catalog a database belongs to via the `datasource` field — read it from the response, don't hardcode it.

If the same database *name* is assigned in more than one catalog, the schema tools report it as ambiguous — resolve it by passing the optional `datasource` argument (same value as the summary's `datasource` field) to `get_schema` / `search_schema` / `sample_values` / `read_profiling_stats`. Only pass it when a tool reports ambiguity.

```sql
-- Correct: fully qualified (catalog + database names come from get_schema)
SELECT COUNT(*) FROM <catalog_a>.<consumer_db>.individual

-- Correct: cross-catalog join (Athena supports it)
SELECT c.first_name, d.dealer_name
FROM <catalog_a>.<consumer_db>.individual c
JOIN <catalog_b>.<dealer_db>.dealers d
  ON c.zip = d.zip
```

## What never goes to the user

- Catalog name strings (`AwsDataCatalog`, `lsc_data_catalog`, etc.) in conversational prose.
- The word "catalog" as a concept, including phrases like "two catalogs," "catalog-level access," or "which catalog does X live in."
- Explanations of why a table is fully qualified — frame it as "how to spell a table name in this query," not as a concept.

**Carve-out:** SQL itself always carries the fully-qualified names — that's unavoidable and fine, including when complete SQL is embedded in a shared deliverable (e.g., the audience-logic-report's "Complete Query" section). The prohibition is about *explaining or naming* catalogs in prose, not about the SQL text.

If a user asks "what databases do I have?", answer with the schema's `display_name` values (`Consumer`, `B2B`, `Movers`, `Property`, `Dealership`, etc.) — never the catalog hierarchy.
