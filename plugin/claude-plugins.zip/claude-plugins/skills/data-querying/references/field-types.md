# Field types

Reference: how to read the typed columns the `get_schema` response returns and translate them into correct SQL. Load this when you're writing a query whose filters need careful value handling.

## Where to find type information

Call `get_schema(database: "<name>")` for a full column-level schema. Each column entry includes:

- `name` — the column name to use in SQL.
- `type` — Athena type (e.g., `varchar`, `bigint`, `boolean`, `date`).
- `options` — for categorical fields, the full set of valid values. Use these verbatim.
- `prompt_guidance` — Claude-facing notes on how to use this column (when to filter, common mistakes, normalization rules).

Always read `prompt_guidance` before writing filters on an unfamiliar column — it's where the data team encodes domain quirks.

## Type-to-filter rules

| Type | Filter shape | Notes |
|---|---|---|
| `varchar` | `column = 'value'` or `column IN ('a', 'b')` | Use exact option values from `options` if it's categorical |
| `bigint`, `int` | `column BETWEEN 100 AND 200` | Numeric ranges, no quotes |
| `boolean` | `column = true` (no quotes) | Never `'true'` or `1` |
| `date` | `column >= DATE '2026-01-01'` | ISO 8601, prefixed with `DATE` |
| `timestamp` | `column >= TIMESTAMP '2026-01-01 00:00:00'` | Same idea |

## Categorical fields

A column with a non-empty `options` array is categorical. The values in `options` are the only legal filter values — anything else returns zero rows even if the value "looks" valid. Examples:

- `homeowner_status` — values like `H` (homeowner), `R` (renter), `U` (unknown). Don't pass `Owner` or `Yes`.
- `marital_status` — schema-defined codes. Read the options.

If a user asks "homeowners," map to the option value before writing the filter, not after.

## Continuous fields with bucketing

Some columns store continuous data in pre-bucketed string codes (e.g., income brackets). The schema's `prompt_guidance` will spell out the bucket boundaries. Do not arithmetic-compare on these — filter by the bucket codes:

```sql
-- Correct
WHERE income_bucket IN ('K', 'L', 'M')   -- option codes for $100K+

-- Wrong
WHERE income_bucket > 100000             -- string comparison, returns nothing useful
```

## When in doubt

Run a small `SELECT DISTINCT column LIMIT 20` via `execute_sql_query` against the current audience's `audience_id` (every SQL execution must be tied to an audience). Faster than guessing.
