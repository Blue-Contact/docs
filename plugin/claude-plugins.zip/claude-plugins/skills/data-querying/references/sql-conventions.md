# SQL conventions

Reference: Presto/Trino dialect rules and value-formatting expectations for Blue Contact queries. Load this before writing non-trivial SQL.

## Dialect

- AWS Athena uses the Presto/Trino SQL dialect.
- All queries must be SELECT-only — no DDL, DML, or semicolons allowed. The validator rejects anything else.
- Maximum 100,000 rows per query. Use `LIMIT` and pagination (`per_page` + `next_token`) for larger result sets.

## Value formatting

- **Booleans**: use unquoted `true` / `false`. Never `'true'` or `1`.
- **Categorical fields**: use the exact option values from the schema. Never invent or paraphrase values — the validator and underlying data both expect verbatim matches.
- **State codes**: two-letter abbreviations (e.g., Minnesota → `MN`).
- **Strings**: single-quoted. Escape internal apostrophes by doubling (`O''Brien`).
- **Dates**: ISO 8601 (`'2026-01-15'`) — Athena parses these reliably.

## Normalization

The MCP server normalizes SQL before validation (whitespace collapse, comment strip). You don't need to pre-format, but:

- Don't include trailing semicolons — they're stripped, but readability suffers.
- Don't try to use comments to bypass safety filters; the normalizer makes them no-ops, and forbidden keywords still match.

## Always validate first

Call `validate_sql` before `execute_sql_query` or `run_audience_query`. The validator returns `{valid, normalized_sql, query_type, rejected_keywords, message}`. If `valid` is false, fix the issue rather than retrying — repeated invalid attempts won't pass.
