---
name: data-querying
description: Domain knowledge for querying Blue Contact's consumer, B2B, mover, property, and dealership databases
---

# Blue Contact Data Querying

You have access to Blue Contact's data platform via MCP. When a user asks about consumer data, demographics, businesses, movers, property records, or dealership information, use these tools and patterns.

## Available Tools

- `ping` — Lightweight connector health check. Returns `ok=true` and the user identity. Use as a connectivity probe.
- `get_schema` — Returns database schema. Call with no parameters for a lightweight summary of databases (with `category` and `display_name`) and table counts. Call with a specific `database` parameter for the full column-level schema (types, valid options, `prompt_guidance`). Schema is cached for 5 minutes per database.
- `get_query_instructions` — Returns SQL guidelines, safety rules, normalization requirements, and field-type handling rules. Call once per session before writing queries.
- `validate_sql` — Validates a SQL query against safety filters before execution. Returns `{valid, normalized_sql, query_type, rejected_keywords, message}`. Query type is either `count` or `data_extraction`.
- `run_audience_query` — **Primary tool for audience work.** Atomically creates/updates an audience, saves conversation history, creates a billing-tracked run, and executes the query. Required: `sql`, `reasoning` (array), `user_prompt`. Optional: `audience_id` (omit to create new), `audience_title`, `per_page` (default 10). Response now includes `coverage_summary` for data-extraction queries.
- `execute_sql_query` — Executes an ad-hoc SQL query inside an existing audience conversation. **Requires `audience_id`.** Every call is recorded as an assistant message and creates a billable audience_run on the supplied audience, but does NOT update the audience's canonical SQL or create an audience_version. Use this for one-off probes (counts, coverage checks, sampling) WITHIN an audience that already exists. Supports pagination via `per_page`, `execution_id`, `next_token`. There is no untracked SQL execution path on this server.
- `create_audience`, `get_audience`, `list_audiences`, `save_message` — Audience persistence helpers; usually `run_audience_query` is enough.

## Always do first

1. Call `get_query_instructions` if you haven't this session — it contains critical SQL rules.
2. Call `get_schema` (no params) to see available databases. Then `get_schema(database: "...")` for the column-level schema of any database you'll query.
3. Use `validate_sql` before executing.

## Critical safety rules (do not bypass)

- All queries are SELECT-only — no DDL, DML, or semicolons. The validator rejects anything else.
- Maximum 100,000 rows per query.
- Always validate before running.
- Use `run_audience_query` to DEFINE or UPDATE an audience's canonical SQL. Use `execute_sql_query` (with the existing `audience_id`) for ad-hoc probes within an audience. Both paths persist and bill — there is no untracked SQL execution path.

## When to load each reference

| Reference | Load when |
|---|---|
| `references/sql-conventions.md` | Writing non-trivial SQL — Presto/Trino dialect, value formatting, normalization, validation flow |
| `references/catalog-guide.md` | Spelling a table name in SQL — fully-qualified `catalog.database.table` mechanic. **Internal only — never surfaces to users.** |
| `references/field-types.md` | Filtering on typed columns — categorical option values, boolean handling, bucketed continuous fields |

## Common query types

- **Consumer demographics**: age, income, gender, ethnicity, homeowner status, presence of children
- **Geographic targeting**: state, city, zip, county, DMA, SCF
- **B2B lookups**: company name, SIC/NAICS codes, employee count, revenue
- **Mover data**: origin/destination, move date, mover type
- **Property records**: property type, value, square footage, lot size, year built
- **Dealership data**: dealer name, location, make/brand, inventory type
- **Contact coverage**: phone, email, and address append rates
