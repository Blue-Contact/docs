---
name: data-querying
description: Use whenever a user asks about consumer, B2B, mover, property, or dealership data — Blue Contact tool reference, SQL conventions, and safety rules for querying via Athena
---

# Blue Contact Data Querying

You have access to Blue Contact's data platform via MCP. When a user asks about consumer data, demographics, businesses, movers, property records, or dealership information, use these tools and patterns.

## Available Tools

- `ping` — Lightweight connector health check. Returns `ok=true` and the user identity. Use as a connectivity probe.
- `get_schema` — Returns database schema. Call with no parameters for a lightweight summary of databases (with `category` and `display_name`) and table counts. Then **scope your column-level call** — don't pull a whole database when you only need part of it:
  - `get_schema(database: "...", table: "...")` — column-level schema for **one table** (types, valid options, `prompt_guidance`). Strongly preferred: some databases (e.g. wide consumer tables) are large enough that a whole-database call can be slow or get truncated. Use a `table_name` from the summary.
  - `get_schema(database: "...", table: "...", columns: ["A", "B"])` — only the named columns of that table. Best for very wide tables when you already know the handful of fields a query needs.
  - `get_schema(database: "...")` (no `table`) still returns every table; the response includes a `hint` nudging you to scope. Avoid it for large databases.
  - High-cardinality columns return their options **summarized** (a count plus a few examples, or a numeric range like `'18'…'99'`) rather than fully enumerated — re-request that specific `table`/`columns` if you need the exhaustive option list. `categorical_fields` is opt-in via `include_field_index: true`.
  - If the same database name exists in more than one catalog, the tool reports the name as **ambiguous** — disambiguate by also passing `datasource` (the `datasource` field from the summary entry). `search_schema`, `sample_values`, and `read_profiling_stats` accept the same optional `datasource`; pass it only when a tool reports ambiguity.
  - Schema is cached for 5 minutes per (database, table, columns) scope.
- `search_schema` — **Discovery, not detail.** Search the catalog for a keyword and get back lightweight breadcrumbs (database › table › column + truncated descriptions). Use it to find *which* table or database holds a field (e.g. `search_schema(query: "ethnicity")`) instead of pulling a full schema and scanning it — a large database can be millions of tokens in full. Matching is lexical/prefix (PostgreSQL full-text over names, labels, descriptions, tags, and option values), not semantic, so prefer concrete keywords. Scope progressively with optional `database` / `table`. Once you find a hit, call `get_schema(database, table[, columns])` for authoritative types, full option lists, and guidance.
- `get_query_instructions` — Returns the platform's **full SQL reference**: guidelines, safety rules, normalization requirements, and field-type handling rules. **Optional** — the `run_audience_query` and `get_schema` tool descriptions (plus this skill's references) carry the essential rules; call it only when you need the full reference for an edge case they don't cover.
- `validate_sql` — Validates a SQL query against safety filters before execution. Returns `{valid, normalized_sql, query_type, rejected_keywords, message}`. Query type is either `count` or `data_extraction`.
- `find_similar_audiences` — **Precedent lookup. Call it before building a new audience.** Searches prior audience prompts account-wide (teammates' audiences included) for `prompt`, and returns matches with the `sql` they ran, the count they returned, when they ran, who owns them, a `match_strength` (`exact` | `strong` | `related`), a boolean `reusable`, and a `guidance` string. `exact`/`strong` are `reusable: true` — the same question, so `validate_sql` the match's `sql` and reuse it verbatim instead of re-deriving your own. `related` is `reusable: false` — overlapping but not the same question; read the match's `prompt` and judge, never reuse it silently. Matching is lexical, so a genuine repeat can land in `related` on different wording ("Wisconsin" vs "WI") — judge by the prompt text, not the band. (`exact`/`strong` are additionally model-checked server-side for the same target population, so a negated prompt can't be auto-reused against its opposite.) Optional: `limit`, `exclude_audience_id`. Workflow: `${CLAUDE_PLUGIN_ROOT}/skills/audience-building/SKILL.md` → step 1.
- `run_audience_query` — **Primary tool for audience work.** Atomically creates/updates an audience, saves conversation history, creates a billing-tracked run, and **queues the query for asynchronous execution** on a worker dyno (returns immediately with `{status: "queued", run_id, audience_id, ...}` — no rows). Required: `sql`, `reasoning` (array), `user_prompt`. Optional: `audience_id` (omit to create new), `audience_title`, `per_page` (default 10). After this call, **poll `get_audience_run`** until `status: "completed"`.
- `execute_sql_query` — Executes an ad-hoc SQL query inside an existing audience conversation. **Requires `audience_id`.** Every call is recorded as an assistant message and creates a billing-tracked audience_run on the supplied audience, but does NOT update the audience's canonical SQL or create an audience_version. **Async kick-off** for new queries (poll `get_audience_run` for results); **synchronous** when paginating an existing run via `execution_id` + `next_token`. Use this for one-off probes (counts, coverage checks, sampling) WITHIN an audience that already exists. There is no untracked SQL execution path on this server.
- `get_audience_run` — **Poll target for both kick-off tools.** Pass `audience_id` + `run_id` from the kick-off response. Returns `{status: "queued"|"running"|"fixing"}` while the job runs (re-poll in 2–5 s), `{status: "completed", columns, rows, row_count, total_count, next_token, download_url, coverage_summary?}` when done, or `{status: "failed", error_message}` on failure. When the account has answered the same question before, this and `run_audience_query` also carry a `precedent` / `comparison` block (`prior_count`, `current_count`, `delta_percent`, a ready-to-use `disclosure` sentence, `sql_identical`) — relay it. Supports pagination via `direction = next | prev | first` for subsequent pages of a completed run.
- `create_audience`, `get_audience`, `list_audiences`, `save_message` — Audience persistence helpers; usually `run_audience_query` is enough.
- `sample_values` — Up to 100 example values for one column (`database`, `table`, `column`). **Masked by default**; sensitive columns only ever return synthetic/format-preserving values (server-enforced — `masked: false` is ignored for them). Use it to learn what values actually look like before writing a filter, instead of a `SELECT DISTINCT` probe.
- `read_profiling_stats` — Per-column **fill rates** and profiling stats (null/blank rates, distinct count, inferred type, min/max, top values) served from persisted profiler output with **no Athena query**. Pass `table_id` for an owned table, or `database` + `table`. Whenever the question is whole-table completeness/coverage/data quality, use this — **do NOT compute fill rates with SQL COUNT queries**. (Coverage of a *filtered* audience subset still needs SQL — see `audience-building`.)

### Owned tables & data jobs (see the `my-data` and `personas` skills)

The platform also manages **user-owned tables** (uploads, CTAS materializations, job outputs) and **managed data jobs** over them: `list_tables` / `get_table` / `get_table_preview`, `create_table_from_file`, `request_upload_url` + `register_uploaded_table`, `create_table_from_query`, `run_data_job` (match | segment | score | quality) + `get_run_status`, `set_table_retention`, `drop_table`, plus the profiling/scoring family (`get_profiling_status`, `get_profiling_artifacts`, `get_persona_details`, `iterate_profiling`, `list_profiling_jobs`, `get_scoring_status`, `get_scoring_results`). Workflows live in the `my-data` skill (upload → match → manage) and the `personas` skill (profile → segment → score). Two things every query-writer must know even without loading those skills:

- **Never link uploaded records to the Blue Contact library with SQL** — no joins on names/emails/addresses, no CTAS matching. Matching is a managed job: `run_data_job(job_type: "match", table_id: ...)`.
- Owned tables expire by default (30 days for MCP-created ones). If a query references one, its `get_table` response states the expiry.
- **Tables are the only unit of owned data.** Jobs are addressed by `table_id` and runs by `data_job_id`; there is no dataset object. The dataset-era tools (`list_datasets`, `create_dataset`, `create_dataset_from_query`, `get_dataset`, `kickoff_import_match`, `kickoff_profiling`, `kickoff_scoring`) have been **removed from the server** — calling them fails. If a user brings an old `dataset_id`, locate the table with `list_tables` instead.

## Always do first

1. Know the SQL rules. The tool descriptions and this skill's references carry the essentials; call `get_query_instructions` only if you need the platform's full reference.
2. Call `get_schema` (no params) to see available databases. Then scope the column-level call to what you need: `get_schema(database: "...", table: "...")` for a single table, or add `columns: [...]` for specific fields of a wide table. Reserve the whole-database call (`get_schema(database: "...")` with no `table`) for small databases. If you don't yet know which database/table contains a field, use `search_schema(query: "...")` to locate it first.
3. Use `validate_sql` before executing.

## Critical safety rules (do not bypass)

- All queries are SELECT-only — no DDL, DML, or semicolons. The validator rejects anything else. (Table materialization happens only through the dedicated `create_table_from_query` tool, which applies its own CTAS guardrails — never by writing DDL into a query tool.)
- Maximum 100,000 rows per query.
- **Unfiltered samples of large tables need `TABLESAMPLE SYSTEM (1)`.** A `LIMIT` with only non-blank (`IS NOT NULL`) predicates does not bound the scan and will exhaust Athena's resources on a large table (millions of rows), failing every time. Add `TABLESAMPLE SYSTEM (1)` after the table name and its alias — e.g. `FROM db.tbl t TABLESAMPLE SYSTEM (1)` (after `FROM`, never after `WHERE`). If 0 rows come back, raise the percentage (1 → 5 → 25). Small tables (thousands of rows) don't need it — plain `LIMIT` is safe there. **This is a rule about row samples, not aggregates**: never add `TABLESAMPLE` to a `COUNT`/`GROUP BY` query whose output is meant to be exact, since it would silently scale down every number.
- Always validate before running.
- **Never match/append uploaded data against the library via SQL joins** — use `run_data_job(job_type: "match")` (see `my-data`).
- **Never compute whole-table fill rates with SQL COUNT queries** — use `read_profiling_stats`.
- **Relay the `precedent` / `comparison` block** when a query response carries one, and read `sql_identical` correctly: `false` means this run used a *different query* than the earlier one, `true` means the *same query over refreshed data*. They are opposite explanations for a number that moved — never report one as the other, and never present a count that moved as if nothing had changed.
- Use `run_audience_query` to DEFINE or UPDATE an audience's canonical SQL. Use `execute_sql_query` (with the existing `audience_id`) for ad-hoc probes within an audience. Both paths persist and are billing-tracked — there is no untracked SQL execution path. (Runs are tagged `count` or `data_extraction` by the validator; extractions are the billable deliverable.)
- Both query tools are **asynchronous**. They return a kick-off response (no rows) and queue the work to a background worker. Always poll `get_audience_run` with the returned `run_id` until `status: "completed"` (or `"failed"`) to get the actual results. The canonical polling pattern: `${CLAUDE_PLUGIN_ROOT}/skills/audience-building/SKILL.md` → "Polling for results".

## When to load each reference

| Reference | Load when |
|---|---|
| `references/sql-conventions.md` | Writing non-trivial SQL — Presto/Trino dialect, value formatting, normalization, validation flow |
| `references/catalog-guide.md` | Spelling a table name in SQL — fully-qualified `catalog.database.table` mechanic. **Internal only — never surfaces to users.** |
| `references/field-types.md` | Filtering on typed columns — categorical option values, boolean handling, bucketed continuous fields |

## Common query types

- **Consumer demographics**: age, income, gender, ethnicity, homeowner status, presence of children
- **Geographic targeting**: state, city, zip, county, DMA, SCF
- **B2B lookups**: company name, SIC/NAICS codes, employee count, revenue
- **Mover data**: origin/destination, move date, mover type
- **Property records**: property type, value, square footage, lot size, year built
- **Dealership data**: dealer name, location, make/brand, inventory type
- **Contact coverage**: phone, email, and address append rates
