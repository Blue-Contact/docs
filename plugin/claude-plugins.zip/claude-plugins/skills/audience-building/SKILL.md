---
name: audience-building
description: Workflow knowledge for building targeted marketing audiences with Blue Contact data
---

# Audience Building with Blue Contact

When a user wants to build a targeted audience, follow this structured workflow:

## Workflow

1. **Clarify the target.** Ask about:
   - Geographic scope (state, city, zip, DMA)
   - Demographic filters (age range, income, homeowner status, etc.)
   - Data type needed (consumer, B2B, mover, property, dealership)
   - Output fields desired (name, address, phone, email, etc.)
   - Volume expectations (how many records)

2. **Load query context.** Call `get_query_instructions` and `get_schema` (two-step: summary first, then full schema for relevant databases) if not already loaded this session.

3. **Open the audience with a COUNT.** Use `run_audience_query` for the volume estimate — this creates the audience and tracks the count as its first run (auto-tagged `query_type: "count"`, not billable):
   ```sql
   SELECT COUNT(*) FROM catalog.database.table WHERE [filters]
   ```
   Pass `sql`, `reasoning`, `user_prompt`, and an `audience_title`. Capture the returned `audience_id` — you'll reuse it for every subsequent SQL call. There is no untracked SQL path; every probe must be tied to an audience.

4. **Probe contact coverage if needed.** If the user needs phone or email and you want explicit append-rate numbers, call `execute_sql_query` with the `audience_id` from step 3. The probe is recorded as an assistant message + run on the same audience but does NOT overwrite the audience's canonical SQL.
   ```sql
   SELECT
     COUNT(*) AS total,
     COUNT(phone) AS with_phone,
     COUNT(email) AS with_email,
     ROUND(COUNT(phone) * 100.0 / COUNT(*), 1) AS phone_pct,
     ROUND(COUNT(email) * 100.0 / COUNT(*), 1) AS email_pct
   FROM catalog.database.table WHERE [filters]
   ```
   Note: `run_audience_query` already returns a `coverage_summary` for `data_extraction` results, so this explicit probe is optional when you plan to extract anyway.

5. **Refine to the data extraction.** Call `run_audience_query` again with the same `audience_id` and the final SELECT. This becomes the audience's canonical SQL — a new `audience_version` is recorded and the run is billable as `data_extraction`.

6. **Report results.** Summarize:
   - Total records (from the count run)
   - Contact coverage rates (from `coverage_summary` or the explicit probe)
   - Geographic distribution
   - Key demographic breakdown

7. **Offer to save & share for QA.** After the user confirms they're happy with the audience (e.g., they express satisfaction, ask to download, save, or move to next steps), prompt them using AskUserQuestion with two options:
   - **"Save & share for QA"** — "Save the exact logic behind this audience as a shareable doc your team can QA — they can check the filters, flag changes, and send it back to update the query."
   - **"Skip for now"** — "You can always generate one later with /blue-contact:audience-logic-report"
   
   This triggers the `audience-logic-report` skill if accepted. **Do not prompt immediately after showing results** — wait for a signal that the user considers this audience finalized.

## Best practices
- Start with count estimates before pulling full data
- Always include contact coverage analysis when the audience is for outreach
- Use `save_message` to log query context and results to the audience for future reference
- For very large audiences (100k+), suggest geographic or demographic sub-segmentation
- Remember the 100,000 row limit per query — segment if needed
