---
name: audience-building
description: Canonical workflow and async-polling reference for building targeted marketing audiences — activates whenever a user describes a target audience, segment, or list they want from Blue Contact data. Other skills defer to this one's "Polling for results" section.
---

# Audience Building with Blue Contact

When a user wants to build a targeted audience, follow this structured workflow:

## Polling for results

**Both `run_audience_query` and `execute_sql_query` are asynchronous.** They always return immediately with:

```json
{
  "audience_id": ...,
  "run_id": ...,
  "status": "queued",
  "query_type": "count" | "data_extraction",
  "message": "...poll get_audience_run..."
}
```

No `rows`, `columns`, `download_url`, or `coverage_summary` come back from the kick-off. The real Athena execution runs in the background on a worker dyno.

**To get results, poll `get_audience_run`** with the `audience_id` and `run_id` from the kick-off response. Wait 2–5 seconds between polls. Possible response shapes:

- **`status: "queued"` / `"running"` / `"fixing"`** — still executing. Wait briefly and call `get_audience_run` again with the same arguments. Do *not* call `run_audience_query` or `execute_sql_query` again with the same SQL — that would start a duplicate query.
- **`status: "completed"`** — full payload: `columns`, `rows`, `row_count`, `total_count`, `next_token`, `download_url`, and (for `data_extraction` queries) `coverage_summary`. Continue the workflow with these.
- **`status: "failed"`** — the response includes `error_message`. Surface it to the user. Do not retry the same SQL automatically.

**Relay the precedent block.** When the account has answered this question before, `run_audience_query` and `get_audience_run` carry a `precedent` / `comparison` block: `prior_count`, `current_count`, `delta_percent`, a ready-to-use `disclosure` sentence, and `sql_identical`. Pass it on to the user — the `disclosure` sentence is written to be used as-is. `sql_identical` is the part that carries the meaning: `false` means this run used a *different query* than the earlier one; `true` means the *same query over refreshed data*. Those are opposite explanations for a number that moved — never report one as the other, and never present a count that moved as if nothing had changed.

**For subsequent pages** of a completed run, call `get_audience_run` again with `direction: "next"` (or `"prev"` / `"first"`). Each direction call updates the run's page state on the server and returns the new page synchronously.

Every workflow step below that says "call `run_audience_query`" or "call `execute_sql_query`" implies this poll loop. The hook on `get_audience_run` will remind you to surface `coverage_summary` and `download_url` once `status: "completed"`.

## Workflow

1. **Check for a precedent.** For a new audience, call `find_similar_audiences(prompt: <the user's request>)` before anything else. It searches prior audience prompts across the whole account — teammates' audiences included — and returns matches carrying the `sql` they ran, the count they returned, when they ran, and who owns them, plus a `guidance` string summarising what to do.
   - **`match_strength: "exact"` or `"strong"`** (`reusable: true`) — the same question, already answered. Run `validate_sql` on the match's `sql` first, since the schema may have moved; if it still validates, reuse it **verbatim** rather than writing your own. Tell the user you're reusing an earlier query, whose it was, and when it ran.
   - **`match_strength: "related"`** (`reusable: false`) — overlapping but *not* the same question. Read the match's `prompt` text and judge for yourself. Never reuse a related query silently.
   - Matching is lexical, so a genuine repeat can come back as `related` when the wording differs a lot ("Wisconsin" vs "WI"). Judge by the prompt text, not the band alone. (Server-side, `exact`/`strong` matches are additionally model-checked for the same target population, so "homeowners NOT in Texas" can never be auto-reused against "homeowners in Texas".)
   - Deviating from an `exact`/`strong` precedent is allowed — validation failure, a real defect in the old query, or the user asking for something different — but say in your `reasoning` what changed and why, and note that the count may differ from the earlier run.
   - Optional args: `exclude_audience_id` to leave an audience you already have in hand out of the results, `limit` to cap how many matches come back.

2. **Clarify the target.** Ask about:
   - Geographic scope (state, city, zip, DMA)
   - Demographic filters (age range, income, homeowner status, etc.)
   - Data type needed (consumer, B2B, mover, property, dealership)
   - Output fields desired (name, address, phone, email, etc.)
   - Volume expectations (how many records)

3. **Load query context.** Call `get_schema` (two-step: summary first, then scope the column-level call to the table(s) you need with `get_schema(database, table)`, adding `columns: [...]` for specific fields of wide tables — avoid whole-database calls on large databases) if not already loaded this session. `get_query_instructions` is optional — the tool descriptions and the `data-querying` skill carry the essential rules; call it only if you need the platform's full SQL reference.

4. **Open the audience with a COUNT.** Call `run_audience_query` for the volume estimate — this creates the audience and queues the count as its first run (auto-tagged `query_type: "count"`):
   ```sql
   SELECT COUNT(*) FROM catalog.database.table WHERE [filters]
   ```
   Pass `sql`, `reasoning`, `user_prompt`, and an `audience_title`. The response is a kick-off (`status: "queued"`); poll `get_audience_run` until `status: "completed"`, then read `rows[0]` for the count. Capture the returned `audience_id` — you'll reuse it for every subsequent SQL call. There is no untracked SQL path; every probe must be tied to an audience.

5. **Probe contact coverage if needed.** (Scope check first: these SQL probes are for coverage of the *filtered* audience. If the user is asking about a whole table's fill rates — "what's phone coverage in the consumer database?" — use `read_profiling_stats(database, table)` instead; it answers from persisted profiler stats with no Athena query.) If the user needs phone or email and you want explicit append-rate numbers for the audience, call `execute_sql_query` with the `audience_id` from step 4 (if your deployment rejects `execute_sql_query`, run the same probe via `run_audience_query` against the same `audience_id`). The probe is recorded as a run on the same audience but does NOT overwrite the audience's canonical SQL. Same poll pattern — kick off, then `get_audience_run`.

   **First check the schema: is contact data a column, or a separate table?** Don't assume `phone`/`email` are columns on the main table — in many Blue Contact databases they live in separate one-to-many tables (e.g. `consumer_phone` / `consumer_email`) joined on the record `Id`. `COUNT(phone)` against a table that has no such column will error or mislead. Pick the shape that matches the schema:

   - **Contact data in separate tables (common):** derive a per-record flag with a deduped semi-join, then count it.
     ```sql
     SELECT
       COUNT(*) AS total,
       COUNT(DISTINCT p.id) AS with_phone,
       COUNT(DISTINCT e.id) AS with_email,
       ROUND(COUNT(DISTINCT p.id) * 100.0 / COUNT(*), 1) AS phone_pct,
       ROUND(COUNT(DISTINCT e.id) * 100.0 / COUNT(*), 1) AS email_pct
     FROM catalog.database.main_table cd
     LEFT JOIN (SELECT DISTINCT Id FROM catalog.database.phone_table) p ON p.id = cd.Id
     LEFT JOIN (SELECT DISTINCT Id FROM catalog.database.email_table) e ON e.id = cd.Id
     WHERE [filters]
     ```
     (Confirm the exact contact tables and join keys from the schema.)
   - **Contact fields inline on the table (only if the schema shows real `phone`/`email` columns):** `COUNT(phone)` / `COUNT(email)` directly. Remember `COUNT(col)` skips NULLs but counts empty strings — treat `''` as missing (`COUNT(NULLIF(phone, ''))`) when blanks stand in for NULL.

   Note: the polled `get_audience_run` response already includes a `coverage_summary` for `data_extraction` results, so this explicit probe is optional when you plan to extract anyway.

6. **Refine to the data extraction.** Call `run_audience_query` again with the same `audience_id` and the final SELECT. This becomes the audience's canonical SQL — a new `audience_version` is recorded and the run is billable as `data_extraction`. Poll `get_audience_run` for the rows + `download_url` + `coverage_summary`.

7. **Report results.** Summarize (all of these come from the `get_audience_run` response with `status: "completed"`):
   - Total records (from the count run's `get_audience_run` payload)
   - Contact coverage rates (from `coverage_summary` or the explicit probe)
   - Geographic distribution
   - Key demographic breakdown

8. **Offer to save & share for QA.** After the user confirms they're happy with the audience (e.g., they express satisfaction, ask to download, save, or move to next steps), prompt them using AskUserQuestion with two options:
   - **"Save & share for QA"** — "Save the exact logic behind this audience as a shareable doc your team can QA — they can check the filters, flag changes, and send it back to update the query."
   - **"Skip for now"** — "You can always generate one later with /blue-contact:audience-logic-report"
   
   This triggers the `audience-logic-report` skill if accepted. **Do not prompt immediately after showing results** — wait for a signal that the user considers this audience finalized.

## After the audience is finalized

Two natural extensions once the user is happy with an audience (offer when relevant, don't recite):

- **Personas** — "want data-driven personas for this audience?" The `personas` skill materializes the audience as a table (`create_table_from_query(audience_id: ..., table_name: ...)`), profiles it (`run_data_job(job_type: "segment", table_id: ...)` → clustering → named personas), and can then score prospect universes against it.
- **Materialize as a table** — `create_table_from_query(audience_id: ..., table_name: ...)` turns the audience into an owned table for downstream jobs (expires in 30 days by default; see the `my-data` skill).

## Best practices
- Check `find_similar_audiences` before building a new audience — an `exact`/`strong` match's SQL is reusable verbatim once `validate_sql` passes; a `related` match is a lead to read, not a query to run
- Start with count estimates before pulling full data
- Always include contact coverage analysis when the audience is for outreach
- Use `save_message` to log query context and results to the audience for future reference
- For very large audiences (100k+), suggest geographic or demographic sub-segmentation
- Remember the 100,000 row limit per query — segment if needed
