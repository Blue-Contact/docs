# Audience Logic Report Generator

Generate branded Blue Contact Audience Logic Reports as .docx files.

## Usage

```bash
node generate_report.js data.json
```

## Input Format

The script accepts a JSON data file with the following structure:

```json
{
  "outputPath": "/path/to/output.docx",
  "audience": {
    "title": "Audience name",
    "id": 12345,
    "createdBy": "Creator name",
    "date": "Date string",
    "status": "Draft|Active|Archived",
    "totalContacts": "Contact count with commas"
  },
  "executiveSummary": {
    "narrative": "Description paragraph",
    "stats": {
      "emailCoverage": "XX.X% (X,XXX)",
      "phoneCoverage": "XX.X% (X,XXX)",
      "topStates": "CA, NY, TX"
    }
  },
  "waterfall": [
    { "step": 0, "filter": "Step name", "remaining": 1000000, "dropped": null, "pctDrop": null },
    { "step": 1, "filter": "Step name", "remaining": 500000, "dropped": 500000, "pctDrop": "50.0%" }
  ],
  "steps": [
    {
      "title": "Step 1: Description",
      "rationale": "Why this step...",
      "filterRows": [["Setting", "Value", true]],
      "sqlHeader": "SQL Fragment",
      "sqlLines": ["SQL line 1", "SQL line 2"],
      "notes": ["Note 1", "Note 2"],
      "impact": "X → Y (Z% drop)"
    }
  ],
  "fullSql": "Complete SQL query",
  "suggestions": [
    {
      "title": "1. Suggestion title",
      "body": "Suggestion description"
    }
  ],
  "assumptions": [
    "Assumption 1",
    "Assumption 2"
  ]
}
```

## Features

- Branded Blue Contact styling with official colors
- Executive summary with coverage metrics
- Waterfall funnel table with danger coloring for high drop percentages (97%+)
- Step-by-step filter logic with editable fields
- SQL query blocks with proper formatting
- Suggestions and assumptions sections
- Header with logo and footer with confidentiality notice
- Validation support via docx validator

## Styling

All styling is derived from the reference template and matches:
- Brand colors: Blue, Graphite, Seafoam, Eggshell
- Page size: US Letter (8.5 x 11 inches)
- Margins: 1 inch top/bottom, 0.875 inch left/right
- Logo: Horizontal logo in header (1.4 inches wide)
- Tables: 2-column (Settings/Value) or 5-column (Waterfall)

## Output

Generates a .docx file at the path specified in `outputPath`.
