#!/usr/bin/env node

const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, AlignmentType, BorderStyle, WidthType, ShadingType,
  LevelFormat, Footer, Header, TabStopType, ImageRun, PageNumber
} = require('docx');
const fs = require('fs');
const path = require('path');

// ── BRAND COLORS (from Blue Contact Brand Guidelines) ─────────────
const BC_BLUE       = "006AFF";   // Contact Blue — primary brand
const BC_GRAPHITE   = "2A3A57";   // Graphite — body text / dark headings
const BC_SEAFOAM    = "12C7B4";   // Seafoam accent
const BC_SUCCESS    = "00C864";
const BC_DANGER     = "DB4646";
const BC_EGGSHELL   = "E4E9F5";   // Background tint
const BC_WHITE      = "FFFFFF";
const BC_LIGHT_RULE = "D0D9EF";   // Light rule lines

// ── LOGO IMAGES ────────────────────────────────────────────────────
const logoHorizontalPath = path.join(__dirname, '..', 'assets', 'logo_horizontal.png');
const logoIconPath = path.join(__dirname, '..', 'assets', 'logo_icon.png');

let logoHorizontal, logoIcon;
try {
  logoHorizontal = fs.readFileSync(logoHorizontalPath);
  logoIcon = fs.readFileSync(logoIconPath);
} catch (err) {
  console.error(`Failed to load logo images: ${err.message}`);
  process.exit(1);
}

// ── BORDER HELPERS ─────────────────────────────────────────────────
const border  = (color = BC_LIGHT_RULE) => ({ style: BorderStyle.SINGLE, size: 1, color });
const borders = (color = BC_LIGHT_RULE) => ({ top: border(color), bottom: border(color), left: border(color), right: border(color) });
const noBorders = { top: { style: BorderStyle.NONE }, bottom: { style: BorderStyle.NONE }, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE } };

// ── TEXT HELPERS ───────────────────────────────────────────────────
const run  = (text, opts = {}) => new TextRun({ text, font: "Arial", size: 22, ...opts });
const bold = (text, opts = {}) => run(text, { bold: true, ...opts });

function para(children, opts = {}) {
  return new Paragraph({ spacing: { before: 60, after: 60 }, children: Array.isArray(children) ? children : [children], ...opts });
}

function h1(text) {
  return new Paragraph({
    spacing: { before: 360, after: 120 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: BC_BLUE, space: 4 } },
    children: [new TextRun({ text: text.toUpperCase(), font: "Arial", size: 24, bold: true, color: BC_GRAPHITE, characterSpacing: 40 })]
  });
}

function h1Seafoam(text) {
  return new Paragraph({
    spacing: { before: 360, after: 120 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: BC_SEAFOAM, space: 4 } },
    children: [new TextRun({ text: text.toUpperCase(), font: "Arial", size: 24, bold: true, color: BC_GRAPHITE, characterSpacing: 40 })]
  });
}

function h2(text) {
  return new Paragraph({
    spacing: { before: 240, after: 80 },
    children: [new TextRun({ text, font: "Arial", size: 22, bold: true, color: BC_BLUE })]
  });
}

function h2Seafoam(text) {
  return new Paragraph({
    spacing: { before: 240, after: 80 },
    children: [new TextRun({ text, font: "Arial", size: 22, bold: true, color: BC_SEAFOAM })]
  });
}

function bodyPara(text, opts = {}) {
  return para([run(text, { color: BC_GRAPHITE, ...opts })]);
}

function notePara(text) {
  return new Paragraph({
    spacing: { before: 60, after: 60 },
    indent: { left: 360 },
    children: [
      run("Note: ", { bold: true, color: BC_SEAFOAM, size: 20 }),
      run(text, { color: "666666", size: 20, italics: true })
    ]
  });
}

function bullet(text, editable = false) {
  return new Paragraph({
    numbering: { reference: "bullets", level: 0 },
    spacing: { before: 40, after: 40 },
    children: editable
      ? [run(text, { color: BC_GRAPHITE, size: 22 }), run("  ← editable", { color: "AAAAAA", size: 18, italics: true })]
      : [run(text, { color: BC_GRAPHITE, size: 22 })]
  });
}

function spacer(before = 160) {
  return new Paragraph({ spacing: { before, after: 0 }, children: [run("")] });
}

// ── TABLE HELPERS ──────────────────────────────────────────────────
function filterTable(rows) {
  const COL1 = 2600, COL2 = 6760;
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [COL1, COL2],
    rows: [
      // Header row
      new TableRow({
        children: [
          new TableCell({
            borders: borders(BC_BLUE), width: { size: COL1, type: WidthType.DXA },
            shading: { fill: BC_GRAPHITE, type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 140, right: 140 },
            children: [para([bold("Setting", { color: BC_WHITE, size: 20 })])]
          }),
          new TableCell({
            borders: borders(BC_BLUE), width: { size: COL2, type: WidthType.DXA },
            shading: { fill: BC_GRAPHITE, type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 140, right: 140 },
            children: [para([bold("Value", { color: BC_WHITE, size: 20 })])]
          })
        ]
      }),
      ...rows.map(([label, value, editable], i) => new TableRow({
        children: [
          new TableCell({
            borders: borders(), width: { size: COL1, type: WidthType.DXA },
            shading: { fill: i % 2 === 0 ? BC_EGGSHELL : BC_WHITE, type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 140, right: 140 },
            children: [para([bold(label, { size: 20, color: BC_GRAPHITE })])]
          }),
          new TableCell({
            borders: borders(), width: { size: COL2, type: WidthType.DXA },
            shading: { fill: i % 2 === 0 ? BC_EGGSHELL : BC_WHITE, type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 140, right: 140 },
            children: [new Paragraph({
              spacing: { before: 0, after: 0 },
              children: editable
                ? [run(value, { size: 20, color: BC_BLUE }), run("  ← editable", { size: 18, color: "AAAAAA", italics: true })]
                : [run(value, { size: 20, color: BC_GRAPHITE })]
            })]
          })
        ]
      }))
    ]
  });
}

function waterfallTable(rows) {
  const COL_WIDTHS = [800, 3200, 2000, 1800, 1560];
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: COL_WIDTHS,
    rows: [
      // Header row
      new TableRow({
        children: [
          new TableCell({
            borders: borders(BC_BLUE), width: { size: COL_WIDTHS[0], type: WidthType.DXA },
            shading: { fill: BC_GRAPHITE, type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 100, right: 100 },
            children: [para([bold("Step", { color: BC_WHITE, size: 18 })])]
          }),
          new TableCell({
            borders: borders(BC_BLUE), width: { size: COL_WIDTHS[1], type: WidthType.DXA },
            shading: { fill: BC_GRAPHITE, type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 100, right: 100 },
            children: [para([bold("Filter", { color: BC_WHITE, size: 18 })])]
          }),
          new TableCell({
            borders: borders(BC_BLUE), width: { size: COL_WIDTHS[2], type: WidthType.DXA },
            shading: { fill: BC_GRAPHITE, type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 100, right: 100 },
            children: [para([bold("Remaining", { color: BC_WHITE, size: 18 })])]
          }),
          new TableCell({
            borders: borders(BC_BLUE), width: { size: COL_WIDTHS[3], type: WidthType.DXA },
            shading: { fill: BC_GRAPHITE, type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 100, right: 100 },
            children: [para([bold("Dropped", { color: BC_WHITE, size: 18 })])]
          }),
          new TableCell({
            borders: borders(BC_BLUE), width: { size: COL_WIDTHS[4], type: WidthType.DXA },
            shading: { fill: BC_GRAPHITE, type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 100, right: 100 },
            children: [para([bold("% Drop", { color: BC_WHITE, size: 18 })])]
          })
        ]
      }),
      ...rows.map(({ step, filter, remaining, dropped, pctDrop }, i) => {
        const isDanger = pctDrop && parseFloat(pctDrop) >= 97;
        return new TableRow({
          children: [
            new TableCell({
              borders: borders(), width: { size: COL_WIDTHS[0], type: WidthType.DXA },
              shading: { fill: i % 2 === 0 ? BC_EGGSHELL : BC_WHITE, type: ShadingType.CLEAR },
              margins: { top: 80, bottom: 80, left: 100, right: 100 },
              children: [para([run(String(step), { size: 18, color: BC_GRAPHITE })])]
            }),
            new TableCell({
              borders: borders(), width: { size: COL_WIDTHS[1], type: WidthType.DXA },
              shading: { fill: i % 2 === 0 ? BC_EGGSHELL : BC_WHITE, type: ShadingType.CLEAR },
              margins: { top: 80, bottom: 80, left: 100, right: 100 },
              children: [para([run(filter, { size: 18, color: BC_GRAPHITE })])]
            }),
            new TableCell({
              borders: borders(), width: { size: COL_WIDTHS[2], type: WidthType.DXA },
              shading: { fill: i % 2 === 0 ? BC_EGGSHELL : BC_WHITE, type: ShadingType.CLEAR },
              margins: { top: 80, bottom: 80, left: 100, right: 100 },
              children: [para([run(String(remaining), { size: 18, color: BC_GRAPHITE })])]
            }),
            new TableCell({
              borders: borders(), width: { size: COL_WIDTHS[3], type: WidthType.DXA },
              shading: { fill: i % 2 === 0 ? BC_EGGSHELL : BC_WHITE, type: ShadingType.CLEAR },
              margins: { top: 80, bottom: 80, left: 100, right: 100 },
              children: [para([run(dropped !== null ? String(dropped) : "—", { size: 18, color: BC_GRAPHITE })])]
            }),
            new TableCell({
              borders: borders(), width: { size: COL_WIDTHS[4], type: WidthType.DXA },
              shading: { fill: i % 2 === 0 ? BC_EGGSHELL : BC_WHITE, type: ShadingType.CLEAR },
              margins: { top: 80, bottom: 80, left: 100, right: 100 },
              children: [para([run(pctDrop !== null ? String(pctDrop) : "—", {
                size: 18,
                color: isDanger ? BC_DANGER : BC_GRAPHITE
              })])]
            })
          ]
        });
      })
    ]
  });
}

function blueBox(headerText, children) {
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [9360],
    rows: [
      new TableRow({ children: [new TableCell({
        borders: borders(BC_BLUE), width: { size: 9360, type: WidthType.DXA },
        shading: { fill: BC_BLUE, type: ShadingType.CLEAR },
        margins: { top: 100, bottom: 100, left: 180, right: 180 },
        children: [para([bold(headerText, { color: BC_WHITE, size: 22 })])]
      })] }),
      new TableRow({ children: [new TableCell({
        borders: borders(), width: { size: 9360, type: WidthType.DXA },
        shading: { fill: BC_EGGSHELL, type: ShadingType.CLEAR },
        margins: { top: 120, bottom: 120, left: 180, right: 180 },
        children
      })] })
    ]
  });
}

function summaryTable(rows) {
  const COL1 = 2800, COL2 = 6560;
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [COL1, COL2],
    rows: rows.map(([label, value], i) => new TableRow({
      children: [
        new TableCell({
          borders: borders(), width: { size: COL1, type: WidthType.DXA },
          shading: { fill: BC_GRAPHITE, type: ShadingType.CLEAR },
          margins: { top: 80, bottom: 80, left: 140, right: 140 },
          children: [para([bold(label, { color: BC_WHITE, size: 20 })])]
        }),
        new TableCell({
          borders: borders(), width: { size: COL2, type: WidthType.DXA },
          shading: { fill: i % 2 === 0 ? BC_EGGSHELL : BC_WHITE, type: ShadingType.CLEAR },
          margins: { top: 80, bottom: 80, left: 140, right: 140 },
          children: [para([run(value, { size: 20, color: BC_GRAPHITE })])]
        })
      ]
    }))
  });
}

// ── LOGO IMAGE RUN ─────────────────────────────────────────────────
function logoImageRun(inches = 2.0) {
  const w = Math.round(inches * 96);
  const h = Math.round(w * (384 / 3102));
  return new ImageRun({ data: logoHorizontal, transformation: { width: w, height: h }, type: "png" });
}

function iconImageRun(inches = 0.22) {
  const px = Math.round(inches * 96);
  return new ImageRun({ data: logoIcon, transformation: { width: px, height: px }, type: "png" });
}

// ── MAIN ───────────────────────────────────────────────────────────

function generateReport(data) {
  const audience = data.audience || {};
  const execSummary = data.executiveSummary || {};
  const waterfall = data.waterfall || [];
  const steps = data.steps || [];
  const fullSql = data.fullSql || "";
  const suggestions = data.suggestions || [];
  const assumptions = data.assumptions || [];

  const docChildren = [];

  // ── TITLE BLOCK ──────────────────────────────────────────────
  docChildren.push(
    new Paragraph({
      spacing: { before: 120, after: 0 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 16, color: BC_BLUE, space: 8 } },
      children: [new TextRun({ text: "AUDIENCE LOGIC REPORT", font: "Arial", size: 36, bold: true, color: BC_GRAPHITE, characterSpacing: 60 })]
    }),
    spacer(200),
    summaryTable([
      ["Audience Name", audience.title || ""],
      ["Audience ID", audience.id ? String(audience.id) : ""],
      ["Created By", audience.createdBy || ""],
      ["Date", audience.date || ""],
      ["Status", audience.status || ""],
      ["Total Contacts", audience.totalContacts || ""]
    ]),
    spacer(280)
  );

  // ── SECTION 1: EXECUTIVE SUMMARY ─────────────────────────────
  docChildren.push(
    h1("1. Executive Summary"),
    bodyPara(execSummary.narrative || ""),
    spacer(120)
  );

  if (execSummary.stats) {
    const stats = execSummary.stats;
    docChildren.push(
      bodyPara("Key Coverage Metrics:", { bold: true }),
      bullet(`Email Coverage: ${stats.emailCoverage || "N/A"}`),
      bullet(`Phone Coverage: ${stats.phoneCoverage || "N/A"}`),
      bullet(`Top States: ${stats.topStates || "N/A"}`),
      spacer(160)
    );
  }

  if (waterfall && waterfall.length > 0) {
    docChildren.push(
      bodyPara("Audience Funnel — Contact Count by Filter Step:", { bold: true }),
      spacer(80),
      waterfallTable(waterfall),
      spacer(280)
    );
  }

  // ── SECTION 2: STEP-BY-STEP LOGIC ────────────────────────────
  docChildren.push(h1("2. Step-by-Step Logic"));

  steps.forEach((step, idx) => {
    docChildren.push(h2(step.title));

    if (step.rationale) {
      docChildren.push(bodyPara(step.rationale));
    }

    if (step.filterRows && step.filterRows.length > 0) {
      docChildren.push(spacer(80), filterTable(step.filterRows), spacer(100));
    }

    if (step.sqlLines && step.sqlLines.length > 0) {
      const sqlChildren = step.sqlLines.map(line =>
        bodyPara(line, { font: "Courier New", size: 19, color: BC_GRAPHITE })
      );
      sqlChildren.push(spacer(40));
      if (step.notes && step.notes.length > 0) {
        step.notes.forEach(note => sqlChildren.push(notePara(note)));
      }
      docChildren.push(
        blueBox(step.sqlHeader || "SQL Fragment", sqlChildren),
        spacer(100)
      );
    }

    if (step.impact) {
      docChildren.push(
        bodyPara(`Impact: ${step.impact}`, { bold: true }),
        spacer(80)
      );
    }

    docChildren.push(
      bodyPara("☐ Approved  ☐ Change requested — see notes below", { italics: true, color: "888888" }),
      spacer(200)
    );
  });

  docChildren.push(spacer(80));

  // ── SECTION 3: COMPLETE QUERY REFERENCE ──────────────────────
  docChildren.push(h1("3. Complete Query Reference"));

  const sqlLines = fullSql.split('\n');
  const sqlChildren = sqlLines.map(line =>
    bodyPara(line, { font: "Courier New", size: 19, color: BC_GRAPHITE })
  );
  sqlChildren.push(
    spacer(40),
    notePara("Do not edit this query directly. All changes should be made to the filter definitions in Section 2 above. Claude will regenerate the complete query from your edits.")
  );

  docChildren.push(
    blueBox("Full SQL Query", sqlChildren),
    spacer(280)
  );

  // ── SECTION 4: BLUE CONTACT SUGGESTS ─────────────────────────
  if (suggestions && suggestions.length > 0) {
    docChildren.push(h1Seafoam("4. Blue Contact Suggests"));
    suggestions.forEach(suggestion => {
      docChildren.push(
        h2Seafoam(suggestion.title),
        bodyPara(suggestion.body),
        spacer(160)
      );
    });
    docChildren.push(spacer(80));
  }

  // ── SECTION 5: REVIEWER NOTES ────────────────────────────────
  docChildren.push(
    h1("5. Reviewer Notes"),
    bodyPara("Use this section to leave feedback, request changes, or flag questions before returning the document to the audience owner."),
    spacer(100),
    blueBox("Feedback & Sign-Off", [
      bodyPara("[Leave your notes here — e.g., 'Add TX', 'Expand to Manager level', 'Include phone-only contacts']", { italics: true, color: "888888" }),
      spacer(40),
      bodyPara("[Add any additional comments or questions here]", { italics: true, color: "888888" }),
      spacer(120),
      bodyPara("Reviewed by: ___________________________     Date: _____________", { italics: true, color: "888888" }),
      spacer(40)
    ]),
    spacer(280)
  );

  // ── SECTION 6: ASSUMPTIONS & CAVEATS ──────────────────────────
  if (assumptions && assumptions.length > 0) {
    docChildren.push(
      h1("6. Assumptions & Caveats"),
      spacer(80)
    );
    assumptions.forEach(assumption => {
      docChildren.push(bullet(assumption));
    });
    docChildren.push(spacer(280));
  }

  // ── SECTION 7: HOW TO SUBMIT EDITS ───────────────────────────
  docChildren.push(
    h1("7. How to Submit Edits"),
    bodyPara("Once you have made your changes, save the document and return it to the audience owner. They will re-ingest the updated criteria using the prompt below in their Claude Cowork session."),
    spacer(100),
    blueBox("Cowork Re-ingestion Prompt", [
      bodyPara(
        '"I\'ve attached an updated audience logic report. Please read the Step-by-Step Logic in Section 2 and the Reviewer Notes in Section 5, then update the audience query to reflect all requested changes. Run the updated count query first and confirm the new total before saving the audience."',
        { italics: true, color: BC_GRAPHITE }
      ),
      spacer(40),
      notePara("Claude will read all editable fields in Section 2 and any notes in Section 5, then regenerate and run the SQL query automatically.")
    ])
  );

  // ── CREATE DOCUMENT ────────────────────────────────────────────
  const doc = new Document({
    styles: {
      default: {
        document: { run: { font: "Arial", size: 22, color: BC_GRAPHITE } }
      },
      paragraphStyles: [
        {
          id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
          run: { size: 24, bold: true, font: "Arial", color: BC_GRAPHITE },
          paragraph: { spacing: { before: 360, after: 120 }, outlineLevel: 0 }
        },
        {
          id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
          run: { size: 22, bold: true, font: "Arial", color: BC_BLUE },
          paragraph: { spacing: { before: 240, after: 80 }, outlineLevel: 1 }
        }
      ]
    },
    numbering: {
      config: [{
        reference: "bullets",
        levels: [{
          level: 0,
          format: LevelFormat.BULLET,
          text: "•",
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } }
        }]
      }]
    },
    sections: [{
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1080, right: 1260, bottom: 1080, left: 1260 }
        }
      },

      // ── HEADER ──
      headers: {
        default: new Header({
          children: [
            new Paragraph({
              border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: BC_BLUE, space: 6 } },
              spacing: { before: 0, after: 120 },
              tabStops: [{ type: TabStopType.RIGHT, position: 9360 }],
              children: [
                logoImageRun(1.4),
                new TextRun({ text: "\t", size: 20 }),
                new TextRun({ text: "Audience Logic Report", font: "Arial", size: 18, color: "999999" })
              ]
            })
          ]
        })
      },

      // ── FOOTER ──
      footers: {
        default: new Footer({
          children: [
            new Paragraph({
              border: { top: { style: BorderStyle.SINGLE, size: 4, color: BC_BLUE, space: 6 } },
              spacing: { before: 100, after: 0 },
              tabStops: [{ type: TabStopType.RIGHT, position: 9360 }],
              children: [
                run("© Blue Contact  |  Confidential", { size: 18, color: "999999" }),
                new TextRun({ text: "\t", size: 18 }),
                run("Page ", { size: 18, color: "999999" }),
                new TextRun({ children: [PageNumber.CURRENT], font: "Arial", size: 18, color: "999999" }),
                run(" of ", { size: 18, color: "999999" }),
                new TextRun({ children: [PageNumber.TOTAL_PAGES], font: "Arial", size: 18, color: "999999" })
              ]
            })
          ]
        })
      },

      children: docChildren
    }]
  });

  return doc;
}

// ── CLI ────────────────────────────────────────────────────────────

const args = process.argv.slice(2);
if (args.length === 0) {
  console.error("Usage: node generate_report.js <data.json>");
  process.exit(1);
}

const jsonPath = args[0];
let data;

try {
  const jsonContent = fs.readFileSync(jsonPath, 'utf-8');
  data = JSON.parse(jsonContent);
} catch (err) {
  console.error(`Failed to read or parse ${jsonPath}: ${err.message}`);
  process.exit(1);
}

if (!data.outputPath) {
  console.error("Error: JSON must contain 'outputPath' field");
  process.exit(1);
}

const doc = generateReport(data);

Packer.toBuffer(doc).then(buf => {
  try {
    fs.writeFileSync(data.outputPath, buf);
    console.log(`Report written to: ${data.outputPath}`);
  } catch (err) {
    console.error(`Failed to write output: ${err.message}`);
    process.exit(1);
  }
}).catch(err => {
  console.error(`Failed to pack document: ${err.message}`);
  process.exit(1);
});
