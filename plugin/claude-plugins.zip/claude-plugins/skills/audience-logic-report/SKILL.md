---
name: audience-logic-report
description: Save the exact logic behind a Blue Contact audience as a shareable doc your team can QA — they check the filters, flag changes, and send it back to update the query automatically.
argument-hint: "audience ID, 'latest', or describe the audience"
allowed-tools:
  - mcp__blue-contact__get_schema
  - mcp__blue-contact__get_query_instructions
  - mcp__blue-contact__validate_sql
  - mcp__blue-contact__run_audience_query
  - mcp__blue-contact__execute_sql_query
  - mcp__blue-contact__get_audience_run
  - mcp__blue-contact__get_audience
  - mcp__blue-contact__list_audiences
  - mcp__blue-contact__save_message
  - mcp__blue-contact__save_artifact
  - AskUserQuestion
  - Read
  - Write
  - Bash
---

# Audience Logic Report

Save the exact results of an audience conversation as a shareable document your team can QA. The report captures every filter decision, the SQL behind it, and the progressive count at each step — so a teammate can verify the logic without needing access to the Cowork session.

The doc is designed for a **QA loop**: you build an audience, save the logic as a doc, send it to a teammate to check. They review the filters, flag anything that needs changing (via checkboxes and change notes), and send it back. You drop the edited doc back into your Cowork session and the audience query updates automatically.

## When This Skill Runs

- **On-demand**: User asks for a logic report, query explanation, or audience breakdown (e.g., "explain how this audience was built", "logic report for audience 42", "walk me through the query").
- **Auto-trigger after audience finalization**: When the `audience-pull` or `audience-building` workflow completes and the user signals they're satisfied with the audience (e.g., confirms the results, asks to download, or moves to next steps), those skills will prompt the user via AskUserQuestion asking if they want a logic report. If accepted, this skill runs automatically. **Do not prompt immediately after showing query results** — wait for a finalization signal. The trigger belongs in the calling skill (audience-pull / audience-building), not here.
- **Re-ingestion mode**: User uploads an edited logic report `.docx` back into the conversation. Detect this and switch to the re-ingestion workflow (see "Handling Edited Reports" below).

## Brand Configuration

Before generating any visual output (`.docx`), read `${CLAUDE_PLUGIN_ROOT}/brand/BRAND.md` for the official Blue Contact brand guide, then load color tokens from `${CLAUDE_PLUGIN_ROOT}/brand/brand.json`. The `brand/` directory lives at the plugin root, not the session working directory. All visual artifacts must use these brand colors — never invent your own. If the brand files cannot be read, fall back to: contactBlue `#006AFF`, graphite `#2A3A57`, clearSky `#334669`, seafoam `#12C7B4`, eggshell `#E4E9F5`, danger `#DB4646`, gradient `linear-gradient(135deg, #1A94FF 0%, #006AFF 100%)`, footer attribution "Data provided by Blue Contact" — never ship an unbranded artifact. (The bundled `scripts/generate_report.js` already embeds the correct tokens for `.docx` output.)

## Output Format

- **Default**: Branded `.docx` document using the `docx` skill patterns (see Document Structure below)
- **Markdown flag**: If the user says "markdown", "md", or "plain text", output a `.md` file instead — same layered content, lighter formatting
- When both are requested, generate both files

## Workflow

### 1. Identify the audience

- If the user provides an audience ID, use `get_audience` to load it
- If the user says "latest" or doesn't specify, call `list_audiences` and pick the most recent active audience
- If this skill was auto-triggered after an audience build, use the audience that was just created
- If no audiences exist, let the user know and offer to build one first (suggest the `audience-pull` skill)
- Extract the audience's SQL query, title, reasoning array, user prompt, and conversation history from the audience state

### 2. Gather query context

- Call `get_query_instructions` if not already loaded this session — needed to accurately explain SQL conventions
- Call `get_schema` (no params for summary, then `get_schema(database, table)` scoped to the table(s) the audience references — add `columns: [...]` for just the fields in the filters) to map column names to human-readable field descriptions
- Parse the audience's SQL query into its component parts: SELECT fields, FROM/JOIN chain, WHERE clauses, GROUP BY, ORDER BY, LIMIT

### 3. Decompose the query into logic steps

Break the query down into a numbered sequence of decisions. Each step should capture:

1. **What was decided** — the business-level filter or targeting choice (e.g., "Target building materials companies")
2. **Why** — the reasoning from the audience's `reasoning` array, user prompt, or conversation history
3. **How it translates to SQL** — the specific clause, column, operator, and values
4. **What it does to the count** — if practical, note the progressive narrowing effect (e.g., "This filter reduces the universe from ~2.1M to ~84K contacts")

Typical decomposition order:

- **Step 1 — Data source selection**: Which database and tables and why. Explain the JOIN chain.
- **Step 2 — Industry targeting**: Industry filter logic (name2–name6 OR pattern, activity_priority = 1)
- **Step 3 — Title / seniority filter**: Contact title keywords and the OR logic
- **Step 4 — Geographic scope**: State/city/zip filters and why those regions were chosen
- **Step 5 — Company size filter**: Employee count range and the business rationale
- **Step 6 — Contact quality gates**: Email/phone requirements, suppression lists, dedupe logic
- **Step 7 — Output fields & ordering**: What columns are returned and how results are sorted

Not every audience will have all steps — skip steps that don't apply and add steps for filters not listed above (e.g., income range, homeowner status, move date, property type).

### 4. Run progressive count queries (optional but recommended)

To show the narrowing funnel, run COUNT queries at key stages:

```sql
-- Universe (no filters). <catalog>.<business_db> = the datasource + database
-- name from get_schema — never hardcode them.
SELECT COUNT(DISTINCT c.contact_id)
FROM <catalog>.<business_db>.contacts c
JOIN <catalog>.<business_db>.companies co ON c.company_id = co.company_id

-- After industry filter
SELECT COUNT(DISTINCT c.contact_id)
FROM <catalog>.<business_db>.contacts c
JOIN <catalog>.<business_db>.companies co ON c.company_id = co.company_id
JOIN <catalog>.<business_db>.companies_company_industries cci ON co.company_id = cci.company_id
JOIN <catalog>.<business_db>.company_industries ci ON cci.company_industry_id = ci.company_industry_id
WHERE ci.company_industries_activity_priority = 1
  AND (ci.company_industries_name2 ILIKE '%Building Materials%' OR ...)

-- Continue adding filters cumulatively...
```

Present these as a narrowing funnel in the report. If runtime is a concern, at minimum run: total universe, after primary filter, and final count.

### 4b. Build the waterfall dropoff visualization

Generate a React (`.jsx`) waterfall chart artifact alongside the report using Recharts. This is a key deliverable — it makes the funnel data visual and immediately shows reviewers where the biggest dropoffs happen, so they can judge whether a filter is too aggressive or too loose.

**Data shape:** Use the progressive counts from Step 4. Each bar represents one filter step.

```jsx
// Example data structure — populate from actual counts
const funnelData = [
  { step: "Universe",         remaining: 12400000, dropped: 0,        pctDrop: null },
  { step: "Industry",         remaining: 84200,    dropped: 12315800, pctDrop: 99.3 },
  { step: "Title / Seniority",remaining: 12800,    dropped: 71400,    pctDrop: 84.8 },
  { step: "Geography",        remaining: 4200,     dropped: 8600,     pctDrop: 67.2 },
  { step: "Company Size",     remaining: 2100,     dropped: 2100,     pctDrop: 50.0 },
  { step: "Email Required",   remaining: 1247,     dropped: 853,      pctDrop: 40.6 },
];
```

**Chart design:**

- **Chart type**: Stacked horizontal bar chart (waterfall style) — each bar shows "remaining" (contactBlue) and "dropped" (eggshell or light gray) stacked to the previous step's total
- Alternative: vertical bar chart with connecting lines showing the drop between steps, similar to a classic waterfall
- **Colors**: Use brand tokens from `${CLAUDE_PLUGIN_ROOT}/brand/brand.json` — contactBlue (#006AFF) for remaining, eggshell (#E4E9F5) for dropped portion, danger (#DB4646) for any step that drops ≥97% (matching the .docx generator's threshold — huge drops are routine in funnels, so only flag the extreme ones)
- **Labels**: Each bar shows the remaining count (formatted with K/M abbreviations) and the % drop from the previous step
- **Annotations**: Flag the steepest dropoff step with a callout: "Largest filter: [step name] removed [X]% of records"
- **Layout**: Include a header with audience name, a stat row with total universe → final count → overall conversion rate, the waterfall chart, and a footer with "Data provided by Blue Contact"

**Component structure** (author from the skeleton below — don't read the sample `.jsx` files into context):

```jsx
import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, ReferenceLine } from "recharts";

// Brand tokens (load from brand.json values)
const BRAND = {
  contactBlue: "#006AFF",
  graphite: "#2A3A57",
  eggshell: "#E4E9F5",
  seafoam: "#12C7B4",
  danger: "#DB4646",
  white: "#FFFFFF",
};

// Utility: abbreviate large numbers
const fmt = (n) => {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toLocaleString();
};

// StatCard, CustomTooltip, and the main waterfall component follow:
// header (audience name) → stat row (universe → final → conversion %) →
// horizontal BarChart with per-bar Cell colors + ReferenceLine for the
// steepest dropoff → "Data provided by Blue Contact" footer.
```

- Present the `.jsx` artifact to the user alongside the `.docx` / `.md` report
- The visualization is interactive — tooltip on hover shows exact counts and percentages for each step

**For the .docx version:** Include a static representation of the waterfall as a styled table in Section 1 (Executive Summary), with horizontal bar indicators using table cell shading widths to approximate the visual proportions. Each row represents a step, with the "remaining" portion shaded in BC_BLUE and the "dropped" portion in BC_EGGSHELL, plus the count and % labels.

**Persist the waterfall:** Call `save_artifact` to attach the interactive waterfall chart to the audience. Detect `artifact_type` from the source code:
```
save_artifact(
  audience_id: <the audience ID>,
  title: "<Audience title> — Filter Funnel",
  source_code: <the complete source code>,
  artifact_type: <"react_dashboard" or "html">,
  metadata: { "generated_by": "audience-logic-report", "steps": <number of funnel steps>, "final_count": <final count> }
)
```
The shareable URL lets reviewers see the interactive funnel without needing Cowork access — include it alongside the .docx when delivering the report.

### 5. Build the report document

Two output formats — `.docx` (default) and `.md` (markdown flag). **Load `references/report-formats.md`** for the full spec: the `.docx` generator's JSON data schema + authoring rules + the `node scripts/generate_report.js` invocation, and the `.md` template. Key rule: for `.docx`, always use the bundled `scripts/generate_report.js` (write a JSON data file, then run it) — never build the docx inline with the `docx` skill.

### 6. Deliver and log

- Save the report file (`.docx` or `.md`) to the outputs folder and present it to the user
- Present the interactive waterfall dropoff `.jsx` visualization artifact alongside the report
- Log the report generation to the audience's conversation history using `save_message` with role "assistant" and a summary of what was generated
- Explain the collaboration workflow:
  - "Share this `.docx` with your teammate for review. They can edit the blue-marked filter values in Section 2 and leave feedback in Section 5 (Reviewer Notes)."
  - "When they return the edited document, drop it back into this conversation and I'll parse their changes, rebuild the query, run an updated count, and confirm before saving."
- Offer additional next steps:
  - "Want me to also generate the full audience segment report (demographics, coverage, visualizations)?"
  - "Need to adjust any of the logic steps yourself before sharing?"

## Handling Edited Reports (Re-ingestion Workflow)

When a user uploads an edited logic report back into the conversation — by attaching the `.docx`/`.md` file or pasting edited content — **load `references/re-ingestion.md`** and follow it. It covers parsing the edited doc, extracting filter/checkbox/note changes, rebuilding and validating the SQL, running the updated count first, confirming and applying via `run_audience_query`, and prompting to regenerate. Don't load it for normal report generation — only when an edited report comes back.

## Integration with Other Skills

- **audience-pull / audience-building**: After these skills complete, offer: "I can generate a logic report explaining how this query was built. Want one?"
- **audience-report**: The logic report complements the audience report — one explains the *what* (demographics, coverage), the other explains the *how* (query construction reasoning). Suggest generating both when a stakeholder review is needed.
- **data-querying**: Uses the same SQL patterns and conventions. Refer to `data-querying` skill knowledge for column mappings and Athena dialect rules.

## Quality Checks

Before delivering the report, verify:
- Every WHERE clause in the final SQL is accounted for in a logic step
- The funnel counts are internally consistent (each step <= previous step)
- The final count in the funnel matches the audience's actual record count
- Column names referenced in explanations exist in the current schema
- The complete query in Section 3 matches what was actually executed (pull from audience state, don't reconstruct)
