---
name: audience-logic-report
description: Save the exact logic behind a Blue Contact audience as a shareable doc your team can QA — they check the filters, flag changes, and send it back to update the query automatically.
argument-hint: "audience ID, 'latest', or describe the audience"
allowed-tools:
  - blue-contact:get_schema
  - blue-contact:get_query_instructions
  - blue-contact:validate_sql
  - blue-contact:execute_sql_query
  - blue-contact:get_audience
  - blue-contact:list_audiences
  - blue-contact:save_message
  - blue-contact:save_artifact
---

# Audience Logic Report

Save the exact results of an audience conversation as a shareable document your team can QA. The report captures every filter decision, the SQL behind it, and the progressive count at each step — so a teammate can verify the logic without needing access to the Cowork session.

The doc is designed for a **QA loop**: you build an audience, save the logic as a doc, send it to a teammate to check. They review the filters, flag anything that needs changing (via checkboxes and change notes), and send it back. You drop the edited doc back into your Cowork session and the audience query updates automatically.

## When This Skill Runs

- **On-demand**: User asks for a logic report, query explanation, or audience breakdown (e.g., "explain how this audience was built", "logic report for audience 42", "walk me through the query").
- **Auto-trigger after audience finalization**: When the `audience-pull` or `audience-building` workflow completes and the user signals they're satisfied with the audience (e.g., confirms the results, asks to download, or moves to next steps), those skills will prompt the user via AskUserQuestion asking if they want a logic report. If accepted, this skill runs automatically. **Do not prompt immediately after showing query results** — wait for a finalization signal. The trigger belongs in the calling skill (audience-pull / audience-building), not here.
- **Re-ingestion mode**: User uploads an edited logic report `.docx` back into the conversation. Detect this and switch to the re-ingestion workflow (see "Handling Edited Reports" below).

## Brand Configuration

Before generating any visual output (`.docx`), read `brand/BRAND.md` for the official Blue Contact brand guide, then load color tokens from `brand/brand.json`. All visual artifacts must use these brand colors — never hardcode color values.

## Output Format

- **Default**: Branded `.docx` document using the `docx` skill patterns (see Document Structure below)
- **Markdown flag**: If the user says "markdown", "md", or "plain text", output a `.md` file instead — same layered content, lighter formatting
- When both are requested, generate both files

## Workflow

### 1. Identify the audience

- If the user provides an audience ID, use `get_audience` to load it
- If the user says "latest" or doesn't specify, call `list_audiences` and pick the most recent active audience
- If this skill was auto-triggered after an audience build, use the audience that was just created
- If no audiences exist, let the user know and offer to build one first (suggest the `audience-pull` skill)
- Extract the audience's SQL query, title, reasoning array, user prompt, and conversation history from the audience state

### 2. Gather query context

- Call `get_query_instructions` if not already loaded this session — needed to accurately explain SQL conventions
- Call `get_schema` (no params for summary, then with `database` param for relevant databases) to map column names to human-readable field descriptions
- Parse the audience's SQL query into its component parts: SELECT fields, FROM/JOIN chain, WHERE clauses, GROUP BY, ORDER BY, LIMIT

### 3. Decompose the query into logic steps

Break the query down into a numbered sequence of decisions. Each step should capture:

1. **What was decided** — the business-level filter or targeting choice (e.g., "Target building materials companies")
2. **Why** — the reasoning from the audience's `reasoning` array, user prompt, or conversation history
3. **How it translates to SQL** — the specific clause, column, operator, and values
4. **What it does to the count** — if practical, note the progressive narrowing effect (e.g., "This filter reduces the universe from ~2.1M to ~84K contacts")

Typical decomposition order:

- **Step 1 — Data source selection**: Which database and tables and why. Explain the JOIN chain.
- **Step 2 — Industry targeting**: Industry filter logic (name2–name6 OR pattern, activity_priority = 1)
- **Step 3 — Title / seniority filter**: Contact title keywords and the OR logic
- **Step 4 — Geographic scope**: State/city/zip filters and why those regions were chosen
- **Step 5 — Company size filter**: Employee count range and the business rationale
- **Step 6 — Contact quality gates**: Email/phone requirements, suppression lists, dedupe logic
- **Step 7 — Output fields & ordering**: What columns are returned and how results are sorted

Not every audience will have all steps — skip steps that don't apply and add steps for filters not listed above (e.g., income range, homeowner status, move date, property type).

### 4. Run progressive count queries (optional but recommended)

To show the narrowing funnel, run COUNT queries at key stages:

```sql
-- Universe (no filters)
SELECT COUNT(DISTINCT c.contact_id)
FROM lsc_data_catalog.business_db.contacts c
JOIN lsc_data_catalog.business_db.companies co ON c.company_id = co.company_id

-- After industry filter
SELECT COUNT(DISTINCT c.contact_id)
FROM lsc_data_catalog.business_db.contacts c
JOIN lsc_data_catalog.business_db.companies co ON c.company_id = co.company_id
JOIN lsc_data_catalog.business_db.companies_company_industries cci ON co.company_id = cci.company_id
JOIN lsc_data_catalog.business_db.company_industries ci ON cci.company_industry_id = ci.company_industry_id
WHERE ci.company_industries_activity_priority = 1
  AND (ci.company_industries_name2 ILIKE '%Building Materials%' OR ...)

-- Continue adding filters cumulatively...
```

Present these as a narrowing funnel in the report. If runtime is a concern, at minimum run: total universe, after primary filter, and final count.

### 4b. Build the waterfall dropoff visualization

Generate a React (`.jsx`) waterfall chart artifact alongside the report using Recharts. This is a key deliverable — it makes the funnel data visual and immediately shows reviewers where the biggest dropoffs happen, so they can judge whether a filter is too aggressive or too loose.

**Data shape:** Use the progressive counts from Step 4. Each bar represents one filter step.

```jsx
// Example data structure — populate from actual counts
const funnelData = [
  { step: "Universe",         remaining: 12400000, dropped: 0,        pctDrop: null },
  { step: "Industry",         remaining: 84200,    dropped: 12315800, pctDrop: 99.3 },
  { step: "Title / Seniority",remaining: 12800,    dropped: 71400,    pctDrop: 84.8 },
  { step: "Geography",        remaining: 4200,     dropped: 8600,     pctDrop: 67.2 },
  { step: "Company Size",     remaining: 2100,     dropped: 2100,     pctDrop: 50.0 },
  { step: "Email Required",   remaining: 1247,     dropped: 853,      pctDrop: 40.6 },
];
```

**Chart design:**

- **Chart type**: Stacked horizontal bar chart (waterfall style) — each bar shows "remaining" (contactBlue) and "dropped" (eggshell or light gray) stacked to the previous step's total
- Alternative: vertical bar chart with connecting lines showing the drop between steps, similar to a classic waterfall
- **Colors**: Use brand tokens from `brand/brand.json` — contactBlue (#006AFF) for remaining, eggshell (#E4E9F5) for dropped portion, danger (#DB4646) for any step that drops >80%
- **Labels**: Each bar shows the remaining count (formatted with K/M abbreviations) and the % drop from the previous step
- **Annotations**: Flag the steepest dropoff step with a callout: "Largest filter: [step name] removed [X]% of records"
- **Layout**: Include a header with audience name, a stat row with total universe → final count → overall conversion rate, the waterfall chart, and a footer with "Data provided by Blue Contact"

**Component structure** (follow the existing `b2b-landscape.jsx` pattern):

```jsx
import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, ReferenceLine } from "recharts";

// Brand tokens (load from brand.json values)
const BRAND = {
  contactBlue: "#006AFF",
  graphite: "#2A3A57",
  eggshell: "#E4E9F5",
  seafoam: "#12C7B4",
  danger: "#DB4646",
  white: "#FFFFFF",
};

// Utility: abbreviate large numbers
const fmt = (n) => {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toLocaleString();
};

// StatCard, CustomTooltip, and main component
// ... (follow b2b-landscape.jsx patterns)
```

- Present the `.jsx` artifact to the user alongside the `.docx` / `.md` report
- The visualization is interactive — tooltip on hover shows exact counts and percentages for each step

**For the .docx version:** Include a static representation of the waterfall as a styled table in Section 1 (Executive Summary), with horizontal bar indicators using table cell shading widths to approximate the visual proportions. Each row represents a step, with the "remaining" portion shaded in BC_BLUE and the "dropped" portion in BC_EGGSHELL, plus the count and % labels.

**Persist the waterfall:** Call `save_artifact` to attach the interactive waterfall chart to the audience. Detect `artifact_type` from the source code:
```
save_artifact(
  audience_id: <the audience ID>,
  title: "<Audience title> — Filter Funnel",
  source_code: <the complete source code>,
  artifact_type: <"react_dashboard" or "html">,
  metadata: { "generated_by": "audience-logic-report", "steps": <number of funnel steps>, "final_count": <final count> }
)
```
The shareable URL lets reviewers see the interactive funnel without needing Cowork access — include it alongside the .docx when delivering the report.

### 5. Build the report document

#### For .docx (default) — use the bundled generator script

The skill includes a branded report generator at `scripts/generate_report.js` that produces pixel-perfect branded .docx files with the Blue Contact logo, brand colors, and formatting. Do NOT build docx files inline with the `docx` skill — always use this script.

**How it works:** Write a JSON data file with all the report content, then run the script. The script handles all styling, logo embedding, headers/footers, and formatting automatically.

**Step 1 — Write the data JSON file**

Save a file (e.g., `/tmp/report_data.json`) with this structure:

```json
{
  "outputPath": "/path/to/Audience_Logic_Report.docx",
  "audience": {
    "title": "Audience Name",
    "id": 12345,
    "createdBy": "User Name",
    "date": "April 16, 2026",
    "status": "Draft",
    "totalContacts": "265,668"
  },
  "executiveSummary": {
    "narrative": "3-5 sentence plain-English narrative of who this audience targets, why, and how many records it contains.",
    "stats": {
      "emailCoverage": "63.3% (168,205)",
      "phoneCoverage": "67.6% (179,599)",
      "topStates": "CA, NY, TX, FL, PA"
    }
  },
  "waterfall": [
    { "step": 0, "filter": "Universe (all contacts)", "remaining": 93620049, "dropped": null, "pctDrop": null },
    { "step": 1, "filter": "US-based contacts only", "remaining": 49079383, "dropped": 44540666, "pctDrop": "47.6%" },
    { "step": 2, "filter": "Seniority filter", "remaining": 9122764, "dropped": 39956619, "pctDrop": "81.4%" },
    { "step": 3, "filter": "Industry filter", "remaining": 265668, "dropped": 8857096, "pctDrop": "97.1%" }
  ],
  "steps": [
    {
      "title": "Step 1: Data Source Selection",
      "rationale": "Plain English explanation of the decision and business reasoning.",
      "filterRows": null,
      "sqlHeader": "SQL Fragment",
      "sqlLines": ["FROM lsc_data_catalog.business_db.contacts c JOIN ..."],
      "notes": ["Explanatory notes about the SQL or column behavior."],
      "impact": null
    },
    {
      "title": "Step 2: Filter Name",
      "rationale": "Why this filter was applied.",
      "filterRows": [
        ["Setting Label", "Editable Value", true],
        ["Non-editable Label", "Fixed Value", false]
      ],
      "sqlHeader": "SQL Condition",
      "sqlLines": ["AND column = 'value'"],
      "notes": ["Column explanation or caveats."],
      "impact": "93.6M → 49.1M (47.6% drop)"
    }
  ],
  "fullSql": "The complete SQL query as a single string",
  "suggestions": [
    {
      "title": "1. Suggestion Title",
      "body": "Detailed recommendation with business reasoning."
    }
  ],
  "assumptions": [
    "Assumption or caveat text",
    "Another assumption"
  ]
}
```

**Key data authoring rules:**

- `waterfall`: one entry per progressive filter step. `remaining` and `dropped` are integers. `pctDrop` is a formatted string like "47.6%" or null for the first step. Steps with pctDrop containing values ≥ 97% render in danger red automatically.
- `steps`: one entry per logic step from the query decomposition (Step 3 above). `filterRows` is an array of `[label, value, editable]` triples — set `editable: true` for values the reviewer can change (rendered in blue with "← editable" hint). Set to `null` if the step has no editable filter (e.g., data source selection).
- `sqlLines`: array of strings, each rendered on its own line in Courier New inside a blue box.
- `suggestions`: 3–5 AI-generated recommendations. Each has a `title` (numbered, like "1. Add Email Quality Gates") and a `body` (the full recommendation paragraph). Organize suggestions by category: expand reach, sharpen targeting, improve coverage, split opportunities, data enrichment. Each suggestion should include the business reasoning and describe what SQL change it would require.
- `assumptions`: array of plain strings rendered as bullet points.
- Format all numbers with commas in the JSON (the script renders them as-is).
- The `narrative` in executiveSummary should summarize: who the audience targets, the campaign goal, total size, and key coverage/geographic highlights.

**Step 2 — Run the generator script**

```bash
node <skill-path>/scripts/generate_report.js /tmp/report_data.json
```

The script reads the JSON, embeds the Blue Contact logo, and produces the branded .docx at `outputPath`. The output matches the brand template exactly: logo in header, graphite/blue color scheme, editable filter tables, blue boxes for SQL, seafoam section for suggestions, reviewer sign-off area, and re-ingestion instructions.

**Step 3 — Validate (optional but recommended)**

```bash
python <docx-skill-path>/scripts/office/validate.py <outputPath>
```

#### For .md (markdown flag)

Same layered structure, lighter formatting:

```markdown
# Audience Logic Report: [Audience Name]

**Audience ID:** [id] | **Created:** [date] | **Total Contacts:** [count] | **Status:** [status]

## Executive Summary

[3-5 sentence narrative]

### Targeting Funnel

| Step | Filter | Records | Reduction |
|------|--------|---------|-----------|
| ... | ... | ... | ... |

## Step-by-Step Query Logic

### Step 1: Data Source Selection

**Why:** [business rationale]

**Current value:** [editable value] ← editable

```sql
[SQL fragment]
```

**Column:** `table.column` — [description]
**Impact:** [X] → [Y] records
**Review:** ☐ Approved  ☐ Change requested

[repeat for each step]

## Complete Query

```sql
[full query]
```

> Do not edit directly — change values in the steps above or leave notes in Reviewer Notes.

## Blue Contact Suggests

### Suggestion 1: [title]
[recommendation with business reasoning and SQL snippet]

### Suggestion 2: [title]
[recommendation with business reasoning and SQL snippet]

> These suggestions are advisory — to apply one, note it in Reviewer Notes below.

## Reviewer Notes

**Reviewer:** [name]  **Date:** [date]

[Leave your feedback here — e.g., "Step 2 should also include HVAC distributors"
or "Remove FL from geography" or "The title filter is too broad, narrow to C-Suite only"]

## Assumptions & Caveats

- [list of assumptions]

## How to Submit Edits

Save this file and return it to the audience owner. They will drop it into their
Claude Cowork session with this prompt:

> "I've attached an updated audience logic report. Please read the editable filter
> values in the Step-by-Step section and the Reviewer Notes, then update the Blue
> Contact audience query to reflect all requested changes. Run the updated count
> query first and confirm the new total before saving the audience."
```

### 6. Deliver and log

- Save the report file (`.docx` or `.md`) to the outputs folder and present it to the user
- Present the interactive waterfall dropoff `.jsx` visualization artifact alongside the report
- Log the report generation to the audience's conversation history using `save_message` with role "assistant" and a summary of what was generated
- Explain the collaboration workflow:
  - "Share this `.docx` with your teammate for review. They can edit the blue-marked filter values in Section 2 and leave feedback in Section 4 (Reviewer Notes)."
  - "When they return the edited document, drop it back into this conversation and I'll parse their changes, rebuild the query, run an updated count, and confirm before saving."
- Offer additional next steps:
  - "Want me to also generate the full audience segment report (demographics, coverage, visualizations)?"
  - "Need to adjust any of the logic steps yourself before sharing?"

## Handling Edited Reports (Re-ingestion Workflow)

When a user uploads an edited logic report back into the conversation — either by attaching the `.docx`/`.md` file or by pasting edited content — follow this workflow:

### 1. Parse the edited document

- Read the uploaded file (use the `docx` skill to extract text from `.docx`, or read `.md` directly)
- Identify the **Audience ID** from the title block / summary table
- Load the original audience state using `get_audience` with that ID

### 2. Extract all changes

Compare the edited document against the original audience state. Look for changes in three places:

**Editable filter values in Section 2:**
Each logic step has an editable value row. Map each changed value back to its SQL clause:

| Step field | Maps to SQL |
|-----------|-------------|
| Industry list | `ci.company_industries_name2 ILIKE '%value%' OR ...` across name2–name6 |
| Title keywords | `c.contact_title ILIKE '%value%' OR ...` |
| State codes | `co.company_state IN ('XX','XX',...)` |
| Min/Max employees | `co.company_employee_count BETWEEN min AND max` |
| Email required | `AND c.contact_email IS NOT NULL` (add or remove) |
| Phone required | `AND c.contact_phone IS NOT NULL` (add or remove) |
| Suppression list | `AND c.contact_id NOT IN (SELECT contact_id FROM audience_[id])` |

**Step review checkboxes and change notes in Section 2:**
- Each step has interactive checkboxes: ☐ Approved / ☐ Change requested
- Each step also has a **Change notes** field below the checkboxes
- Parse the structured document tags (SDTs) in the docx to read checked state (`w14:checked val="1"`)
- If "Change requested" is checked, read the change notes for that step and apply the described change
- If "Approved" is checked (or neither is checked), keep that clause unchanged

**Suggestion actions in Section 4 (Blue Contact Suggests):**
- Each suggestion has interactive checkboxes: ☐ Accept / ☐ Skip
- If "Accept" is checked, apply that suggestion's SQL change to the query
- If "Skip" is checked (or neither is checked), do not apply
- Multiple suggestions can be accepted simultaneously

**Reviewer Notes in Section 5:**
- Parse all freeform feedback
- Match notes to specific logic steps where possible (e.g., "Step 2 should also include HVAC" → modify the industry filter)
- Flag any notes that are ambiguous or require clarification — ask the user before proceeding

### 3. Rebuild the SQL query

- Start from the original query
- Apply each identified change to the relevant SQL clause
- Follow the same SQL patterns documented in the spec (fully qualified Athena paths, ILIKE with OR across name2–name6, etc.)
- Validate the rebuilt query with `validate_sql`

### 4. Run the updated count query first

- Execute a COUNT version of the rebuilt query via `execute_sql_query`
- Present the new total alongside the original total: "Original: 1,247 contacts → Updated: 2,891 contacts (+132%)"
- If the count changed dramatically (>50% increase or >30% decrease), flag this and confirm with the user before proceeding

### 5. Confirm and apply

- Present a summary of all changes made, organized by logic step
- Ask the user to confirm before saving
- Once confirmed, update the audience using `run_audience_query` with the new SQL, updated reasoning array, and the reviewer's feedback as context
- Log the review cycle to the audience conversation history via `save_message`, including: who reviewed it, what changed, the old vs. new count

### 6. Prompt to regenerate the logic report

After confirming and applying the query changes, prompt the user sequentially:

**Prompt 1 — Regenerate report:**
> "The audience has been updated (original: X contacts → updated: Y contacts). Would you like me to regenerate the logic report with the new query, counts, and waterfall data?"

If yes, regenerate the full report (docx and/or markdown per user preference) with updated:
- Summary table (new count, new date)
- Executive summary reflecting new filter values
- Waterfall funnel with fresh progressive counts from the updated query
- Step-by-step logic reflecting the changed filter values
- Updated complete query in Section 3
- Fresh Blue Contact Suggests based on the new query state
- Clear reviewer notes and reset all checkboxes to unchecked

**Prompt 2 — Send for review:**
> "Here's the updated report. Would you like to send it back for another review round?"

This enables iterative review cycles — the report can go back and forth between analyst and reviewer until both sides are satisfied with the targeting logic. Each cycle produces a clean report with reset checkboxes and updated data.

## Integration with Other Skills

- **audience-pull / audience-building**: After these skills complete, offer: "I can generate a logic report explaining how this query was built. Want one?"
- **audience-report**: The logic report complements the audience report — one explains the *what* (demographics, coverage), the other explains the *how* (query construction reasoning). Suggest generating both when a stakeholder review is needed.
- **data-querying**: Uses the same SQL patterns and conventions. Refer to `data-querying` skill knowledge for column mappings and Athena dialect rules.

## Quality Checks

Before delivering the report, verify:
- Every WHERE clause in the final SQL is accounted for in a logic step
- The funnel counts are internally consistent (each step <= previous step)
- The final count in the funnel matches the audience's actual record count
- Column names referenced in explanations exist in the current schema
- The complete query in Section 3 matches what was actually executed (pull from audience state, don't reconstruct)
