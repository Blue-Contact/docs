# Report formats (section 5 — build the report document)

Load this when you're ready to render the report. Two output formats: `.docx` (default, via the bundled generator) and `.md` (markdown flag).

## For .docx (default) — use the bundled generator script

The skill includes a branded report generator at `scripts/generate_report.js` that produces pixel-perfect branded .docx files with the Blue Contact logo, brand colors, and formatting. Do NOT build docx files inline with the `docx` skill — always use this script.

**How it works:** Write a JSON data file with all the report content, then run the script. The script handles all styling, logo embedding, headers/footers, and formatting automatically.

**Step 1 — Write the data JSON file**

Save a file (e.g., `/tmp/report_data.json`) with this structure:

```json
{
  "outputPath": "/path/to/Audience_Logic_Report.docx",
  "audience": {
    "title": "Audience Name",
    "id": 12345,
    "createdBy": "User Name",
    "date": "April 16, 2026",
    "status": "Draft",
    "totalContacts": "265,668"
  },
  "executiveSummary": {
    "narrative": "3-5 sentence plain-English narrative of who this audience targets, why, and how many records it contains.",
    "stats": {
      "emailCoverage": "63.3% (168,205)",
      "phoneCoverage": "67.6% (179,599)",
      "topStates": "CA, NY, TX, FL, PA"
    }
  },
  "waterfall": [
    { "step": 0, "filter": "Universe (all contacts)", "remaining": 93620049, "dropped": null, "pctDrop": null },
    { "step": 1, "filter": "US-based contacts only", "remaining": 49079383, "dropped": 44540666, "pctDrop": "47.6%" },
    { "step": 2, "filter": "Seniority filter", "remaining": 9122764, "dropped": 39956619, "pctDrop": "81.4%" },
    { "step": 3, "filter": "Industry filter", "remaining": 265668, "dropped": 8857096, "pctDrop": "97.1%" }
  ],
  "steps": [
    {
      "title": "Step 1: Data Source Selection",
      "rationale": "Plain English explanation of the decision and business reasoning.",
      "filterRows": null,
      "sqlHeader": "SQL Fragment",
      "sqlLines": ["FROM <catalog>.<business_db>.contacts c JOIN ..."],
      "notes": ["Explanatory notes about the SQL or column behavior."],
      "impact": null
    },
    {
      "title": "Step 2: Filter Name",
      "rationale": "Why this filter was applied.",
      "filterRows": [
        ["Setting Label", "Editable Value", true],
        ["Non-editable Label", "Fixed Value", false]
      ],
      "sqlHeader": "SQL Condition",
      "sqlLines": ["AND column = 'value'"],
      "notes": ["Column explanation or caveats."],
      "impact": "93.6M → 49.1M (47.6% drop)"
    }
  ],
  "fullSql": "The complete SQL query as a single string",
  "suggestions": [
    {
      "title": "1. Suggestion Title",
      "body": "Detailed recommendation with business reasoning."
    }
  ],
  "assumptions": [
    "Assumption or caveat text",
    "Another assumption"
  ]
}
```

**Key data authoring rules:**

- `waterfall`: one entry per progressive filter step. `remaining` and `dropped` are integers. `pctDrop` is a formatted string like "47.6%" or null for the first step. Steps with pctDrop containing values ≥ 97% render in danger red automatically.
- `steps`: one entry per logic step from the query decomposition (Step 3 above). `filterRows` is an array of `[label, value, editable]` triples — set `editable: true` for values the reviewer can change (rendered in blue with "← editable" hint). Set to `null` if the step has no editable filter (e.g., data source selection).
- `sqlLines`: array of strings, each rendered on its own line in Courier New inside a blue box.
- `suggestions`: 3–5 AI-generated recommendations. Each has a `title` (numbered, like "1. Add Email Quality Gates") and a `body` (the full recommendation paragraph). Organize suggestions by category: expand reach, sharpen targeting, improve coverage, split opportunities, data enrichment. Each suggestion should include the business reasoning and describe what SQL change it would require.
- `assumptions`: array of plain strings rendered as bullet points.
- Format all numbers with commas in the JSON (the script renders them as-is).
- The `narrative` in executiveSummary should summarize: who the audience targets, the campaign goal, total size, and key coverage/geographic highlights.

**Step 2 — Run the generator script**

The script requires the `docx` npm package. Install it once into the skill's scripts directory before the first run (no package.json is bundled):

```bash
cd <skill-path>/scripts && npm install docx 2>/dev/null || npm install --prefix . docx
node <skill-path>/scripts/generate_report.js /tmp/report_data.json
```

If npm isn't available or the install fails, fall back to a working directory: copy `generate_report.js` and the `assets/` folder somewhere writable, `npm install docx` there, and run it from that location.

The script reads the JSON, embeds the Blue Contact logo, and produces the branded .docx at `outputPath`. The output matches the brand template exactly: logo in header, graphite/blue color scheme, editable filter tables, blue boxes for SQL, seafoam section for suggestions, reviewer sign-off area, and re-ingestion instructions.

**Step 3 — Validate (optional but recommended)**

```bash
python <docx-skill-path>/scripts/office/validate.py <outputPath>
```

## For .md (markdown flag)

Same layered structure, lighter formatting:

```markdown
# Audience Logic Report: [Audience Name]

**Audience ID:** [id] | **Created:** [date] | **Total Contacts:** [count] | **Status:** [status]

## Executive Summary

[3-5 sentence narrative]

### Targeting Funnel

| Step | Filter | Records | Reduction |
|------|--------|---------|-----------|
| ... | ... | ... | ... |

## Step-by-Step Query Logic

### Step 1: Data Source Selection

**Why:** [business rationale]

**Current value:** [editable value] ← editable

```sql
[SQL fragment]
```

**Column:** `table.column` — [description]
**Impact:** [X] → [Y] records
**Review:** ☐ Approved  ☐ Change requested

[repeat for each step]

## Complete Query

```sql
[full query]
```

> Do not edit directly — change values in the steps above or leave notes in Reviewer Notes.

## Blue Contact Suggests

### Suggestion 1: [title]
[recommendation with business reasoning and SQL snippet]

### Suggestion 2: [title]
[recommendation with business reasoning and SQL snippet]

> These suggestions are advisory — to apply one, note it in Reviewer Notes below.

## Reviewer Notes

**Reviewer:** [name]  **Date:** [date]

[Leave your feedback here — e.g., "Step 2 should also include HVAC distributors"
or "Remove FL from geography" or "The title filter is too broad, narrow to C-Suite only"]

## Assumptions & Caveats

- [list of assumptions]

## How to Submit Edits

Save this file and return it to the audience owner. They will drop it into their
Claude Cowork session with this prompt:

> "I've attached an updated audience logic report. Please read the editable filter
> values in the Step-by-Step section and the Reviewer Notes, then update the Blue
> Contact audience query to reflect all requested changes. Run the updated count
> query first and confirm the new total before saving the audience."
```
