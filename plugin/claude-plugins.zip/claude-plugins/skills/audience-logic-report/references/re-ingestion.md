# Handling edited reports (re-ingestion workflow)

Load this **only** when a user uploads an edited logic report back into the conversation — by attaching the `.docx`/`.md` file or pasting edited content. Otherwise it isn't needed.

## 1. Parse the edited document

- Read the uploaded file (use the `docx` skill to extract text from `.docx`, or read `.md` directly)
- Identify the **Audience ID** from the title block / summary table
- Load the original audience state using `get_audience` with that ID

## 2. Extract all changes

Compare the edited document against the original audience state. Look for changes in three places:

**Editable filter values in the logic steps (Section 2):**
Each logic step renders its filters as `[label, value]` rows, with editable values shown in blue with an "← editable" hint. Diff each value against the original audience state and map changes back to the SQL clause that step documents. The step's own "SQL Condition" block tells you exactly which clause, column, and operator the value feeds — derive the mapping from the document itself, not from a fixed column list (column names vary by database and account; the table below is an *illustrative* B2B example, not a contract):

| Step field (example) | Maps to SQL (example) |
|-----------|-------------|
| Industry list | `ci.company_industries_name2 ILIKE '%value%' OR ...` across name2–name6 |
| Title keywords | `c.contact_title ILIKE '%value%' OR ...` |
| State codes | `co.company_state IN ('XX','XX',...)` |
| Min/Max employees | `co.company_employee_count BETWEEN min AND max` |
| Email required | `AND c.contact_email IS NOT NULL` (add or remove) |
| Phone required | `AND c.contact_phone IS NOT NULL` (add or remove) |

**Per-step review marks:**
- Each step ends with a literal text line: `☐ Approved  ☐ Change requested — see notes below`
- These are plain characters, not interactive Word controls. Reviewers mark them however Word lets them: replacing `☐` with `☑`/`☒`, typing an `X` next to one, bolding/highlighting one option, or striking through the other. Treat *any* visible marking of "Change requested" as a change request for that step.
- There is no per-step notes field — the change itself lives in the edited blue values and/or the Reviewer Notes section.
- If "Approved" is marked (or nothing is marked and no values changed), keep that step's clause unchanged.

**Suggestion adoptions (Blue Contact Suggests — Section 4):**
- Suggestions are advisory paragraphs, not checkboxes. A reviewer adopts one by saying so in Reviewer Notes (e.g., "apply suggestion 2") or by marking/annotating the suggestion text itself.
- Apply each adopted suggestion's SQL change to the query; ignore the rest.

**Reviewer Notes (Section 5):**
- Parse all freeform feedback
- Match notes to specific logic steps where possible (e.g., "Step 2 should also include HVAC" → modify the industry filter)
- Flag any notes that are ambiguous or require clarification — ask the user before proceeding

## 3. Rebuild the SQL query

- Start from the original query
- Apply each identified change to the relevant SQL clause
- Follow the same SQL patterns documented in the spec (fully qualified Athena paths, ILIKE with OR across name2–name6, etc.)
- Validate the rebuilt query with `validate_sql`

## 4. Run the updated count query first

- Execute a COUNT version of the rebuilt query via `execute_sql_query`, passing the existing `audience_id` so the probe is recorded on the same audience the report is for. The COUNT does not overwrite the audience's canonical SQL — that only happens in step 5.
- Present the new total alongside the original total: "Original: 1,247 contacts → Updated: 2,891 contacts (+132%)"
- If the count changed dramatically (>50% increase or >30% decrease), flag this and confirm with the user before proceeding

## 5. Confirm and apply

- Present a summary of all changes made, organized by logic step
- Ask the user to confirm before saving
- Once confirmed, update the audience using `run_audience_query` with the new SQL, updated reasoning array, and the reviewer's feedback as context
- Log the review cycle to the audience conversation history via `save_message`, including: who reviewed it, what changed, the old vs. new count

## 6. Prompt to regenerate the logic report

After confirming and applying the query changes, prompt the user sequentially:

**Prompt 1 — Regenerate report:**
> "The audience has been updated (original: X contacts → updated: Y contacts). Would you like me to regenerate the logic report with the new query, counts, and waterfall data?"

If yes, regenerate the full report (docx and/or markdown per user preference) with updated:
- Summary table (new count, new date)
- Executive summary reflecting new filter values
- Waterfall funnel with fresh progressive counts from the updated query
- Step-by-step logic reflecting the changed filter values
- Updated complete query in Section 3
- Fresh Blue Contact Suggests based on the new query state
- Clear reviewer notes and reset all checkboxes to unchecked

**Prompt 2 — Send for review:**
> "Here's the updated report. Would you like to send it back for another review round?"

This enables iterative review cycles — the report can go back and forth between analyst and reviewer until both sides are satisfied with the targeting logic. Each cycle produces a clean report with reset checkboxes and updated data.
