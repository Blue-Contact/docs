---
name: market-sizing
description: Size a target market using Blue Contact data — total addressable market, geographic breakdown, reachability analysis, and opportunity dashboard
argument-hint: "description of your target market"
allowed-tools:
  - mcp__blue-contact__get_schema
  - mcp__blue-contact__get_query_instructions
  - mcp__blue-contact__validate_sql
  - mcp__blue-contact__execute_sql_query
  - mcp__blue-contact__run_audience_query
  - mcp__blue-contact__get_audience_run
  - mcp__blue-contact__save_message
  - mcp__blue-contact__save_artifact
  - AskUserQuestion
  - Read
  - Write
---

# Market Sizing / TAM Calculator

Help users size a target market using Blue Contact's data. Transform a market description into a quantified opportunity with geographic breakdowns, reachability analysis, and a polished market dashboard.

## Async query results

`run_audience_query` and `execute_sql_query` are async — each call returns a kick-off (`{status: "queued", run_id, ...}` with no rows). Poll `get_audience_run` with the returned `run_id` every 2–5 seconds until `status: "completed"`; the completed response carries `rows`, `columns`, `coverage_summary`, and `download_url`. Every step below that mentions one of those tools implies this poll loop. Full pattern: `${CLAUDE_PLUGIN_ROOT}/skills/audience-building/SKILL.md` → "Polling for results".

## Brand Configuration

Before generating any visual output, read `${CLAUDE_PLUGIN_ROOT}/brand/BRAND.md` for the official Blue Contact brand guide, then load color tokens from `${CLAUDE_PLUGIN_ROOT}/brand/brand.json`. The `brand/` directory lives at the plugin root, not the session working directory. All visual artifacts must use these brand colors — never invent your own.

**Every visual artifact must include the Blue Contact icon at minimum.** Embed the icon (`${CLAUDE_PLUGIN_ROOT}/brand/logos/icon-gradient.svg`) or, for headers, the horizontal logo (`${CLAUDE_PLUGIN_ROOT}/brand/logos/horizontal-gradient.svg`). See `${CLAUDE_PLUGIN_ROOT}/brand/BRAND.md` for placement guidance per artifact type.

**Fallback palette** — if the brand files cannot be read, do not ship an unbranded artifact; use these tokens: contactBlue `#006AFF` (primary), graphite `#2A3A57` (text), clearSky `#334669` (secondary text), seafoam `#12C7B4` (accent), eggshell `#E4E9F5` (backgrounds/borders), success `#00C864`, danger `#DB4646`, hazard `#FF9A1F`, gradient `linear-gradient(135deg, #1A94FF 0%, #006AFF 100%)`. Chart series order: `#006AFF`, `#1994FF`, `#12C7B4`, `#334669`, `#FF9A1F`, `#00C864`. Every artifact carries the footer attribution "Data provided by Blue Contact".

## Workflow

### 1. Understand the market definition

Parse the user's description of their target market. If details are missing, use `AskUserQuestion` to clarify:

- **Who**: Consumer or business? What demographics/firmographics define the target?
- **Where**: National, regional, or specific states/markets?
- **What makes them a prospect**: Homeowners? Specific income range? Industry vertical? Recent movers?
- **What's the product/service**: This helps frame the analysis (e.g., home improvement → homeowners + property age; auto insurance → vehicle owners in specific age/income ranges)

### 2. Load schema and build the query

- Call `get_schema` (two-step: summary, then `get_schema(database, table)` scoped to the table(s) you need — add `columns: [...]` for specific fields of wide tables) if not loaded; `get_query_instructions` is optional (full SQL reference only)
- Map the user's market definition to available columns and filter values
- Identify which databases and tables are needed

### 3. Size the total addressable market (TAM)

Open the analysis as an audience by calling `run_audience_query` first with the **Target market (TAM)** count. Use a descriptive `audience_title` like `"<Market description> — Market Sizing"`. This creates the audience and gives you the `audience_id` you'll reuse for every subsequent probe in this skill — there is no untracked SQL path.

**Target market (TAM)** — `run_audience_query` with all the user's demographic/firmographic/geographic filters as a COUNT
```sql
SELECT COUNT(*) AS tam FROM catalog.database.table WHERE [all filters]
```

**Total universe** — `execute_sql_query` (with the audience_id from above) — count all records in the relevant table(s) with no filters
```sql
SELECT COUNT(*) AS total_universe FROM catalog.database.table
```

**Reachable market** — `execute_sql_query` (with the same audience_id) — TAM filtered to records with phone OR email
```sql
-- Shape only — verify contact columns via get_schema first. In some schemas
-- phone/email live in separate join tables (e.g. consumer_phone /
-- consumer_email) rather than inline columns; in that case use the semi-join
-- pattern from the audience-building skill. Treat '' as NULL.
SELECT
  COUNT(*) AS reachable,
  COUNT(NULLIF(phone, '')) AS with_phone,
  COUNT(NULLIF(email, '')) AS with_email,
  ROUND(COUNT(NULLIF(phone, '')) * 100.0 / COUNT(*), 1) AS phone_pct,
  ROUND(COUNT(NULLIF(email, '')) * 100.0 / COUNT(*), 1) AS email_pct
FROM catalog.database.table WHERE [all filters]
```

### 4. Break down the opportunity

Run additional queries to segment the TAM. Continue using `execute_sql_query` with the same `audience_id`:

**Geographic breakdown:**
- By state (top 15), sorted by count
- If state-specific, by city or zip (top 20)
- Calculate each state's share of the total TAM

**Demographic/firmographic breakdown:**
- By age range (consumer) or employee count (B2B)
- By income bracket (consumer) or revenue tier (B2B)
- By homeowner status (consumer) or industry (B2B)

**Contact channel analysis:**
- Phone-only reachable count
- Email-only reachable count
- Both phone + email count
- Neither (unreachable) count

### 5. Build the market opportunity dashboard

Create a React (.jsx) visualization — this should be the centerpiece deliverable:

**Layout:**
- **Hero section**: Three big stat cards — Total Universe, Target Market (TAM), Reachable Market — with percentages showing the funnel
- **Market funnel**: A visual funnel or waterfall chart showing Universe → TAM → Reachable → Phone Reachable → Email Reachable
- **Geographic opportunity**: Horizontal bar chart of top states, with record counts and % of TAM
- **Segment breakdown**: Bar charts for the most relevant demographic/firmographic dimensions
- **Channel reachability**: Stacked bar or donut showing phone-only, email-only, both, neither
- **Footer**: Data source attribution, date, and filter summary

**Design:**
- Blue Contact brand colors from `${CLAUDE_PLUGIN_ROOT}/brand/brand.json` as primary (contactBlue #006AFF)
- Use a gradient or funnel metaphor to show the narrowing from universe to reachable
- Large, bold stat callouts for TAM and reachable numbers
- Include % penetration for each segment (segment count / TAM × 100)

**Persist to the audience:** The audience already exists (created in step 3) — attach the dashboard to its `audience_id`. Detect `artifact_type` from the source code:
```
save_artifact(
  audience_id: <the audience ID>,
  title: "<Market description> — Market Opportunity",
  source_code: <the complete source code>,
  artifact_type: <"react_dashboard" or "html">,
  metadata: { "generated_by": "market-sizing", "tam": <TAM count>, "reachable": <reachable count> }
)
```
Include the returned `share_url` in the findings presentation — stakeholders can open the dashboard without needing Cowork access.

### 6. Present the findings

Narrate the market size in business terms:
- "Your target market is X records nationally — that's Y% of the total consumer universe"
- "The top 5 states account for Z% of your TAM — [state list]"
- "You can reach A% by phone and B% by email, giving you C reachable prospects"
- Highlight where the opportunity is densest and where coverage is strongest

### 7. Offer next steps

- "Want to refine this into a full extraction (names + contact fields) for campaign execution?" (→ `run_audience_query` on the audience created in step 3)
- "Should I generate a report to share with your team?" (→ `audience-report` skill)
- "Want to see how this compares to a different market definition?" (→ `audience-compare` skill)
- "Shall we narrow this down to a specific state or metro area?"
- "Ready to break this into campaign-sized segments?"

## Framing Notes

- Always present numbers in context — raw counts are less meaningful without percentages and comparisons
- Use the funnel metaphor: Universe → TAM → Reachable. This tells a story
- If the TAM is very large (500K+), suggest segmentation strategies
- If the TAM is very small (<1K), suggest broadening criteria and show what loosening each filter would add
- If coverage is low (<30% phone or email), flag it proactively and suggest alternative channels
