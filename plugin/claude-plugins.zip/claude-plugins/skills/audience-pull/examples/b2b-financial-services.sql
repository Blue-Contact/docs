-- Example: B2B contacts at financial-services companies in a target geography
-- Pattern: SIC/NAICS industry filter + employee size + revenue band + geography + contact fields
-- Use this shape for: B2B SaaS prospecting, vendor outreach, partnerships
--
-- Substitute placeholders before running:
--   <STATE>           two-letter abbreviation, e.g., 'CA'
--   <EMP_MIN>         integer, e.g., 50
--   <EMP_MAX>         integer, e.g., 500
--   <REVENUE_MIN>     integer, e.g., 10000000  (= $10M)
--   <b2b_db>          the B2B database name from get_schema
--   <catalog>         datasource for the B2B database
--
-- The SIC codes 6020–6029 cover commercial banks; 6311 covers life insurance;
-- 6411 covers insurance agents/brokers; adjust as needed. Always verify codes
-- against the schema's prompt_guidance for the industry column.

SELECT
  c.first_name,
  c.last_name,
  c.title,
  c.email,
  c.phone,
  co.company_name,
  co.address_line_1,
  co.city,
  co.state,
  co.zip,
  co.employee_count,
  co.annual_revenue,
  co.sic_code
FROM <catalog>.<b2b_db>.contacts c
JOIN <catalog>.<b2b_db>.companies co ON c.company_id = co.company_id
WHERE co.state = '<STATE>'
  AND co.sic_code IN ('6020', '6021', '6022', '6311', '6411')
  AND co.employee_count BETWEEN <EMP_MIN> AND <EMP_MAX>
  AND co.annual_revenue >= <REVENUE_MIN>
  AND c.email IS NOT NULL
ORDER BY co.annual_revenue DESC, co.company_name
LIMIT 25000
