-- Example: Recent movers into a target destination
-- Pattern: destination geography + recency window + mover-type filter + contact fields
-- Use this shape for: moving services, home services prospecting, retail welcome campaigns,
-- utility/services onboarding
--
-- Substitute placeholders before running:
--   <DEST_STATE>      two-letter abbreviation, e.g., 'NC'
--   <DEST_CITY>       optional; remove the city clause if filtering only by state
--   <WINDOW_DAYS>     recency window (e.g., 90 for last 90 days)
--   <MOVER_TYPE>      'F' (family), 'I' (individual), or remove the clause for both
--   <mover_db>        the mover database name from get_schema
--   <catalog>         datasource for the mover database
--
-- Coverage tip: mover records often have higher phone coverage than email;
-- check both rates in a separate count query before committing to an output format.

SELECT
  first_name,
  last_name,
  destination_address_line_1 AS address_line_1,
  destination_city AS city,
  destination_state AS state,
  destination_zip AS zip,
  origin_state,
  origin_city,
  move_date,
  mover_type,
  phone,
  email
FROM <catalog>.<mover_db>.movers
WHERE destination_state = '<DEST_STATE>'
  AND destination_city = '<DEST_CITY>'
  AND move_date >= DATE_ADD('day', -<WINDOW_DAYS>, CURRENT_DATE)
  AND mover_type = '<MOVER_TYPE>'
ORDER BY move_date DESC, destination_zip
LIMIT 100000
