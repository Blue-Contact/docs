-- Example: Consumer homeowners in a target metro
-- Pattern: state + city + age band + homeowner status + contact fields
-- Use this shape for: real estate, home services, insurance, financial services
--
-- Substitute placeholders before running:
--   <CITY>          e.g., 'Austin'
--   <STATE>         two-letter abbreviation, e.g., 'TX'
--   <AGE_MIN>       e.g., 30
--   <AGE_MAX>       e.g., 55
--   <INCOME_MIN>    integer, e.g., 75000
--   <consumer_db>   the consumer database name from get_schema
--   <catalog>       the consumer database's datasource value (typically AwsDataCatalog)

SELECT
  first_name,
  last_name,
  address_line_1,
  city,
  state,
  zip,
  phone,
  email,
  age,
  income,
  homeowner_status
FROM <catalog>.<consumer_db>.individual
WHERE state = '<STATE>'
  AND city = '<CITY>'
  AND age BETWEEN <AGE_MIN> AND <AGE_MAX>
  AND income >= <INCOME_MIN>
  AND homeowner_status = 'H'   -- option value for homeowner; verify against schema
  AND phone IS NOT NULL
  AND email IS NOT NULL
ORDER BY zip, last_name
LIMIT 50000
