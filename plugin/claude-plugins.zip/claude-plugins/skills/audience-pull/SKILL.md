---
name: audience-pull
description: Slash-command entry point for a quick audience build — a compressed version of the audience-building workflow for when the user gives a one-line audience description and wants the list, not a walkthrough
argument-hint: "description of target audience"
allowed-tools:
  - mcp__blue-contact__get_schema
  - mcp__blue-contact__get_query_instructions
  - mcp__blue-contact__validate_sql
  - mcp__blue-contact__run_audience_query
  - mcp__blue-contact__execute_sql_query
  - mcp__blue-contact__get_audience_run
  - mcp__blue-contact__save_message
  - AskUserQuestion
---

# /blue-contact:audience-pull

The user wants to build a targeted audience. Follow the audience-building workflow:

> **Async note.** `run_audience_query` and `execute_sql_query` return a kick-off (`{status: "queued", run_id, ...}` with no rows). After every kick-off, poll `get_audience_run` with the returned `run_id` every 2–5 seconds until `status: "completed"` — that response carries `rows`, `columns`, `coverage_summary`, and `download_url`. Full pattern: `${CLAUDE_PLUGIN_ROOT}/skills/audience-building/SKILL.md` → "Polling for results". Every step below that mentions one of those tools implies this poll loop.

Worked SQL examples for common shapes live in `examples/` next to this skill (`consumer-homeowners.sql`, `b2b-financial-services.sql`, `recent-movers-by-destination.sql`) — load the matching one as a starting shape when the request fits, substituting schema-verified names.

1. Parse the user's description of their target audience
2. Call `get_schema` (no params for summary, then scope the column-level call with `get_schema(database, table)` — add `columns: [...]` for specific fields of wide tables; avoid whole-database calls on large databases) if not already loaded; skip `get_query_instructions` unless you need the platform's full SQL reference — the tool descriptions carry the essentials
3. Clarify any ambiguities (geography, demographics, data type, output fields)
4. **Open the audience with a COUNT.** Call `run_audience_query` with a `SELECT COUNT(*) FROM ... WHERE [filters]` query, plus `reasoning`, `user_prompt`, and `audience_title`. This creates the audience and tags the run as a count (billing-tracked, but not a data extraction). Capture the returned `audience_id` — every subsequent SQL call must reference it.
5. Check contact coverage (phone/email append rates) via `execute_sql_query` using the `audience_id` from step 4. Probes are recorded as ad-hoc messages on the audience without overwriting its canonical SQL.
6. **Refine to the data extraction.** Call `run_audience_query` again with the same `audience_id` and the final SELECT. This becomes the audience's canonical SQL (a new `audience_version` is recorded) and the run is billable as `data_extraction`. The response includes a `coverage_summary` so a separate coverage probe in step 5 is optional when you plan to extract anyway.
7. Present a summary report with record count, coverage rates, and key breakdowns
8. **After the user confirms this is the audience they want** (e.g., they express satisfaction, ask to download, or move to next steps), prompt them using AskUserQuestion with two options:
   - **"Save & share for QA"** — "Save the exact logic behind this audience as a shareable doc your team can QA — they can check the filters, flag changes, and send it back to update the query."
   - **"Skip for now"** — "You can always generate one later with /blue-contact:audience-logic-report"
   
   This triggers the `audience-logic-report` skill if accepted.
