---
name: audience-pull
description: Build a targeted data audience from Blue Contact
argument-hint: "description of target audience"
allowed-tools:
  - blue-contact:get_schema
  - blue-contact:get_query_instructions
  - blue-contact:validate_sql
  - blue-contact:run_audience_query
  - blue-contact:execute_sql_query
  - blue-contact:create_audience
  - blue-contact:save_message
---

# /blue-contact:audience-pull

The user wants to build a targeted audience. Follow the audience-building workflow:

1. Parse the user's description of their target audience
2. Call `get_query_instructions` and `get_schema` (no params for summary, then with `database` param for full schema) if not already loaded
3. Clarify any ambiguities (geography, demographics, data type, output fields)
4. **Open the audience with a COUNT.** Call `run_audience_query` with a `SELECT COUNT(*) FROM ... WHERE [filters]` query, plus `reasoning`, `user_prompt`, and `audience_title`. This creates the audience and tags the run as a non-billable count. Capture the returned `audience_id` — every subsequent SQL call must reference it.
5. Check contact coverage (phone/email append rates) via `execute_sql_query` using the `audience_id` from step 4. Probes are recorded as ad-hoc messages on the audience without overwriting its canonical SQL.
6. **Refine to the data extraction.** Call `run_audience_query` again with the same `audience_id` and the final SELECT. This becomes the audience's canonical SQL (a new `audience_version` is recorded) and the run is billable as `data_extraction`. The response includes a `coverage_summary` so a separate coverage probe in step 5 is optional when you plan to extract anyway.
7. Present a summary report with record count, coverage rates, and key breakdowns
8. **After the user confirms this is the audience they want** (e.g., they express satisfaction, ask to download, or move to next steps), prompt them using AskUserQuestion with two options:
   - **"Save & share for QA"** — "Save the exact logic behind this audience as a shareable doc your team can QA — they can check the filters, flag changes, and send it back to update the query."
   - **"Skip for now"** — "You can always generate one later with /blue-contact:audience-logic-report"
   
   This triggers the `audience-logic-report` skill if accepted.
