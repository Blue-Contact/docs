---
name: industry-playbooks
description: Pre-built audience recipes for specific verticals — real estate, automotive, insurance, home services, financial services, and more. Pick your industry and get a tailored audience in minutes.
---

# Industry Playbooks

Guided audience-building templates tailored to specific verticals. Each playbook lives in its own reference file under `references/` and is loaded only when selected — keeping the loaded skill footprint small.

## Brand Configuration

Read `brand/BRAND.md` and load color tokens from `brand/brand.json` before any visual output. Every visual artifact must include the Blue Contact icon (`brand/logos/icon-gradient.svg`) or, for headers, the horizontal logo (`brand/logos/horizontal-gradient.svg`). See `brand/BRAND.md` for placement guidance.

## Workflow

### 1. Confirm prerequisites

Call `get_schema` (no params) if not already loaded. Build the menu in step 2 from the user's actual `category` set — only show playbooks whose required data sources are present.

### 2. Select an industry

Use `AskUserQuestion` to present available playbooks. The "required categories" column tells you whether the option should be included for this user:

| Playbook | Required categories | Description |
|---|---|---|
| **Real Estate** | `consumer` + `property` (+ `mover` for buyer flows) | Target homeowners, recent movers, or properties by type/value/age. Great for agents, brokerages, property services. |
| **Automotive** | `consumer` + `dealership` | Reach consumers near dealerships, target by demographics and geography. |
| **Insurance** | `consumer` + `property` | Homeowners, age/income segments, property values. Build prospect lists for home, auto, or life insurance. |
| **Home Services** | `consumer` + `property` | Target by property age, type, value, and homeowner status. Ideal for HVAC, roofing, plumbing, landscaping. |
| **Financial Services** | `consumer` (+ `property` for equity flows) | Income-based targeting, retirement/wealth segments, homeowner equity prospects. |
| **Healthcare / Wellness** | `consumer` | Age and demographic targeting for health-related services, geographic radius targeting. |
| **Moving Services** | `mover` + `consumer` | Recent movers by origin/destination, mover type, timing. |
| **Retail / E-commerce** | `consumer` | Demographic and geographic targeting for store locations or direct mail campaigns. |

### 3. Load the playbook reference

For the selected vertical, load **only** the matching reference file at `references/<lowercased-with-hyphens>.md` (e.g., "Real Estate" → `references/real-estate.md`). Each reference specifies the best data sources, the questions to ask, the default output fields, sample queries, and the recommended visualization. Healthcare/Wellness and Retail/E-commerce don't have dedicated references — use the generic execution flow below with consumer-only filters.

### 4. Execute the playbook

Once the reference is loaded:

1. Load the full schema for the playbook's required databases via `get_schema(database: "...")`.
2. Ask the playbook-specific questions using `AskUserQuestion`.
3. Build the SQL query using the playbook's default fields and the user's answers.
4. Run a `COUNT` estimate first via `execute_sql_query`.
5. Check contact coverage (phone/email rates).
6. If the count looks good, build the audience with `run_audience_query`.
7. Create the industry-specific visualization dashboard (.jsx) per the reference.
8. Present results with the visualization and a conversational summary.
9. Offer next steps: refine, generate report, compare to another segment, size the broader market.

### 5. Cross-sell other skills

After the audience is built, mention relevant next steps:

- "Want a polished report to share with your team?" → `audience-report`
- "Curious how this compares to a different geography?" → `audience-compare`
- "Want to see the total market size before narrowing down?" → `market-sizing`
