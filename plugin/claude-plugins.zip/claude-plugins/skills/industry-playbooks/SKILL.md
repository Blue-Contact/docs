---
name: industry-playbooks
description: Pre-built audience recipes for specific verticals — real estate, automotive, insurance, home services, financial services, and more. Pick your industry and get a tailored audience in minutes.
---

# Industry Playbooks

Guided audience-building templates tailored to specific verticals. Each playbook lives in its own reference file under `references/` and is loaded only when selected — keeping the loaded skill footprint small.

## Brand Configuration

Read `${CLAUDE_PLUGIN_ROOT}/brand/BRAND.md` and load color tokens from `${CLAUDE_PLUGIN_ROOT}/brand/brand.json` before any visual output (the `brand/` directory lives at the plugin root, not the session working directory). Every visual artifact must include the Blue Contact icon (`${CLAUDE_PLUGIN_ROOT}/brand/logos/icon-gradient.svg`) or, for headers, the horizontal logo (`${CLAUDE_PLUGIN_ROOT}/brand/logos/horizontal-gradient.svg`). See `${CLAUDE_PLUGIN_ROOT}/brand/BRAND.md` for placement guidance. If the brand files cannot be read, fall back to: contactBlue `#006AFF`, graphite `#2A3A57`, clearSky `#334669`, seafoam `#12C7B4`, eggshell `#E4E9F5`, gradient `linear-gradient(135deg, #1A94FF 0%, #006AFF 100%)`, footer attribution "Data provided by Blue Contact" — never ship an unbranded artifact.

## Workflow

### 1. Confirm prerequisites

Call `get_schema` (no params) if not already loaded. Build the menu in step 2 from the user's actual `category` set — only show playbooks whose required data sources are present.

### 2. Select an industry

Use `AskUserQuestion` to present available playbooks. The "required categories" column tells you whether the option should be included for this user:

| Playbook | Required categories | Description |
|---|---|---|
| **Real Estate** | `consumer` + `property` (+ `mover` for buyer flows) | Target homeowners, recent movers, or properties by type/value/age. Great for agents, brokerages, property services. |
| **Automotive** | `consumer` + `dealership` | Reach consumers near dealerships, target by demographics and geography. |
| **Insurance** | `consumer` + `property` | Homeowners, age/income segments, property values. Build prospect lists for home, auto, or life insurance. |
| **Home Services** | `consumer` + `property` | Target by property age, type, value, and homeowner status. Ideal for HVAC, roofing, plumbing, landscaping. |
| **Financial Services** | `consumer` (+ `property` for equity flows) | Income-based targeting, retirement/wealth segments, homeowner equity prospects. |
| **Healthcare / Wellness** | `consumer` | Age and demographic targeting for health-related services, geographic radius targeting. |
| **Moving Services** | `mover` + `consumer` | Recent movers by origin/destination, mover type, timing. |
| **Retail / E-commerce** | `consumer` | Demographic and geographic targeting for store locations or direct mail campaigns. |

### 3. Load the playbook reference

For the selected vertical, load **only** the matching reference file at `references/<lowercased-with-hyphens>.md` (e.g., "Real Estate" → `references/real-estate.md`). Each reference specifies the best data sources, the questions to ask, the default output fields, sample queries, and the recommended visualization. Healthcare/Wellness and Retail/E-commerce don't have dedicated references — use the generic execution flow below with consumer-only filters.

### 4. Execute the playbook

Once the reference is loaded:

1. Load the schema for the playbook's required tables via `get_schema(database: "...", table: "...")` — scope to the tables the playbook uses (add `columns: [...]` for specific fields of wide tables) rather than pulling whole databases.
2. Ask the playbook-specific questions using `AskUserQuestion`.
3. **Check for a precedent** before writing SQL: call `find_similar_audiences(prompt: <the playbook request in the user's own terms>)`. Playbooks get run repeatedly, often by different people on the same account — if a match comes back `exact` or `strong` (`reusable: true`), `validate_sql` its `sql` and reuse it verbatim, saying whose it was and when it ran. A `related` match (`reusable: false`) is a different question; read its `prompt` and judge. Detail: `${CLAUDE_PLUGIN_ROOT}/skills/audience-building/SKILL.md` → step 1.
4. Build the SQL query using the playbook's default fields and the user's answers.
5. Open the audience with a `COUNT` via `run_audience_query` (pass `sql`, `reasoning`, `user_prompt`, and a playbook-derived `audience_title`). Capture the returned `audience_id`.
6. Check contact coverage via `execute_sql_query` using the `audience_id` from step 5. (Optional — `run_audience_query` returns a `coverage_summary` once you refine to the data extraction.)
7. If the count looks good, refine by calling `run_audience_query` again with the same `audience_id` and the final SELECT.
8. Create the industry-specific visualization dashboard (.jsx) per the reference.
9. Present results with the visualization and a conversational summary.
10. Offer next steps: refine, generate report, compare to another segment, size the broader market.

### 5. Cross-sell other skills

After the audience is built, mention relevant next steps:

- "Want a polished report to share with your team?" → `audience-report`
- "Curious how this compares to a different geography?" → `audience-compare`
- "Want to see the total market size before narrowing down?" → `market-sizing`
