# Real Estate Playbook

**Best data sources**: Consumer + Property + Mover

## Ask the user

- What's your focus? (Sellers: target long-tenure homeowners; Buyers: target renters or recent movers; Investors: target multi-family properties)
- Geographic focus? (State, city, zip, or radius around an area)
- Property value range? (Helps match listings to prospects)
- Any age or income preferences?

## Default output fields

Name, address, phone, email, homeowner status, property type, property value, year built, length of residence, age, income.

## Sample queries

- Likely sellers: Homeowners in [area] with property owned 10+ years, property value $200K–$500K
- Likely buyers: Renters aged 25–45 with income $75K+ in [area]
- Recent movers into area: Movers with destination in [zip/city] in last 6 months

## Visualization

Property value distribution + geographic heat map + homeowner tenure chart.
