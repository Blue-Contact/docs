# Home Services Playbook

**Best data sources**: Consumer + Property

## Ask the user

- What service? (HVAC, roofing, plumbing, landscaping, remodeling, solar)
- Geographic service area?
- Property age preference? (Older homes = more service needs)
- Homeowner income range? (Ability to pay)

## Default output fields

Name, address, phone, email, homeowner status, property type, property value, year built, square footage, lot size, age, income.

## Sample queries

- Roofing leads: Homeowners with property built before 1995, value $150K+, in [area]
- HVAC prospects: Homeowners with property built before 2000, square footage 1500+, in [area]
- Remodeling: Homeowners with property 20+ years old, income $75K+, property value $200K–$400K

## Visualization

Property age distribution + value ranges + geographic density + homeowner income profile.
