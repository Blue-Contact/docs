# Automotive Playbook

**Best data sources**: Consumer + Dealership

## Ask the user

- What's the goal? (Service marketing, new vehicle sales, conquest campaigns)
- Which makes/brands? (Match to dealership inventory)
- Geographic radius around dealership(s)?
- Any demographic targeting? (Age, income, family status)

## Default output fields

Name, address, phone, email, age, income, gender, presence of children, distance to nearest dealer.

## Sample queries

- Service conquest: Consumers within 15-mile radius of [dealer], age 25–65, income $50K+
- New car buyers: Consumers near [make] dealerships, age 30–55, income $75K+, homeowners

## Visualization

Consumer density around dealership locations + age/income distribution + coverage rates.
