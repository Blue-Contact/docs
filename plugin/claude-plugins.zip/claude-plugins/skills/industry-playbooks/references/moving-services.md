# Moving Services Playbook

**Best data sources**: Mover + Consumer

## Ask the user

- Inbound or outbound movers? (Or both)
- Geographic focus? (Destination state/city for inbound; origin for outbound)
- Time window? (Last 30 days, 90 days, 6 months?)
- Mover type? (Individual, family)

## Default output fields

Name, address, phone, email, origin address, destination address, move date, mover type.

## Sample queries

- Inbound movers: People who moved to [state/city] in the last 90 days
- Outbound movers: People leaving [state/city] in the last 90 days
- Family movers: Family-type movers into [area] in last 6 months

## Visualization

Monthly mover volume trend + top origin/destination states + mover type breakdown.
