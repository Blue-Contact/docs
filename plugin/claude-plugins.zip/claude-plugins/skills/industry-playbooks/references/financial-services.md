# Financial Services Playbook

**Best data sources**: Consumer + Property

## Ask the user

- What product? (Wealth management, retirement planning, lending, credit cards)
- Income threshold?
- Age range?
- Geographic focus?
- Homeowner preference? (Equity = asset indicator)

## Default output fields

Name, address, phone, email, age, income, homeowner status, property value, marital status, presence of children.

## Sample queries

- Wealth management: Consumers aged 45–70, income $150K+, homeowners with property value $400K+
- Retirement planning: Consumers aged 55–70, income $75K+, homeowners
- First-time mortgage: Renters aged 25–40, income $60K+, in [area]

## Visualization

Income distribution + age segments + homeowner equity profile + geographic opportunity.
