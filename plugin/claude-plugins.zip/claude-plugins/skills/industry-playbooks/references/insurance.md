# Insurance Playbook

**Best data sources**: Consumer + Property

## Ask the user

- Insurance type? (Home, auto, life, umbrella)
- Geographic focus?
- Property value or income thresholds?
- Age range for the target segment?

## Default output fields

Name, address, phone, email, age, income, homeowner status, property type, property value, marital status, presence of children.

## Sample queries

- Home insurance: Homeowners in [state] with property value $150K–$750K, age 30–65
- Life insurance: Consumers aged 25–55 with income $60K+, presence of children
- High-value umbrella: Homeowners with property value $500K+, income $150K+

## Visualization

Property value tiers + age distribution + income brackets + coverage funnel.
