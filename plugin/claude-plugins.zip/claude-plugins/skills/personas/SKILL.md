---
name: personas
description: Segment any Blue Contact audience or uploaded list into data-driven personas (clustering + persona narratives), inspect and iterate the segmentation, and score prospect universes against it — activates when a user asks for personas, segments, clusters, lookalikes, or propensity scoring
allowed-tools:
  - mcp__blue-contact__get_table
  - mcp__blue-contact__list_tables
  - mcp__blue-contact__create_dataset_from_query
  - mcp__blue-contact__get_dataset
  - mcp__blue-contact__get_dataset_preview
  - mcp__blue-contact__kickoff_profiling
  - mcp__blue-contact__iterate_profiling
  - mcp__blue-contact__get_profiling_status
  - mcp__blue-contact__list_profiling_jobs
  - mcp__blue-contact__get_profiling_artifacts
  - mcp__blue-contact__get_persona_details
  - mcp__blue-contact__kickoff_scoring
  - mcp__blue-contact__get_scoring_status
  - mcp__blue-contact__get_scoring_results
  - mcp__blue-contact__get_run_status
  - mcp__blue-contact__get_audience
  - mcp__blue-contact__list_audiences
  - mcp__blue-contact__get_schema
  - mcp__blue-contact__save_message
  - mcp__blue-contact__save_artifact
  - AskUserQuestion
  - Read
  - Write
---

# Personas — Profiling, Segmentation, and Scoring

Blue Contact's profiling pipeline turns a list of people into named personas: K-means clustering over library attributes, LightGBM modeling for feature importance and lift, and generated persona narratives with charts and images. A completed profiling run can then **score** any other table (a prospect universe, a lead file) for similarity/propensity. This skill covers the whole arc: source → profile → inspect → iterate → score.

## The pipeline at a glance

1. **Source a dataset** the profiler can run on.
2. **Profile it** — `kickoff_profiling` (a managed job, minutes-long).
3. **Read the results** — `get_profiling_artifacts` + `get_persona_details`.
4. **Iterate** if needed — `iterate_profiling` creates a new run alongside for comparison.
5. **Score a universe** against the personas — `kickoff_scoring` → `get_scoring_results`.

## 1. Source a dataset

Profiling runs on a **dataset**.

**If the source is already an owned table** (an upload or match output from the `my-data` skill), the dataset already exists: `get_table(table_id)` returns its `dataset_id` — use that directly in the profiling/scoring tools below. No `create_dataset_from_query` needed.

**Otherwise**, create one with `create_dataset_from_query`, which accepts exactly one of:

- `audience_id` — profiles an existing audience's latest SQL (the common case: "build personas from my audience"). Find the id via `list_audiences`/`get_audience` if the user names an audience.
- `sql` + `table_name` — arbitrary guarded SELECT, materialized via CTAS.
- `existing_table: "database.table"` — an existing Glue table the platform doesn't already own.

Add `people_description` (who's in the data) and `report_audience` (who reads the report) — these steer narrative generation. Pass `auto_profile: true` to skip step 2 and launch profiling immediately; when using it, provide the business context in `people_description` up front.

Datasets created this way are born `ready` and **cannot run a match job** — matching an upload belongs to the `my-data` skill (`run_data_job(job_type: "match")`), never SQL.

If the user's list isn't in the platform yet, hand off to `my-data` to upload (and usually match) it first — personas cluster on library attributes, so an unmatched raw upload has little to cluster on.

## 2. Kick off profiling

```
kickoff_profiling(
  dataset_id: <id>,
  business_details: "<who is in this audience and what the business objective is>"
)
```

`business_details` matters — it drives persona naming and narratives. Compose it from the user's own words; ask one clarifying question if you'd otherwise be guessing the objective.

Optional tuning (also available later via `iterate_profiling`): `arg_overrides` keys like `GEO_SAMPLE_ENABLED`/`GEO_SAMPLE_LEVEL` (geographic sampling), `FEATURE_INCLUDE_COLS`/`FEATURE_EXCLUDE_COLS`, `HOLDOUT_TEST_SIZE`, `LIFT_DECILES`, `RUN_LABEL`. Bring-your-own-universe: `universe_db` + `universe_table`, which **require** `arg_overrides.UNIVERSE_EST_ROWS`. Defaults are right for a first run — don't tune speculatively.

**Checking status:** profiling is a managed Glue job — **minutes, not seconds**. Check `get_profiling_status(dataset_run_id)` (or `get_run_status` with `run_type: "profiling"`); the response includes elapsed time, an ETA, and a `message` with explicit handling guidance — follow it. The standard rhythm is: kick off, **share the ETA with the user, and end your turn** — check again when they ask or when you're back for other work; don't sleep-poll in a loop. On `failed`, report the error context; don't auto-relaunch.

## 3. Read the results

- `get_profiling_artifacts(dataset_id)` — auto-resolves the latest successful run and returns the full picture: overall audience persona, named cluster personas with descriptions, cluster size summary, feature-importance and attribute-distribution chart URLs, and lift analysis. (Artifacts are addressed by `agency`/`client`/`job_folder` under the hood; `list_profiling_jobs` navigates that hierarchy when you need a *specific* older run.)
- `get_persona_details(agency, client, job_folder, cluster_id)` — drill into one persona: full description, attribute charts (paginated via `attr_chart_limit`/`attr_chart_offset`), feature importance, and the persona image. `cluster_id: "overall"` for the whole-audience persona. Take `agency`/`client`/`job_folder` from the artifacts response.

**Presenting personas:** lead with the story, not the mechanics — persona names, one-line essences, relative sizes, and the 2–3 attributes that most distinguish each cluster (from feature importance / lift). Chart and image URLs can be embedded in dashboards or reports; for a brand-styled deliverable, follow the `audience-report` skill's visual conventions. If the source was an audience, `save_message` a short summary (and `save_artifact` any dashboard) to that audience so the personas live with it.

## 4. Iterate

`iterate_profiling(dataset_id, run_label: "<what changed>", arg_overrides: {...})` re-runs with adjusted parameters as a **new run alongside** the old one — nothing is overwritten. Typical iterations: exclude a dominating feature (`FEATURE_EXCLUDE_COLS`), enable geo sampling for nationally-skewed data, or change the universe. Always set `run_label` so runs are distinguishable, then compare via `get_profiling_artifacts` per run.

## 5. Score a universe

Once a profiling run has succeeded, score any table for cluster assignment + propensity:

```
kickoff_scoring(
  dataset_id: <profiled dataset>,
  source_db: "<db>", source_table: "<table to score>",
  output_db: "<db>", output_table: "<scored output>"
)
```

Confirm the source and output locations with the user before launching — scoring writes a new table. Check `get_scoring_status` (same share-the-ETA-and-end-turn rhythm as profiling), then `get_scoring_results(dataset_run_id)` for row counts, the score distribution, and top-scored samples. Present the distribution (a decile/histogram chart works well) and offer to build an audience from the high scorers.

## Ground rules

- Profiling and scoring are **billing-visible managed jobs** — tell the user what you're launching and roughly how long it takes before kicking it off.
- One clarifying pass, then act: source + business objective are the two things worth confirming. Everything else has good defaults.
- Never fabricate persona content. Names, narratives, and stats come from the artifacts; your job is selection and presentation.
- Fill rates and data-quality questions about the source table: `read_profiling_stats` via the `my-data`/`data-querying` guidance, not SQL COUNTs.
