---
name: personas
description: Segment any Blue Contact audience or uploaded list into data-driven personas (clustering + persona narratives), inspect and iterate the segmentation, and score prospect universes against it — activates when a user asks for personas, segments, clusters, lookalikes, or propensity scoring
allowed-tools:
  - mcp__blue-contact__get_table
  - mcp__blue-contact__list_tables
  - mcp__blue-contact__get_table_preview
  - mcp__blue-contact__create_table_from_query
  - mcp__blue-contact__run_data_job
  - mcp__blue-contact__iterate_profiling
  - mcp__blue-contact__get_profiling_status
  - mcp__blue-contact__list_profiling_jobs
  - mcp__blue-contact__get_profiling_artifacts
  - mcp__blue-contact__get_persona_details
  - mcp__blue-contact__get_scoring_status
  - mcp__blue-contact__get_scoring_results
  - mcp__blue-contact__get_run_status
  - mcp__blue-contact__read_profiling_stats
  - mcp__blue-contact__get_audience
  - mcp__blue-contact__list_audiences
  - mcp__blue-contact__get_schema
  - mcp__blue-contact__save_message
  - mcp__blue-contact__save_artifact
  - AskUserQuestion
  - Read
  - Write
---

# Personas — Profiling, Segmentation, and Scoring

Blue Contact's profiling pipeline turns a list of people into named personas: K-means clustering over library attributes, LightGBM modeling for feature importance and lift, and generated persona narratives with charts and images. A completed profiling run can then **score** any other table (a prospect universe, a lead file) for similarity/propensity. This skill covers the whole arc: source → profile → inspect → iterate → score.

## Everything is addressed by `table_id`

Profiling, scoring, and their status pollers all run on an **owned table**, identified by its `table_id`. Runs are identified by `data_job_id` (returned by `run_data_job`). There is no separate dataset object and no `dataset_id` — the old dataset tools (`create_dataset_from_query`, `kickoff_profiling`, `kickoff_scoring`, `get_dataset`, …) have been **removed from the server**; calling them fails. If a user hands you an old `dataset_id` from a previous session, find the table instead via `list_tables`.

## The pipeline at a glance

1. **Source a table** the profiler can run on.
2. **Profile it** — `run_data_job(job_type: "segment", table_id: ...)` (a managed job, minutes-long).
3. **Read the results** — `get_profiling_artifacts` + `get_persona_details`.
4. **Iterate** if needed — `iterate_profiling` creates a new run alongside for comparison.
5. **Score a universe** against the personas — `run_data_job(job_type: "score", ...)` → `get_scoring_results`.

## 1. Source a table

**If the source is already an owned table** (an upload or match output from the `my-data` skill), you're done — use its `table_id` directly. `list_tables` finds it; `get_table(table_id)` confirms `status: "ready"` and shows the `profiling` block and `recent_jobs`.

**Otherwise**, materialize one with `create_table_from_query`, which accepts exactly one of:

- `audience_id` + `table_name` — materializes an existing audience's latest SQL (the common case: "build personas from my audience"). Find the id via `list_audiences`/`get_audience` if the user names an audience.
- `sql` + `table_name` — arbitrary guarded SELECT, materialized via CTAS.
- `existing_table: "database.table"` — reference an existing Glue table the platform doesn't already own.

Add `people_description` (who's in the data) and `report_audience` (who reads the report) — these steer narrative generation. Pass `auto_profile: true` to skip step 2 and launch segmentation immediately; when using it, provide the business context in `people_description` up front. CTAS tables expire by default (30 days for MCP) — surface the expiry from the response.

`run_data_job` can also target a table you can see in `get_schema` but don't own — pass `database_name` + `table_name` (plus `datasource` if the name is ambiguous) instead of `table_id`. That is the only way to address a read-only library table, which has no `table_id`.

If the user's list isn't in the platform yet, hand off to `my-data` to upload (and usually match) it first — personas cluster on library attributes, so an unmatched raw upload has little to cluster on.

## 2. Kick off segmentation

```
run_data_job(
  job_type: "segment",
  table_id: <id>,
  business_details: "<who is in this audience and what the business objective is>"
)
```

`business_details` matters — it drives persona naming and narratives. Compose it from the user's own words; ask one clarifying question if you'd otherwise be guessing the objective.

Optional tuning via `arg_overrides` (the same keys `iterate_profiling` accepts): `GEO_SAMPLE_ENABLED`/`GEO_SAMPLE_LEVEL` (geographic sampling), `FEATURE_INCLUDE_COLS`/`FEATURE_EXCLUDE_COLS`, `HOLDOUT_TEST_SIZE`, `HOLDOUT_RANDOM_STATE`, `LIFT_DECILES`, `RUN_LABEL`. Bring-your-own-universe: `universe_db` + `universe_table`, which **require** `arg_overrides.UNIVERSE_EST_ROWS`. Defaults are right for a first run — don't tune speculatively.

**Checking status:** segmentation is a managed Glue job — **minutes, not seconds**. Check `get_profiling_status(data_job_id: ...)` — or `table_id` for that table's most recent run, or `get_run_status(data_job_id | table_id, run_type: "profiling")`. The response includes elapsed time, an ETA, and a `message` with explicit handling guidance — follow it. The standard rhythm is: kick off, **share the ETA with the user, and end your turn** — check again when they ask or when you're back for other work; don't sleep-poll in a loop. On `failed`, report the error context; don't auto-relaunch.

## 3. Read the results

- `get_profiling_artifacts(table_id)` — auto-resolves that table's latest successful run and returns the full picture: overall audience persona, named cluster personas with descriptions, cluster size summary, feature-importance and attribute-distribution chart URLs, and lift analysis. (Artifacts are addressed by `agency`/`client`/`job_folder` under the hood; pass those explicitly, with `list_profiling_jobs` navigating the hierarchy, when you need a *specific* older run.)
- `get_persona_details(agency, client, job_folder, cluster_id)` — drill into one persona: full description, attribute charts (paginated via `attr_chart_limit`/`attr_chart_offset`), feature importance, and the persona image. All four arguments are required; take `agency`/`client`/`job_folder` from the artifacts response. `cluster_id: "overall"` (or `"-1"`) for the whole-audience persona.

**Presenting personas:** lead with the story, not the mechanics — persona names, one-line essences, relative sizes, and the 2–3 attributes that most distinguish each cluster (from feature importance / lift). Chart and image URLs can be embedded in dashboards or reports; for a brand-styled deliverable, follow the `audience-report` skill's visual conventions. If the source was an audience, `save_message` a short summary (and `save_artifact` any dashboard) to that audience so the personas live with it.

## 4. Iterate

`iterate_profiling(table_id, run_label: "<what changed>", arg_overrides: {...})` re-runs with adjusted parameters as a **new run alongside** the old one — nothing is overwritten. `table_id` is required; `business_details` is optional and defaults to the most recent run's. Typical iterations: exclude a dominating feature (`FEATURE_EXCLUDE_COLS`), enable geo sampling for nationally-skewed data, or change the universe. Always set `run_label` so runs are distinguishable, then compare via `get_profiling_artifacts` per run.

## 5. Score a universe

Once a segmentation run has succeeded, score any table for cluster assignment + propensity:

```
run_data_job(
  job_type: "score",
  table_id: <the profiled table>,
  source_db: "<db>", source_table: "<table to score>",
  output_db: "<db>", output_table: "<scored output>"
)
```

Confirm the source and output locations with the user before launching — scoring writes a new table. Optional `scoring_options` carries overrides. Check `get_scoring_status(data_job_id: ...)` (or `table_id` for the latest scoring run — same share-the-ETA-and-end-turn rhythm as segmentation), then `get_scoring_results(data_job_id, sample_limit: <1-100>)` for row counts, the score distribution, and top-scored samples. Present the distribution (a decile/histogram chart works well) and offer to build an audience from the high scorers.

## Ground rules

- Segmentation and scoring are **billing-visible managed jobs** — tell the user what you're launching and roughly how long it takes before kicking it off.
- One clarifying pass, then act: source + business objective are the two things worth confirming. Everything else has good defaults.
- Never fabricate persona content. Names, narratives, and stats come from the artifacts; your job is selection and presentation.
- Fill rates and data-quality questions about the source table: `read_profiling_stats(table_id)`, not SQL COUNTs.
