import { useState } from "react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Cell, LabelList
} from "recharts";

const BRAND = {
  contactBlue: "#006AFF",
  graphite: "#2A3A57",
  clearSky: "#334669",
  seafoam: "#12C7B4",
  eggshell: "#E4E9F5",
  danger: "#DB4646",
  hazard: "#FF9A1F",
  white: "#FFFFFF",
  success: "#00C864",
};

const funnelData = [
  { step: "Universe\n(All Movers)",    remaining: 23851891, dropped: 0,        pctDrop: null,  filterDesc: "All mover records in the database" },
  { step: "Recency\n(June 2025+)",     remaining: 6719773,  dropped: 17132118, pctDrop: 71.8,  filterDesc: "date_processed >= '20250601'" },
  { step: "Age\n(25+)",                remaining: 1989079,  dropped: 4730694,  pctDrop: 70.4,  filterDesc: "CAST(age AS INTEGER) >= 25" },
  { step: "Contact\n(Phone or Email)", remaining: 1491614,  dropped: 497465,   pctDrop: 25.0,  filterDesc: "phone IS NOT NULL OR email IS NOT NULL" },
];

const fmt = (n) => {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(0)}K`;
  return n.toLocaleString();
};
const fmtFull = (n) => n.toLocaleString();
const conversionRate = ((funnelData[funnelData.length - 1].remaining / funnelData[0].remaining) * 100).toFixed(1);
const steepestStep = funnelData.slice(1).reduce((a, b) => (b.dropped > a.dropped ? b : a));

const StatCard = ({ label, value, sub, color = BRAND.contactBlue }) => (
  <div style={{
    background: BRAND.white, border: `1px solid ${BRAND.eggshell}`,
    borderRadius: 8, padding: "16px 20px", flex: 1, minWidth: 160,
    borderTop: `3px solid ${color}`,
  }}>
    <div style={{ fontSize: 12, color: BRAND.clearSky, fontWeight: 500, textTransform: "uppercase", letterSpacing: 1 }}>{label}</div>
    <div style={{ fontSize: 28, fontWeight: 700, color: BRAND.graphite, marginTop: 4 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: BRAND.clearSky, marginTop: 2 }}>{sub}</div>}
  </div>
);

const CustomTooltip = ({ active, payload }) => {
  if (!active || !payload?.length) return null;
  const d = payload[0]?.payload;
  if (!d) return null;
  return (
    <div style={{
      background: BRAND.graphite, color: BRAND.white, padding: "12px 16px",
      borderRadius: 8, fontSize: 13, lineHeight: 1.6, maxWidth: 260,
    }}>
      <div style={{ fontWeight: 700, marginBottom: 4 }}>{d.step.replace("\n", " ")}</div>
      <div>Remaining: <strong>{fmtFull(d.remaining)}</strong></div>
      {d.dropped > 0 && <div>Dropped: <strong style={{ color: d.pctDrop > 60 ? "#FF6B6B" : BRAND.eggshell }}>{fmtFull(d.dropped)}</strong></div>}
      {d.pctDrop !== null && <div>Drop rate: <strong>{d.pctDrop}%</strong></div>}
      <div style={{ color: BRAND.eggshell, marginTop: 6, fontStyle: "italic", fontSize: 11 }}>{d.filterDesc}</div>
    </div>
  );
};

const barData = funnelData.map((d, i) => ({
  ...d,
  label: d.step.replace("\n", " "),
  invisible: i === 0 ? 0 : funnelData[0].remaining - funnelData[i - 1].remaining,
  droppedBar: d.dropped,
  remainingBar: d.remaining,
}));

export default function WaterfallReport() {
  const [view, setView] = useState("waterfall");

  return (
    <div style={{ fontFamily: "'Inter', 'SF Pro Display', -apple-system, sans-serif", background: "#F8F9FC", minHeight: "100vh", padding: 24 }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, color: BRAND.contactBlue, textTransform: "uppercase", letterSpacing: 2 }}>Audience Logic Report</div>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: BRAND.graphite, margin: "4px 0 0" }}>Insurance Movers — National 25+ with Contact Info</h1>
          <div style={{ fontSize: 13, color: BRAND.clearSky, marginTop: 4 }}>Audience #13003 | April 15, 2026 | Draft</div>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          {["waterfall", "table"].map(v => (
            <button key={v} onClick={() => setView(v)} style={{
              padding: "6px 14px", borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: "pointer",
              border: `1px solid ${view === v ? BRAND.contactBlue : BRAND.eggshell}`,
              background: view === v ? BRAND.contactBlue : BRAND.white,
              color: view === v ? BRAND.white : BRAND.graphite,
            }}>{v === "waterfall" ? "Chart" : "Table"}</button>
          ))}
        </div>
      </div>

      {/* Stat Cards */}
      <div style={{ display: "flex", gap: 16, marginBottom: 24, flexWrap: "wrap" }}>
        <StatCard label="Universe" value={fmt(funnelData[0].remaining)} sub="Total mover records" />
        <StatCard label="Final Audience" value={fmt(funnelData[funnelData.length - 1].remaining)} sub={`${conversionRate}% of universe`} color={BRAND.success} />
        <StatCard label="Steepest Drop" value={`${steepestStep.pctDrop}%`} sub={steepestStep.step.replace("\n", " ")} color={BRAND.danger} />
        <StatCard label="Filter Steps" value={funnelData.length - 1} sub="Progressive filters" color={BRAND.seafoam} />
      </div>

      {/* Chart or Table */}
      {view === "waterfall" ? (
        <div style={{ background: BRAND.white, borderRadius: 12, border: `1px solid ${BRAND.eggshell}`, padding: 24 }}>
          <h2 style={{ fontSize: 15, fontWeight: 700, color: BRAND.graphite, margin: "0 0 20px" }}>Targeting Funnel — Waterfall Dropoff</h2>
          <ResponsiveContainer width="100%" height={340}>
            <BarChart data={barData} layout="vertical" margin={{ left: 120, right: 60, top: 10, bottom: 10 }} barCategoryGap="30%">
              <CartesianGrid strokeDasharray="3 3" stroke={BRAND.eggshell} horizontal={false} />
              <XAxis type="number" tickFormatter={fmt} tick={{ fontSize: 11, fill: BRAND.clearSky }} domain={[0, funnelData[0].remaining]} />
              <YAxis type="category" dataKey="label" tick={{ fontSize: 12, fill: BRAND.graphite, fontWeight: 500 }} width={110} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="remainingBar" stackId="a" radius={[0, 4, 4, 0]}>
                {barData.map((d, i) => (
                  <Cell key={i} fill={i === barData.length - 1 ? BRAND.success : BRAND.contactBlue} />
                ))}
                <LabelList dataKey="remainingBar" position="right" formatter={fmt} style={{ fontSize: 12, fontWeight: 600, fill: BRAND.graphite }} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>

          {/* Annotation */}
          <div style={{
            marginTop: 16, padding: "10px 16px", background: "#FFF5F5",
            borderLeft: `3px solid ${BRAND.danger}`, borderRadius: "0 6px 6px 0", fontSize: 13, color: BRAND.graphite,
          }}>
            <strong>Largest filter:</strong> {steepestStep.step.replace("\n", " ")} removed {fmtFull(steepestStep.dropped)} records ({steepestStep.pctDrop}% drop)
          </div>
        </div>
      ) : (
        <div style={{ background: BRAND.white, borderRadius: 12, border: `1px solid ${BRAND.eggshell}`, padding: 24 }}>
          <h2 style={{ fontSize: 15, fontWeight: 700, color: BRAND.graphite, margin: "0 0 16px" }}>Targeting Funnel — Step Detail</h2>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <thead>
              <tr style={{ borderBottom: `2px solid ${BRAND.contactBlue}` }}>
                {["Step", "Filter", "Remaining", "Dropped", "% Drop", "SQL Clause"].map(h => (
                  <th key={h} style={{ padding: "10px 12px", textAlign: "left", color: BRAND.graphite, fontWeight: 700, fontSize: 11, textTransform: "uppercase", letterSpacing: 0.5 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {funnelData.map((d, i) => (
                <tr key={i} style={{ borderBottom: `1px solid ${BRAND.eggshell}`, background: i % 2 === 0 ? "#FAFBFE" : BRAND.white }}>
                  <td style={{ padding: "10px 12px", fontWeight: 600, color: BRAND.graphite }}>{i}</td>
                  <td style={{ padding: "10px 12px", color: BRAND.graphite }}>{d.step.replace("\n", " ")}</td>
                  <td style={{ padding: "10px 12px", fontWeight: 700, color: BRAND.contactBlue }}>{fmtFull(d.remaining)}</td>
                  <td style={{ padding: "10px 12px", color: d.pctDrop > 60 ? BRAND.danger : BRAND.graphite }}>{d.dropped ? fmtFull(d.dropped) : "—"}</td>
                  <td style={{ padding: "10px 12px", fontWeight: 600, color: d.pctDrop > 60 ? BRAND.danger : BRAND.graphite }}>{d.pctDrop !== null ? `${d.pctDrop}%` : "—"}</td>
                  <td style={{ padding: "10px 12px", fontFamily: "monospace", fontSize: 11, color: BRAND.clearSky }}>{d.filterDesc}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Footer */}
      <div style={{ textAlign: "center", marginTop: 24, fontSize: 11, color: BRAND.clearSky }}>
        Data provided by Blue Contact | Generated April 15, 2026
      </div>
    </div>
  );
}
