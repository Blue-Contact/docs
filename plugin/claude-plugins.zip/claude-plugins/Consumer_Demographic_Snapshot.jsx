import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie,
  Legend,
} from "recharts";

// Blue Contact brand tokens (from brand/brand.json)
const BC = {
  contactBlue: "#006AFF",
  lightBlue: "#1994FF",
  seafoam: "#12C7B4",
  graphite: "#2A3A57",
  clearSky: "#334669",
  hazard: "#FF9A1F",
  success: "#00C864",
  eggshell: "#E4E9F5",
  white: "#FFFFFF",
};

// ---------- Data (from live Athena queries on source_a.consumer_data) ----------
const TOTALS = {
  consumers: 254137291,
  households: 195740033,
  phone_pct: 85.7,
  email_pct: 72.3,
  with_phone: 217695976,
  with_email: 183676789,
};

const STATES = [
  { state: "CA", consumers: 26312823 },
  { state: "TX", consumers: 22057018 },
  { state: "FL", consumers: 18571718 },
  { state: "NY", consumers: 13858965 },
  { state: "OH", consumers: 10046759 },
  { state: "PA", consumers: 9771639 },
  { state: "IL", consumers: 9568256 },
  { state: "NC", consumers: 8601878 },
  { state: "MI", consumers: 8540429 },
  { state: "GA", consumers: 8538461 },
  { state: "VA", consumers: 6791814 },
  { state: "NJ", consumers: 6640368 },
  { state: "WA", consumers: 5836178 },
  { state: "TN", consumers: 5543077 },
  { state: "MA", consumers: 5451818 },
];

const AGE = [
  { bucket: "18–24", consumers: 11151042 },
  { bucket: "25–34", consumers: 40966278 },
  { bucket: "35–44", consumers: 38901690 },
  { bucket: "45–54", consumers: 36698138 },
  { bucket: "55–64", consumers: 39627467 },
  { bucket: "65–74", consumers: 36165816 },
  { bucket: "75+", consumers: 36523318 },
];

const INCOME = [
  { bucket: "Under $35K", consumers: 19053364 },
  { bucket: "$35K–$50K", consumers: 31173802 },
  { bucket: "$50K–$75K", consumers: 29780687 },
  { bucket: "$75K–$100K", consumers: 38607667 },
  { bucket: "$100K–$150K", consumers: 46860647 },
  { bucket: "$150K+", consumers: 75614575 },
];

const OWNERSHIP = [
  { name: "Home Owner", value: 160972516, color: BC.contactBlue },
  { name: "Renter", value: 32120389, color: BC.seafoam },
  { name: "Unknown / Not coded", value: 60916564, color: BC.eggshell },
  { name: "Probable Home Owner", value: 127822, color: BC.lightBlue },
];

// ---------- helpers ----------
const fmt = (n) => {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(0) + "K";
  return String(n);
};
const fmtFull = (n) => n.toLocaleString();

const Card = ({ children, className = "" }) => (
  <div className={`bg-white rounded-2xl shadow-sm border border-slate-100 p-5 ${className}`}>
    {children}
  </div>
);
const ChartTitle = ({ children, sub }) => (
  <div className="mb-3">
    <div className="text-sm font-semibold tracking-wide uppercase" style={{ color: BC.graphite }}>
      {children}
    </div>
    {sub && <div className="text-xs mt-0.5" style={{ color: BC.clearSky }}>{sub}</div>}
  </div>
);
const Stat = ({ label, value, sub, accent }) => (
  <Card className="flex flex-col justify-between">
    <div className="text-xs font-semibold tracking-wide uppercase" style={{ color: BC.clearSky }}>
      {label}
    </div>
    <div className="mt-2">
      <div className="text-3xl font-black" style={{ color: accent || BC.contactBlue }}>
        {value}
      </div>
      {sub && <div className="text-xs mt-1" style={{ color: BC.clearSky }}>{sub}</div>}
    </div>
  </Card>
);

const tooltipStyle = {
  backgroundColor: BC.graphite,
  color: BC.white,
  border: "none",
  borderRadius: 8,
  padding: "8px 12px",
  fontSize: 12,
};

export default function ConsumerDemographicSnapshot() {
  return (
    <div className="min-h-screen p-8" style={{ background: BC.eggshell }}>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-end justify-between mb-6">
          <div>
            <div className="text-xs font-semibold tracking-widest uppercase mb-1" style={{ color: BC.contactBlue }}>
              Blue Contact · Consumer Snapshot
            </div>
            <h1 className="text-3xl font-black tracking-tight" style={{ color: BC.graphite }}>
              Your Consumer Universe
            </h1>
            <div className="text-sm mt-1" style={{ color: BC.clearSky }}>
              source_a.consumer_data · live counts as of today
            </div>
          </div>
          <div className="text-right">
            <div className="text-xs uppercase tracking-wider" style={{ color: BC.clearSky }}>Total Records</div>
            <div className="text-4xl font-black" style={{ color: BC.contactBlue }}>
              {fmt(TOTALS.consumers)}
            </div>
          </div>
        </div>

        {/* Top stat row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Stat label="Consumers" value={fmt(TOTALS.consumers)} sub={`${fmtFull(TOTALS.consumers)} individuals`} />
          <Stat label="Households" value={fmt(TOTALS.households)} sub={`${fmtFull(TOTALS.households)} unique households`} accent={BC.clearSky} />
          <Stat label="Phone Coverage" value={`${TOTALS.phone_pct}%`} sub={`${fmt(TOTALS.with_phone)} reachable by phone`} accent={BC.seafoam} />
          <Stat label="Email Coverage" value={`${TOTALS.email_pct}%`} sub={`${fmt(TOTALS.with_email)} reachable by email`} accent={BC.success} />
        </div>

        {/* Geography (full-width) */}
        <Card className="mb-6">
          <ChartTitle sub="Top 15 by record count">Geographic Distribution</ChartTitle>
          <ResponsiveContainer width="100%" height={380}>
            <BarChart data={STATES} layout="vertical" margin={{ left: 10, right: 30, top: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={BC.eggshell} horizontal={false} />
              <XAxis type="number" tickFormatter={fmt} stroke={BC.clearSky} fontSize={11} />
              <YAxis type="category" dataKey="state" stroke={BC.graphite} fontSize={12} width={36} />
              <Tooltip
                contentStyle={tooltipStyle}
                formatter={(v) => [fmtFull(v), "Consumers"]}
              />
              <Bar dataKey="consumers" radius={[0, 6, 6, 0]}>
                {STATES.map((_, i) => (
                  <Cell key={i} fill={i === 0 ? BC.contactBlue : i < 4 ? BC.lightBlue : BC.seafoam} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* 2-col: Age + Income */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <Card>
            <ChartTitle sub="Where age is known">Age Distribution</ChartTitle>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={AGE} margin={{ top: 10, right: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={BC.eggshell} vertical={false} />
                <XAxis dataKey="bucket" stroke={BC.graphite} fontSize={11} />
                <YAxis tickFormatter={fmt} stroke={BC.clearSky} fontSize={11} />
                <Tooltip
                  contentStyle={tooltipStyle}
                  formatter={(v) => [fmtFull(v), "Consumers"]}
                />
                <Bar dataKey="consumers" fill={BC.contactBlue} radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>

          <Card>
            <ChartTitle sub="Estimated household income">Income Brackets</ChartTitle>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={INCOME} margin={{ top: 10, right: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={BC.eggshell} vertical={false} />
                <XAxis dataKey="bucket" stroke={BC.graphite} fontSize={10} />
                <YAxis tickFormatter={fmt} stroke={BC.clearSky} fontSize={11} />
                <Tooltip
                  contentStyle={tooltipStyle}
                  formatter={(v) => [fmtFull(v), "Consumers"]}
                />
                <Bar dataKey="consumers" fill={BC.seafoam} radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* 2-col: Ownership donut + Coverage bars */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <Card>
            <ChartTitle sub="Home_Owner field">Ownership Mix</ChartTitle>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie
                  data={OWNERSHIP}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                >
                  {OWNERSHIP.map((slice, i) => (
                    <Cell key={i} fill={slice.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={tooltipStyle}
                  formatter={(v, name) => [`${fmt(v)} (${((v / TOTALS.consumers) * 100).toFixed(1)}%)`, name]}
                />
                <Legend wrapperStyle={{ fontSize: 11, color: BC.graphite }} />
              </PieChart>
            </ResponsiveContainer>
          </Card>

          <Card>
            <ChartTitle sub="Reachable contact methods">Contact Coverage</ChartTitle>
            <div className="space-y-5 mt-2">
              <div>
                <div className="flex justify-between mb-1">
                  <div className="text-sm font-semibold" style={{ color: BC.graphite }}>Phone</div>
                  <div className="text-sm font-bold" style={{ color: BC.contactBlue }}>{TOTALS.phone_pct}%</div>
                </div>
                <div className="h-3 w-full rounded-full" style={{ background: BC.eggshell }}>
                  <div
                    className="h-3 rounded-full"
                    style={{ width: `${TOTALS.phone_pct}%`, background: BC.contactBlue }}
                  />
                </div>
                <div className="text-xs mt-1" style={{ color: BC.clearSky }}>
                  {fmtFull(TOTALS.with_phone)} consumers
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <div className="text-sm font-semibold" style={{ color: BC.graphite }}>Email</div>
                  <div className="text-sm font-bold" style={{ color: BC.seafoam }}>{TOTALS.email_pct}%</div>
                </div>
                <div className="h-3 w-full rounded-full" style={{ background: BC.eggshell }}>
                  <div
                    className="h-3 rounded-full"
                    style={{ width: `${TOTALS.email_pct}%`, background: BC.seafoam }}
                  />
                </div>
                <div className="text-xs mt-1" style={{ color: BC.clearSky }}>
                  {fmtFull(TOTALS.with_email)} consumers
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100">
                <div className="text-xs uppercase tracking-wider mb-1" style={{ color: BC.clearSky }}>
                  Either phone or email
                </div>
                <div className="text-2xl font-black" style={{ color: BC.graphite }}>
                  ~{Math.round(((TOTALS.with_phone + TOTALS.with_email) / TOTALS.consumers) * 50)}% reachable
                </div>
                <div className="text-xs mt-1" style={{ color: BC.clearSky }}>
                  Strong starting point for outreach campaigns
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Footer */}
        <div className="text-center text-xs mt-4" style={{ color: BC.clearSky }}>
          Data provided by Blue Contact · source_a.consumer_data · 254.1M individual records across 195.7M households
        </div>
      </div>
    </div>
  );
}
