# Changelog

All notable changes to the Blue Contact plugin are documented here. This
project adheres to [Semantic Versioning](https://semver.org/).

## [0.9.0] - 2026-08-19

`find_similar_audiences` shipped to production on 2026-08-19. Users were
asking the same question weeks apart and getting different counts because
the agent re-derived the SQL each time — defensible variance, but invisible,
so it read as unreliability. The server now lets a repeated question be
answered with the query that already ran, and the plugin's audience
workflows check for that precedent before writing SQL. Note what this is
*not*: the tool surfaces a precedent and the model decides. Only `exact` /
`strong` matches (`reusable: true`) are reused automatically; `related` is a
lead to read, never a query to run silently.

### Added
- **`find_similar_audiences` is the new first step of the canonical
  workflow.** `audience-building`'s "## Workflow" opens with a precedent
  check — call it with the user's request before clarifying the target —
  and the remaining steps are renumbered 2–8 (internal cross-references
  updated). The step documents the full contract: account-wide search
  (teammates' audiences included), each match's `sql` / count / run date /
  owner / `guidance`, `exact`|`strong` → `validate_sql` then reuse the `sql`
  **verbatim** (the schema may have moved, so validation is the gate),
  `related` → read the match's `prompt` and judge. Because matching is
  lexical, a genuine repeat can come back as `related` on wording alone
  ("Wisconsin" vs "WI") — judge by the prompt text, not the band; and
  because `exact`/`strong` are additionally model-checked server-side for the
  same target population, "homeowners NOT in Texas" can't be auto-reused
  against "homeowners in Texas". Deviating from an `exact`/`strong`
  precedent is allowed (validation failure, a defect in the old query, a
  genuinely different ask) but must be stated in `reasoning`, with the note
  that the count may differ from the earlier run. Also added as a "Best
  practices" bullet.
- **The precedent check propagated to the other audience-building
  entry points**, each in its own register:
  - `audience-pull` — a compressed one-paragraph step 1 (steps renumbered
    2–9), pointing at `audience-building` step 1 for detail. This is the
    demo path, where a re-derived count is most visible.
  - `market-sizing` — folded into "1. Understand the market definition" as
    a lead-in, framed for TAM: a repeated sizing question shouldn't move
    just because the SQL was re-derived. Numbering unchanged.
  - `industry-playbooks` — one sub-step in "Execute the playbook", placed
    after the playbook questions are answered (that's when a comparable
    prompt exists) and before the SQL is written; sub-steps renumbered
    4–10. Playbooks get re-run by different people on the same account, so
    the precedent hit rate is high.
  - `getting-started` is deliberately **not** wired up: the tour fires a
    fixed marginal query per topic rather than answering a user-described
    audience, its whole design target is "first chart in ~15 seconds," and
    its build path hands off to `audience-pull`, which now checks.
- **`data-querying` tool reference** documents `find_similar_audiences`
  (parameters, the three match bands, `reusable`, the lexical-matching
  caveat) alongside the other audience tools.
- **Tool grants** — `mcp__blue-contact__find_similar_audiences` added to
  `audience-pull` and `market-sizing` (`allowed-tools`) and to the
  `data-analyst` agent (`tools`). `audience-building`, `data-querying`, and
  `industry-playbooks` declare no tool list, so they need no grant.
  `audience-compare`, `audience-monitor`, `audience-report`,
  `audience-logic-report`, and the `data-monitor` / `report-builder` agents
  all operate on audiences that already exist — no precedent lookup, no
  grant.
- **`data-analyst` agent** gained the precedent step (new step 5, rest
  renumbered) — it takes audience builds with iterative refinement, which is
  exactly where a silently re-derived query costs the most.

### Changed
- **Relay the `precedent` / `comparison` block.** `run_audience_query` and
  `get_audience_run` now return `prior_count`, `current_count`,
  `delta_percent`, a ready-to-use `disclosure` sentence, and
  `sql_identical` when the account has answered the question before.
  `audience-building`'s "Polling for results" section, the `data-querying`
  safety rules, the `data-analyst` agent, and the `get_audience_run`
  PostToolUse hook all say to pass it on and to read `sql_identical`
  correctly: `false` means this run used a *different query*, `true` means
  the *same query over refreshed data*. Those are opposite explanations for
  a number that moved — never report one as the other, and never present a
  count that moved as if nothing had changed.

## [0.8.1] - 2026-08-17

### Fixed
- **Reconciled the `TABLESAMPLE` contradiction introduced in 0.7.3.**
  `getting-started/references/topic-playbooks.md` carried a blanket "Never
  use `TABLESAMPLE`, `GROUPING SETS`, or `execute_sql_query`", which
  directly contradicted 0.7.3's new `data-querying` safety rule (and the
  server's own `run_audience_query` guidance) requiring `TABLESAMPLE
  SYSTEM (1)` for unfiltered samples of large tables. Both rules are right
  within their scope, so the ban is now scoped and re-reasoned: no
  `TABLESAMPLE` in a *marginal* query because it reports exact counts and
  sampling would skew every number, with an explicit note that the
  `data-querying` rule governs row samples instead. The `data-querying`
  rule gained the matching caveat ("a rule about row samples, not
  aggregates"), so neither can be over-applied. The `execute_sql_query`
  half of the blanket ban is dropped as redundant — the tour's
  one-`run_audience_query`-per-topic discipline is already stated, with its
  reasoning, at the top of the same file.

## [0.8.0] - 2026-08-17

The dataset pipeline is gone. Verified against the deployed MCP server on
2026-08-17: eight tools were **removed** (not deprecated) —
`create_dataset`, `create_dataset_from_query`, `get_dataset`,
`get_dataset_preview`, `list_datasets`, `kickoff_import_match`,
`kickoff_profiling`, `kickoff_scoring`. Owned tables are now the only unit
of owned data: jobs are addressed by `table_id`, runs by `data_job_id`.
`get_table` no longer returns a `dataset_id` (confirmed against a live
match-output table).

### Changed
- **`personas` rewritten onto `run_data_job`.** Segmentation is
  `run_data_job(job_type: "segment", table_id: ...)` and scoring is
  `run_data_job(job_type: "score", table_id: ..., source_db/source_table,
  output_db/output_table)`. Sourcing a table now goes through
  `create_table_from_query` (`audience_id` | `sql` | `existing_table`)
  instead of `create_dataset_from_query`. Two calls the skill previously
  prescribed would have hard-failed against the current schemas:
  `get_profiling_artifacts` takes `table_id` (it has no `dataset_id`
  property and rejects unknown keys), and `iterate_profiling` **requires**
  `table_id`. Status polling documented as `get_profiling_status` /
  `get_scoring_status` / `get_run_status` by `data_job_id` or `table_id`.
  Tool grants updated: the five removed tools dropped; `run_data_job`,
  `create_table_from_query`, `get_table_preview`, and
  `read_profiling_stats` (referenced in the body but never granted) added.
- **`my-data`: the "table ↔ dataset bridge" section replaced** with
  "`table_id` is the only handle", since the `dataset_id` it described is
  not in the `get_table` response. `get_run_status` documented with
  `data_job_id` / `table_id` / `run_type` rather than the retired
  `dataset_run_id` / `dataset_id`. The `kickoff_import_match` legacy
  parenthetical and the `list_datasets` escape hatch are deleted — there is
  no tool left to run those flows with.
- **`data-querying`: tool inventory corrected.** The profiling/scoring
  family now lists what exists (`get_profiling_status`,
  `iterate_profiling`, `list_profiling_jobs`, `get_scoring_status`,
  `get_scoring_results`); the "legacy dataset pipeline" bullet is replaced
  by an explicit note that those tools were removed and calling them fails.
- **`audience-building`: personas hand-off** now describes
  `create_table_from_query` → `run_data_job(job_type: "segment")`.
- **`report-builder` agent** takes a `table_id` for
  `get_profiling_artifacts` instead of a `dataset_id`.

### Added
- **All four match libraries documented.** `match_target` accepts
  `consumer | business_contact | company | property` (previously only the
  first two were documented), with `bc_company_id` and `bc_property_id`
  alongside `bc_consumer_id` / `bc_contact_id`, and a
  `bc_match_<library>_*` column family per library. Confirmed against a
  live match-output table.
- **`name_match_mode` and `household_max_entities`.** New `my-data`
  section covering `exact` / `fuzzy` / `household` address-match
  strictness, the `HOUSEHOLD_MATCH` grade ("the right home, not always the
  right person" — to be stated plainly to the user), and the default-5
  ambiguity cutoff. The "here's my customer list" flow now *offers* the
  mode rather than only documenting it: target library and name-match mode
  are asked in a single `AskUserQuestion` call (preserving the
  one-question-then-act rule), the mode question is skipped when the match
  will run on email or phone, and a `"household"` run reports its
  `HOUSEHOLD_MATCH` row count back to the user.

## [0.7.3] - 2026-07-22

Mirrors a server-side guidance change (bluequeryai #578): the SQL builder
now steers unfiltered samples of large tables through `TABLESAMPLE SYSTEM`.

### Changed
- **`data-querying`: unfiltered-sampling guardrail.** Added a Critical-safety
  rule that a `LIMIT` with only `IS NOT NULL` predicates does not bound the
  scan and will exhaust Athena on a large table — use `TABLESAMPLE SYSTEM (1)`
  after the table name and its alias, stepping the percentage up (1 → 5 → 25)
  if 0 rows return. Small tables keep plain `LIMIT`. Matches the server's
  `get_query_instructions` / `run_audience_query` guidance so plugin users and
  direct MCP clients see the same rule.


## [0.7.2] - 2026-07-21

Synced with the live Blue Contact MCP surface (verified against the
deployed server's tool schemas on 2026-07-21). Tool inventory was already
complete — all 41 platform tools referenced, nothing stale — but three
server-side behavior changes needed doc updates.

### Changed
- **`get_query_instructions` is now optional.** The server moved the
  essential SQL rules into the `run_audience_query`/`get_schema` tool
  descriptions and downgraded this tool to "full reference only". The
  blanket "call once per session" mandate is removed from
  `data-querying`, `audience-building`, `market-sizing`, `audience-pull`,
  and the `data-analyst` agent — each now says to call it only when the
  full platform reference is needed. (`audience-logic-report` keeps its
  call: explaining SQL conventions in a shareable doc is the full-reference
  use case. Tool grants are unchanged.)
- **Multi-library `match_target` documented.** `run_data_job(job_type:
  "match")` now accepts an array or comma-separated list (e.g.
  `"consumer,business_contact"`); the output carries one typed id column
  per selected library (`bc_consumer_id` and/or `bc_contact_id`, with
  `bc_match_entity_types` listing which matched), and each id column's
  authoritative join lives in its `joins` metadata in `get_schema`.
  `my-data` documents all of this (join targets via schema metadata, not
  hardcoded table names, per the 0.6.4 no-hardcoded-catalogs rule) plus
  the server's stated 5–10 minute match ETA.

### Added
- **`datasource` disambiguation parameter documented.** `get_schema`,
  `search_schema`, `sample_values`, and `read_profiling_stats` accept an
  optional `datasource` to resolve a database name assigned in multiple
  catalogs; the tools report ambiguity when it's needed. Noted in
  `data-querying` and the catalog guide (previously `datasource` was
  documented only as a response field).

## [0.7.1] - 2026-07-03

### Fixed
- **`my-data` no longer lets the match-target confirmation go stale.**
  Observed in the field: the agent asked which library to match against,
  the user answered, and the next turn re-presented the pre-question
  context ("pick whichever fits your goal above") without launching the
  job — the choice was received but not acted on. The suggested flow now
  requires all supporting context (fill-rate highlights, recommendation)
  to be presented *before* the question, and mandates launching
  `run_data_job(job_type: "match")` in the same turn the answer arrives —
  never re-confirming, restating the question, or ending the turn between
  answer and launch. The matching section carries the same rule.

## [0.7.0] - 2026-07-03

The Blue Contact MCP grew from ~11 tools to ~45. This release integrates the
new tool families: owned tables & uploads, managed data jobs, profiling /
personas, and scoring. Verified live against the platform's table↔dataset
fix (2026-07-03): `get_table` returns a top-level `dataset_id` (shared by a
match output and its source), which is the documented hand-off from owned
tables to the dataset-scoped profiling/scoring tools; both skills describe
that bridge. Data-job status responses carry an ETA and explicit "share the
ETA and end your turn" guidance — the skills follow it instead of
sleep-polling in a loop.

### Added
- **`my-data` skill** (`/blue-contact:my-data`) — the bring-your-own-data
  lifecycle: upload files as queryable owned tables
  (`create_table_from_file` ≤25MB; `request_upload_url` +
  `register_uploaded_table` above that), materialize tables from SQL or an
  audience (`create_table_from_query`), match uploads against the library
  via `run_data_job(job_type: "match")`, quality checks, table management
  (`list_tables`/`get_table`/`get_table_preview`), and retention
  (30-day default expiry; `set_table_retention` pin/extend; `drop_table`
  with mandatory user confirmation).
- **`personas` skill** (`/blue-contact:personas`) — profiling/segmentation
  and scoring: `create_dataset_from_query` (incl. from an `audience_id`) →
  `kickoff_profiling` → `get_profiling_artifacts`/`get_persona_details` →
  `iterate_profiling` for comparison runs → `kickoff_scoring` /
  `get_scoring_results` to score prospect universes. Documents the
  minutes-long Glue-job polling cadence (`get_run_status`, 30–60s) as
  distinct from the 2–5s audience-query polling.
- **`read_profiling_stats` and `sample_values`** documented in
  `data-querying` and `data-dictionary`, and granted to `data-analyst`:
  whole-table fill rates now come from persisted profiler stats (no Athena
  query) and example values from masked sampling — with an explicit rule
  against SQL COUNT fill-rate probes and `SELECT DISTINCT` value probes.
  `audience-building`'s coverage step now scopes its SQL probes to
  *filtered-audience* coverage only.
- **Agent upgrades**: `data-analyst` gained `sample_values`,
  `read_profiling_stats`, and owned-table lookups
  (`list_tables`/`get_table`/`get_table_preview`); `report-builder` gained
  `read_profiling_stats`, `get_profiling_artifacts`, and
  `get_persona_details` plus an opt-in personas report section (read-only —
  it never launches profiling jobs).
- **Cross-cutting safety rules** in `data-querying` (mirrored from the
  server's tool descriptions): never match/append uploads to the library
  via SQL joins (managed match job only), never compute whole-table fill
  rates via SQL, table materialization only through
  `create_table_from_query` (never hand-written DDL — SELECT-only rule
  nuanced accordingly in `sql-conventions.md`).
- **Legacy flags surfaced**: `list_datasets`, `kickoff_import_match`, and
  `create_dataset` are documented as the legacy dataset pipeline, only for
  pre-existing `dataset_id` flows.
- **Onboarding touch-ups**: `getting-started` menu gained a
  "Bring your own data" hand-off to `my-data` and persona follow-up
  suggestions; `setup` mentions upload/match/personas in its expectations
  and pointer list; README, plugin description, and keywords updated
  (14 skills).

## [0.6.5] - 2026-06-19

### Added
- **`search_schema` tool support.** The platform added a `search_schema`
  MCP tool for definition discovery — it searches the catalog and returns
  lightweight database › table › column breadcrumbs, so an agent can find
  which table holds a field without pulling a full schema (the largest
  production database is millions of tokens in full). `get_query_instructions`
  now points agents at it, so the subagents need it granted:
  - Added `mcp__blue-contact__search_schema` to the `data-analyst` and
    `report-builder` tool grants. Without this, those subagents would be
    told (by `get_query_instructions`) to call a tool their whitelist blocks.
    `data-monitor` is intentionally left out — it only ever operates on a
    known audience's table, so cross-table discovery isn't its job.
  - Documented the tool in the `data-querying` skill's "Available Tools" and
    "Always do first" sections, and in the `data-analyst` workflow, framed as
    discovery-first (find where a field lives, then `get_schema` for detail).

## [0.6.4] - 2026-06-11

### Fixed
- **Tool grants now use real MCP tool names.** Every skill `allowed-tools`
  list and agent `tools` list used the invalid `blue-contact:tool` form,
  which matches nothing — skill grants were silent no-ops and the agents'
  whitelists stripped their MCP access entirely (`data-analyst` and
  `data-monitor` had zero usable tools). All entries are now
  `mcp__blue-contact__<tool>`, with previously missing built-ins added
  (`Read`/`Write`/`Bash`/`AskUserQuestion` where used), unused
  `create_audience` grants pruned, and `run_audience_query` added to the
  skills whose workflows call it. Note: these grants pre-approve in Claude
  Code only — Cowork namespaces the connector differently.
- **`data-monitor` can now actually complete a run** — it gained
  `get_audience_run` (its query tool is async and it had no way to poll for
  results) and `get_schema`, plus instructions to derive contact columns
  instead of assuming `COUNT(phone)`. It also lost `run_audience_query`,
  which its own constraints forbid.
- **PostToolUse hook no longer suppresses terminal-state reminders** when a
  completed run's row data or SQL happens to contain the word "running" /
  "queued" / "fixing" — the suppression grep now matches the `"status"`
  JSON field specifically.
- **SessionStart hook is namespace-agnostic** (the old text hardcoded
  `mcp__blue-contact__*`, which is wrong in Cowork) and guards against an
  unset `CLAUDE_PLUGIN_ROOT`.
- **The logic-report re-ingestion spec now matches what the generator
  emits.** It previously instructed parsing Word checkbox controls (SDTs)
  and per-step change-note fields that `generate_report.js` never produces;
  it now parses the literal `☐ Approved ☐ Change requested` text marks and
  routes suggestion adoptions through Reviewer Notes. Also fixed the
  Reviewer Notes section number (5, not 4) and aligned the waterfall danger
  threshold between the `.jsx` (was >80%) and `.docx` (≥97%) outputs.
- **Cross-skill contradictions resolved**: hardcoded
  `lsc_data_catalog.business_db` examples replaced with
  `<catalog>.<business_db>` placeholders (the catalog guide no longer
  asserts which catalog houses which data — it varies by account; read
  `datasource` from `get_schema`); the false "the platform rejects
  `execute_sql_query`" claim in the getting-started references scoped to
  tour cost discipline; billing language unified on "billing-tracked";
  coverage SQL examples (`COUNT(phone)`) now carry a schema-first caveat
  since contact fields can live in separate join tables; the
  audience-report polling note no longer forbids concurrent distinct
  probes (the real rule: never re-submit the same SQL while in flight);
  `audience-monitor` no longer references a nonexistent
  `create_scheduled_task` tool.
- **Setup skill**: the connectivity-test query is now opt-in with its cost
  disclosed (there is no untracked SQL path), and the Claude Code
  connector-missing flow points at the bundled `.mcp.json` before
  suggesting a manual `/mcp` add (which would create a duplicate).
- **Brand**: added the missing `lightRule: #D0D9EF` token (used by both
  report generators) to `brand.json`/`BRAND.md`; documented that no white
  logo variant ships (use the gradient logo in a white chip on dark
  backgrounds); noted that logo paths are plugin-root-relative.
- **README**: corrected the marketplace org slug (`Blue-Contact`), the
  local-dev `--plugin-dir` path, and folded the misleading separate "slash
  commands" bullet into the skills bullet.

### Changed
- **~30% smaller install.** Removed from distribution: the three root demo
  `.jsx` artifacts (~98K, dereferenced since 0.6.1), the `specs/` internal
  planning docs (~72K, including a stale duplicate report generator that
  hardcoded a `/home/claude/` path), and `.claude/settings.local.json`.
  `specs/` is now fully gitignored.
- Agent `model` pins switched from full model IDs (`claude-sonnet-4-6`,
  `claude-haiku-4-5`) to the `sonnet` / `haiku` aliases so installed copies
  survive model retirements.
- `report-builder` and `audience-report` document a fallback when the
  `pptx`/`pdf` Anthropic skills aren't available (generate via
  `python-pptx` / `reportlab` in Bash).
- Skill descriptions sharpened as trigger surfaces (`audience-building` vs
  `audience-pull` disambiguated; `data-querying` and `setup` now say when
  to fire). The orphaned `examples/` files in `audience-pull` and
  `audience-report` are now referenced from their skills. Cross-skill
  "Polling for results" pointers now carry the actual
  `${CLAUDE_PLUGIN_ROOT}` path. `generate_report.js`'s undeclared `docx`
  npm dependency is documented with an install step. `category` moved from
  plugin.json to the marketplace entry; stray `name` field removed from
  `.mcp.json`.

## [0.6.3] - 2026-06-11

### Fixed
- **Reports generated in installed sessions (e.g., Cowork) now use Blue
  Contact branding.** Skills referenced brand assets with repo-root-relative
  paths (`brand/BRAND.md`, `brand/brand.json`, `brand/logos/*.svg`), which
  only resolve when the working directory *is* this repo. In an installed
  plugin session the CWD is the user's workspace, so the brand reads failed
  silently and reports fell back to generic styling. Three-layer fix:
  - All brand asset references in skills, agents, and examples now use
    `${CLAUDE_PLUGIN_ROOT}/brand/...` so they resolve regardless of CWD
    (`audience-report`, `audience-monitor`, `audience-compare`,
    `market-sizing`, `industry-playbooks`, `audience-logic-report`,
    `getting-started`, `report-builder` agent,
    `branded-report-structure.md`, `visualization-guide.md`).
  - The `SessionStart` hook now emits the resolved absolute path to the
    `brand/` directory, so the model always knows where the assets live.
  - Report skills carry an inline fallback palette (contactBlue `#006AFF`,
    graphite, seafoam, gradient, chart order, attribution line) so a failed
    brand read degrades to correct colors instead of an unbranded artifact.

## [0.6.2] - 2026-06-05

### Changed
- **Getting Started tour speed pass — time-to-first-chart drops from ~15s to
  ~0–5s on the pre-warmed pick and ~10–12s on other topics.** Several
  changes compound:
  - **Fire-and-narrate order in Phase 3** — the marginal `run_audience_query`
    now fires first; narration, brand load, and (rare) schema fallback all
    happen *during* the poll instead of before it. Old order was
    narrate → fire → silently poll.
  - **Speculative pre-warm in Phase 2** — the most-likely-pick marginal
    query fires in the same response as the menu `AskUserQuestion`. If the
    user picks that topic, the query is already in flight. Heuristic:
    `consumer` → demographic snapshot, else the first non-`custom` category
    present. Cost: one billable run on a wrong-topic pick.
  - **Canonical columns inlined in `topic-playbooks.md`** — the marginal SQL
    for each topic now lists the standard column names directly (e.g.,
    `individual.age`, `individual.homeowner_status` `H`/`R`/`U`,
    `consumer_phone`/`consumer_email` semi-joins). The preliminary
    `get_schema` round-trip is gone from the hot path; the schema call is
    a fallback only on a "column not found" error.
  - **Dashboard skeleton inlined in SKILL.md** — the ~40-line skeleton no
    longer requires a separate read of `references/visualization-guide.md`
    during the hot path.
  - **Brand load (`brand/BRAND.md`, `brand/brand.json`) moved into the
    Phase 3 poll window** instead of running at session start.
- **"Skip — straight to building" menu option** added to Phase 2 — power
  users on a return visit can bail to `audience-pull` immediately.
- **Phase 4 command catalog collapsed to one or two contextual suggestions
  per topic** rather than reciting all seven workflows.
- **`visualization-guide.md` is now on-demand only** (chart-selection +
  interactive cube pattern); it dropped from 92 lines to 45.
- **Wait is telegraphed explicitly** at the top of Phase 3 ("about 15
  seconds — while that runs, here's what we're looking at…") so the user
  is never staring at silence.

### Fixed
- **"Save & share for QA" no longer interrupts with an `AskUserQuestion`
  turn** after an audience is finalized in "Build your first audience" —
  the offer is now inline ("just say the word — I'll trigger
  `audience-logic-report`") so the tour doesn't stall on a button click.
- Phase 3 applicability guard table dropped — Phase 2 menu construction
  is already the applicability check; the guard was unreachable.

### Removed
- Unused tools dropped from `getting-started` `allowed-tools`:
  `get_query_instructions`, `validate_sql`, `execute_sql_query`. The tour
  never called them, and `execute_sql_query` is explicitly forbidden by
  the platform anyway.

## [0.6.1] - 2026-05-29

### Changed
- **Getting Started tour is faster for live, sales-facing demos.** Each topic
  now runs a **single** compact marginal query (`dimension, value, count` via
  `UNION ALL`) instead of 2–3 serial async runs. Cuts time-to-first-chart from
  ~30–45s to ~15s and reduces each topic to one billable run.
- Dashboards in the tour are now authored from the prebuilt skeleton in
  `references/visualization-guide.md` rather than from scratch.
- "Build your first audience" remains an intentional multi-step guided flow
  (count + coverage folded into one run, then one run to create the audience).
- **`get_schema` calls are now table- and column-scoped across all skills and
  agents.** The MCP tool gained table/column scoping and option-list
  summarization; pulling whole databases was slow and got truncated on large
  ones. Updated: `data-querying`, `getting-started`, `audience-building`,
  `audience-pull`, `audience-logic-report`, `market-sizing`,
  `industry-playbooks`, `data-dictionary`, `setup`, plus the `data-analyst`
  and `report-builder` agents.
- **Contact-coverage probe rewritten as a deduped semi-join.** Phone and
  email live in separate one-to-many tables joined on `Id`, so
  `COUNT(phone)`/`COUNT(email)` against the consumer table was wrong. Now
  uses `COUNT(DISTINCT p.id)` via a semi-join.
- **Demographic snapshot uses the reliable compact-marginal pattern, not a
  cube.** The platform's SQL auto-fixer reshapes multi-dimensional cubes
  unpredictably (collapsing to a flat profile, expanding past one page, or
  hard-failing on `TABLESAMPLE`). The snapshot now ships one
  `run_audience_query` returning ~30 rows of `dimension/value/consumers`
  via `UNION ALL` per dimension, with the static dashboard as the baseline
  deliverable. The interactive "slice-it-yourself" cube is demoted to an
  opt-in upgrade gated on shape verification. `TABLESAMPLE`, `GROUPING
  SETS`, and `execute_sql_query` are now explicitly forbidden in the tour.

### Performance
- **Stopped pointing skills/agents at large sample files to "model on."**
  Removed references to a 74KB `Interactive_Audience_Builder.jsx`, 11.6KB
  `b2b-landscape.jsx`, and 20KB `generate_branded_report.js`.
  `getting-started` ships a compact ~40-line dashboard skeleton in
  `references/visualization-guide.md`; report builders point at
  `brand/BRAND.md` as the source of truth.
- **Slimmed the two heaviest skills via progressive disclosure.**
  `getting-started` 288 → 168 lines (visualization how-to and per-topic
  playbooks moved to `references/`, loaded only for the chosen topic).
  `audience-logic-report` 457 → 206 lines (~55%): re-ingestion workflow
  moved to `references/re-ingestion.md`, and the .docx/.md output-format
  specs moved to `references/report-formats.md`, both loaded on demand.
- `data-dictionary/references/b2b.md`: replaced a `SELECT *` example with
  an explicit column list (the `companies` table is 60+ columns).

### Fixed
- **`get_audience_run` PostToolUse hook matcher now matches the full MCP
  tool name** (`mcp__.*__get_audience_run`). The original
  `mcp__blue-contact__get_audience_run` matched only the `blue-contact`
  server namespace; the deployed connector uses `mcp__claude_ai_Blue_Contact__*`,
  so the hook never fired and completed polls produced no reminder. An
  interim namespace-agnostic `get_audience_run$` matched under search
  semantics but not when anchored — `mcp__.*__get_audience_run` works under
  both.
- `post-get-audience-run.sh` now only emits on terminal states
  (`completed`/`failed`) instead of on every poll, and fails open so a
  completed result is never dropped.

### Removed
- Dropped the `execute_sql_query` follow-up probes from the Getting Started
  walkthrough — the platform rejects that call.

## [0.6.0] - 2026-05-28

### Changed
- **Teach the async kick-off + polling pattern for MCP query tools.** The
  Blue Contact MCP server now returns asynchronously from
  `run_audience_query` and `execute_sql_query` — both queue the Athena
  execution to a worker dyno and return immediately with `{audience_id,
  run_id, status: "queued", ...}` and no rows. A new `get_audience_run`
  MCP tool is the poll target, returning `running`/`completed`/`failed`
  with the full row payload (`rows`, `columns`, `coverage_summary`,
  `download_url`, `next_token`) on completion. This is a breaking-change
  shift away from synchronous Heroku web requests, which were dying to
  H12 timeouts (30s router limit) on any non-trivial query against the
  254M-row consumer tables.

### Added
- **`audience-building` gets a canonical "Polling for results" section** —
  the single source of truth other skills reference.
- **Async-query callouts** added to `audience-pull`, `audience-report`,
  `audience-compare`, `market-sizing`, and `getting-started`, each
  pointing back at the canonical poll loop and adding `get_audience_run`
  to allowed-tools.
- `audience-monitor` and `audience-logic-report` get `get_audience_run`
  in allowed-tools (they orchestrate less heavily but still need to poll).
- `data-querying` tool catalog rewritten to describe the async kick-off
  shape; `get_audience_run` documented as the poll target. Safety rules
  gain an "async" bullet.
- `data-analyst` and `report-builder` agents get `get_audience_run` in
  their tool lists and workflow prose updated to spell out the poll loop.
  `report-builder` explicitly notes "do not start a new probe until the
  prior poll reaches `completed`" since it runs multi-query report
  generation.
- New `hooks/post-get-audience-run.sh` with branched reminders for
  `queued`/`running`/`fixing` (keep polling), `completed` (surface
  `coverage_summary` + `download_url`), and `failed` (surface
  `error_message`). Replaces `post-run-audience-query.sh`.

### Removed
- `hooks/post-run-audience-query.sh` — replaced by the
  `get_audience_run`-targeted hook above, since the poll target is where
  results actually land.

[0.6.4]: https://github.com/Blue-Contact/claude-plugins/releases/tag/v0.6.4
[0.6.3]: https://github.com/Blue-Contact/claude-plugins/releases/tag/v0.6.3
[0.6.2]: https://github.com/Blue-Contact/claude-plugins/releases/tag/v0.6.2
[0.6.1]: https://github.com/Blue-Contact/claude-plugins/releases/tag/v0.6.1
[0.6.0]: https://github.com/Blue-Contact/claude-plugins/releases/tag/v0.6.0
