import { useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

const BRAND = {
  contactBlue: "#006AFF",
  lightBlue: "#1994FF",
  graphite: "#2A3A57",
  clearSky: "#334669",
  seafoam: "#12C7B4",
  success: "#00C864",
  danger: "#DB4646",
  hazard: "#FF9A1F",
  eggshell: "#E4E9F5",
  white: "#FFFFFF",
  gradient: "linear-gradient(135deg, #1A94FF 0%, #006AFF 100%)",
};

const funnelData = [
  { step: "Universe", remaining: 93620049, dropped: 0, pctDrop: null },
  {
    step: "US Only",
    remaining: 49079383,
    dropped: 44540666,
    pctDrop: 47.6,
  },
  {
    step: "Seniority Filter",
    remaining: 9122764,
    dropped: 39956619,
    pctDrop: 81.4,
  },
  {
    step: "Real Estate Industry",
    remaining: 265668,
    dropped: 8857096,
    pctDrop: 97.1,
  },
];

const audienceInfo = {
  title: "US Real Estate Decision Makers — C-Level, VP, Director",
  id: 17228,
  total: 265668,
  emailCoverage: 168205,
  emailCoveragePct: 63.3,
  phoneCoverage: 179599,
  phoneCoveragePct: 67.6,
};

const fmt = (n) => {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toLocaleString();
};

const fmtComma = (n) => n.toLocaleString();

const CustomTooltip = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-white p-3 rounded shadow-lg border border-gray-200">
        <p className="font-semibold text-gray-900">{data.step}</p>
        <p className="text-sm text-gray-700">
          Remaining: {fmtComma(data.remaining)}
        </p>
        {data.dropped > 0 && (
          <p className="text-sm text-gray-700">
            Dropped: {fmtComma(data.dropped)}
          </p>
        )}
        {data.pctDrop !== null && (
          <p className="text-sm font-semibold text-red-600">
            Drop: {data.pctDrop}%
          </p>
        )}
      </div>
    );
  }
  return null;
};

const BarLabel = (props) => {
  const { x, y, width, height, value } = props;
  const isSmall = value < 500_000;
  const labelText = fmt(value);
  return (
    <text
      x={x + width / 2}
      y={y - 8}
      fill={BRAND.graphite}
      textAnchor="middle"
      fontSize={isSmall ? 11 : 13}
      fontWeight="600"
    >
      {labelText}
    </text>
  );
};

export default function USRealEstateWaterfall() {
  const universeTotal = funnelData[0].remaining;
  const finalAudience = funnelData[funnelData.length - 1].remaining;
  const conversionRate = ((finalAudience / universeTotal) * 100).toFixed(2);
  const largestFilter = "Industry (97.1%)";

  return (
    <div className="w-full bg-white">
      {/* Header */}
      <div
        className="w-full px-8 py-10 text-white rounded-t-lg"
        style={{ background: BRAND.gradient }}
      >
        <h1 className="text-3xl font-bold mb-2">{audienceInfo.title}</h1>
        <p className="text-lg opacity-90">
          Audience Logic Report • Waterfall Dropoff
        </p>
      </div>

      {/* Stat Cards Row */}
      <div className="px-8 py-8 grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Card 1: Total Universe */}
        <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
          <p className="text-sm font-medium" style={{ color: BRAND.graphite }}>
            Total Universe
          </p>
          <p
            className="text-2xl font-bold mt-2"
            style={{ color: BRAND.contactBlue }}
          >
            {fmt(universeTotal)}
          </p>
        </div>

        {/* Card 2: Final Audience */}
        <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
          <p className="text-sm font-medium" style={{ color: BRAND.graphite }}>
            Final Audience
          </p>
          <p
            className="text-2xl font-bold mt-2"
            style={{ color: BRAND.contactBlue }}
          >
            {fmt(finalAudience)}
          </p>
        </div>

        {/* Card 3: Conversion Rate */}
        <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
          <p className="text-sm font-medium" style={{ color: BRAND.graphite }}>
            Conversion Rate
          </p>
          <p
            className="text-2xl font-bold mt-2"
            style={{ color: BRAND.contactBlue }}
          >
            {conversionRate}%
          </p>
        </div>

        {/* Card 4: Largest Filter */}
        <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
          <p className="text-sm font-medium" style={{ color: BRAND.graphite }}>
            Largest Filter
          </p>
          <p
            className="text-2xl font-bold mt-2"
            style={{ color: BRAND.contactBlue }}
          >
            {largestFilter}
          </p>
        </div>
      </div>

      {/* Waterfall Bar Chart */}
      <div className="px-8 py-8">
        <h2
          className="text-lg font-bold mb-6"
          style={{ color: BRAND.graphite }}
        >
          Waterfall Dropoff Analysis
        </h2>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={funnelData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E0E7FF" />
            <XAxis dataKey="step" tick={{ fill: BRAND.graphite, fontSize: 12 }} />
            <YAxis
              tickFormatter={(value) => fmt(value)}
              tick={{ fill: BRAND.graphite, fontSize: 12 }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="remaining" radius={[8, 8, 0, 0]} label={<BarLabel />}>
              {funnelData.map((entry, index) => {
                const barColor =
                  entry.pctDrop !== null && entry.pctDrop > 80
                    ? BRAND.danger
                    : BRAND.contactBlue;
                return <Cell key={`cell-${index}`} fill={barColor} />;
              })}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Funnel Detail Table */}
      <div className="px-8 py-8">
        <h2
          className="text-lg font-bold mb-6"
          style={{ color: BRAND.graphite }}
        >
          Filter Details
        </h2>
        <div className="overflow-x-auto rounded-lg border border-gray-200">
          <table className="w-full text-sm">
            {/* Table Header */}
            <thead>
              <tr style={{ backgroundColor: BRAND.graphite }}>
                <th className="px-6 py-3 text-left text-white font-semibold">
                  Step
                </th>
                <th className="px-6 py-3 text-left text-white font-semibold">
                  Filter Applied
                </th>
                <th className="px-6 py-3 text-right text-white font-semibold">
                  Records Remaining
                </th>
                <th className="px-6 py-3 text-right text-white font-semibold">
                  Dropped
                </th>
                <th className="px-6 py-3 text-center text-white font-semibold">
                  % Drop
                </th>
              </tr>
            </thead>

            {/* Table Body */}
            <tbody>
              {funnelData.map((row, idx) => (
                <tr
                  key={idx}
                  style={{
                    backgroundColor:
                      idx % 2 === 0 ? BRAND.white : BRAND.eggshell,
                  }}
                  className="border-t border-gray-200"
                >
                  <td className="px-6 py-3 font-medium text-gray-900">
                    {row.step}
                  </td>
                  <td className="px-6 py-3 text-gray-700">
                    {row.step === "Universe"
                      ? "—"
                      : row.step === "US Only"
                        ? "Geographic"
                        : row.step === "Seniority Filter"
                          ? "Job Level"
                          : "Industry"}
                  </td>
                  <td className="px-6 py-3 text-right font-medium text-gray-900">
                    {fmtComma(row.remaining)}
                  </td>
                  <td className="px-6 py-3 text-right text-gray-700">
                    {row.dropped > 0 ? fmtComma(row.dropped) : "—"}
                  </td>
                  <td
                    className="px-6 py-3 text-center font-semibold"
                    style={{
                      color:
                        row.pctDrop !== null && row.pctDrop > 80
                          ? BRAND.danger
                          : BRAND.graphite,
                    }}
                  >
                    {row.pctDrop !== null ? `${row.pctDrop}%` : "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Additional Metrics Section */}
      <div className="px-8 py-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3
            className="text-sm font-semibold mb-2"
            style={{ color: BRAND.graphite }}
          >
            Email Coverage
          </h3>
          <p className="text-2xl font-bold" style={{ color: BRAND.seafoam }}>
            {audienceInfo.emailCoveragePct}%
          </p>
          <p className="text-xs text-gray-600 mt-1">
            {fmtComma(audienceInfo.emailCoverage)} records
          </p>
        </div>
        <div>
          <h3
            className="text-sm font-semibold mb-2"
            style={{ color: BRAND.graphite }}
          >
            Phone Coverage
          </h3>
          <p className="text-2xl font-bold" style={{ color: BRAND.seafoam }}>
            {audienceInfo.phoneCoveragePct}%
          </p>
          <p className="text-xs text-gray-600 mt-1">
            {fmtComma(audienceInfo.phoneCoverage)} records
          </p>
        </div>
      </div>

      {/* Footer */}
      <div
        className="px-8 py-6 text-center text-xs border-t border-gray-200"
        style={{ color: BRAND.clearSky }}
      >
        Data provided by Blue Contact
      </div>
    </div>
  );
